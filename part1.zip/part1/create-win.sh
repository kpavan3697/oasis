#!/usr/bin/env bash
# Creates a Windows NSIS installer (.exe) for i-Ready OASIS.
#
# Usage:
#   ./create-win.sh              # build the Electron app and wrap into an NSIS installer
#
# NOTE: Building on macOS produces an unsigned installer. To sign, run on a
# Windows machine (or CI) with the following env vars set:
#   WIN_CSC_LINK            path or base64-encoded .pfx code-signing certificate
#   WIN_CSC_KEY_PASSWORD    password for that .pfx
#
# Without credentials the script still produces a working unsigned installer
# (suitable for local dev/test). Users will see a SmartScreen warning on first run.
set -euo pipefail

cd "$(dirname "$0")"

VERSION=$(node -e "console.log(require('./package.json').version)")
EXE_OUT="release/i-Ready OASIS-Setup-${VERSION}.exe"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  i-Ready OASIS v${VERSION} — Windows installer build"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [[ -n "${WIN_CSC_LINK:-}" && -n "${WIN_CSC_KEY_PASSWORD:-}" ]]; then
  echo "  • Code signing credentials found — installer will be signed."
else
  echo "  • No signing credentials — installer will be unsigned (dev/test only)."
  echo "    Set WIN_CSC_LINK + WIN_CSC_KEY_PASSWORD to sign."
fi

echo ""
echo "▶ Building Windows installer with electron-builder…"
npx electron-builder --win 2>&1 | grep -v "^$" | sed 's/^/  /'

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Done: $EXE_OUT"
ls -lh "$EXE_OUT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
