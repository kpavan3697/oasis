#!/usr/bin/env bash
# Creates a macOS .pkg installer for i-Ready OASIS.
#
# Usage:
#   ./create-pkg.sh              # build .app then wrap into .pkg
#   ./create-pkg.sh --pkg-only   # skip electron-builder, use existing release/mac-arm64 .app
#
# Signing / notarization (optional — omit for local dev/test builds):
#   PKG_CSC_LINK            base64-encoded Developer ID Installer .p12
#   PKG_CSC_KEY_PASSWORD    password for that .p12
#   APPLE_API_KEY / APPLE_API_KEY_ID / APPLE_API_ISSUER   (notary via API key)
#   — or —
#   APPLE_ID / APPLE_APP_SPECIFIC_PASSWORD / APPLE_TEAM_ID (notary via Apple ID)
set -euo pipefail

cd "$(dirname "$0")"

VERSION=$(node -e "console.log(require('./package.json').version)")
PKG_OUT="release/i-Ready OASIS-${VERSION}-arm64.pkg"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  i-Ready OASIS v${VERSION} — pkg build"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 1: Build the .app (electron-builder) ──────────────────────────────────
if [[ "${1:-}" == "--pkg-only" ]]; then
  echo "▶ Skipping electron-builder (--pkg-only)"
  APP_DIR="release/mac-arm64/i-Ready OASIS.app"
  if [[ ! -d "$APP_DIR" ]]; then
    echo "✗ No .app found at: $APP_DIR"
    echo "  Run without --pkg-only first, or run: npm run dist:mac"
    exit 1
  fi
  echo "  Using existing: $APP_DIR"
else
  echo "▶ Building .app with electron-builder…"
  npx electron-builder --mac --config.mac.target=dir 2>&1 | grep -v "^$" | sed 's/^/  /'
  echo "  .app built: release/mac-arm64/"
fi

echo ""

# ── Step 2: Wrap into .pkg ─────────────────────────────────────────────────────
echo "▶ Creating .pkg installer…"
bash build/build-pkg.sh

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Done: $PKG_OUT"
ls -lh "$PKG_OUT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"