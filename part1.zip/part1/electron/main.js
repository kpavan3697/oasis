/**
 * i-Ready OASIS — Electron main process
 *
 * Boots the existing Express + WebSocket server locally (on an OS-assigned
 * free port) and loads it in a desktop window. All clone/build/IDE work runs
 * on the user's own machine — Electron just wraps the local web app and adds
 * auto-update.
 */
'use strict';

const { app, BrowserWindow, Menu, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { autoUpdater } = require('electron-updater');
const log = require('electron-log');

// Set the app name immediately — before app.whenReady() — so that OS notifications
// and the dock/taskbar show "i-Ready OASIS" instead of the process name "Electron".
app.setName('i-Ready OASIS');
// Windows attributes toast notifications to this ID; without it, notifications
// raised while the window is in the background may not surface. Matches build.appId.
app.setAppUserModelId('com.cainc.iready.oasis');

autoUpdater.logger = log;
log.transports.file.level = 'info';

// ── Scripts live in a writable, update-safe location ───────────────────────
// Bundled default scripts are shipped as extraResources and seeded into
// userData on first run so the user can add their own <repo>.sh scripts.
function setupScriptsDir() {
  const userScriptsDir = path.join(app.getPath('userData'), 'scripts');
  fs.mkdirSync(userScriptsDir, { recursive: true });

  // resourcesPath points at the app's resources dir in a packaged build
  const bundled = app.isPackaged
    ? path.join(process.resourcesPath, 'scripts')
    : path.join(__dirname, '..', 'scripts');

  try {
    if (fs.existsSync(bundled)) {
      for (const f of fs.readdirSync(bundled)) {
        if (f === '.DS_Store') continue;
        // Refresh bundled default scripts on every launch so app updates ship
        // new/updated scripts (e.g. iready-core.sh and the iready-dev-setup
        // toolchain). User-added scripts that aren't part of the bundle are not
        // touched — only entries that ship with the app are overwritten.
        fs.cpSync(path.join(bundled, f), path.join(userScriptsDir, f), {
          recursive: true,
          force: true,
        });
      }
    }
  } catch (e) {
    log.warn('Could not seed default scripts:', e.message);
  }
  return userScriptsDir;
}

// Seed config/oasis.yml into a writable per-user dir so the user can edit
// AWS/Bedrock settings, and they survive updates.
function setupConfig() {
  const dir = path.join(app.getPath('userData'), 'config');
  fs.mkdirSync(dir, { recursive: true });
  const dest = path.join(dir, 'oasis.yml');
  const bundled = app.isPackaged
    ? path.join(app.getAppPath(), 'config', 'oasis.yml')
    : path.join(__dirname, '..', 'config', 'oasis.yml');
  try {
    if (!fs.existsSync(bundled)) return dest;
    if (!fs.existsSync(dest)) {
      // First run — seed from bundled defaults.
      fs.copyFileSync(bundled, dest);
    } else {
      // Existing config — deep-merge bundled defaults for any top-level sections
      // the user's config is missing (e.g. a new 'bedrock:' block added in a later
      // release). User-defined values are never overwritten.
      const yaml = require('js-yaml');
      const bundledCfg = yaml.load(fs.readFileSync(bundled, 'utf8')) || {};
      const userCfg    = yaml.load(fs.readFileSync(dest,    'utf8')) || {};
      let changed = false;
      for (const key of Object.keys(bundledCfg)) {
        if (userCfg[key] === undefined) {
          userCfg[key] = bundledCfg[key];
          changed = true;
        }
      }
      if (changed) fs.writeFileSync(dest, yaml.dump(userCfg), 'utf8');
    }
  } catch (e) {
    log.warn('Could not seed config:', e.message);
  }
  return dest;
}

// App icon (built from the i-Ready logo). Used for the dev dock icon and the
// window icon; packaged builds use the .icns/.ico electron-builder derives from it.
const ICON_PATH = path.join(__dirname, '..', 'build', 'icon.png');

// ── Dev-mode icon patch ────────────────────────────────────────────────────
// In development the process is Electron.app whose bundle contains electron.icns.
// macOS uses that bundle icon for the minimized-window tile in the Dock, ignoring
// app.dock.setIcon(). Overwrite it with our icon at startup so minimize shows the
// correct icon. This is a no-op in packaged builds (app.isPackaged === true).
if (!app.isPackaged && process.platform === 'darwin') {
  try {
    const icnsPath = path.join(__dirname, '..', 'build', 'icon.icns');
    const bundleIcon = path.join(path.dirname(process.execPath), '..', 'Resources', 'electron.icns');
    if (fs.existsSync(icnsPath)) fs.copyFileSync(icnsPath, bundleIcon);
  } catch (_) { /* non-fatal — ignore permission errors */ }
}

// ── Fix PATH for GUI launches ──────────────────────────────────────────────
// Apps launched from Finder/Launchpad don't inherit the user's shell PATH, so
// toolchains (mvn, java, git, idea) installed in custom/Homebrew/SDKMAN dirs
// aren't found. Resolve the real login-shell PATH and apply it to this process
// (the embedded server + everything it spawns inherits it).
function resolveUserPath() {
  if (process.platform === 'win32') return;
  // Vars we import from the login shell: PATH (for toolchains) + AWS settings
  // (so Bedrock suggestions use the same creds/profile/region as the terminal).
  const VARS = ['PATH', 'AWS_PROFILE', 'AWS_DEFAULT_PROFILE', 'AWS_REGION', 'AWS_DEFAULT_REGION'];
  try {
    const { execFileSync } = require('child_process');
    const shell = process.env.SHELL || '/bin/zsh';
    const M = '__OASIS_ENV__';
    // -ilc = interactive login shell → sources ~/.zprofile AND ~/.zshrc
    const printArgs = ['"' + M + '"', ...VARS.map(v => `"${v}=$${v}"`), '"' + M + '"'].join(' ');
    const out = execFileSync(shell, ['-ilc', `printf '%s\\n' ${printArgs}`], {
      encoding: 'utf8',
      timeout: 8000,
    });
    const block = out.split(M)[1] || '';
    for (const line of block.split('\n')) {
      const eq = line.indexOf('=');
      if (eq < 0) continue;
      const k = line.slice(0, eq), v = line.slice(eq + 1);
      if (VARS.includes(k) && v) process.env[k] = v;
    }
  } catch (e) {
    log.warn('Could not resolve login env:', e.message);
  }
  // Fallback: make sure common toolchain dirs are present
  const extra = ['/opt/homebrew/bin', '/opt/homebrew/sbin', '/usr/local/bin'];
  const parts = (process.env.PATH || '').split(':').filter(Boolean);
  for (const d of extra) if (!parts.includes(d)) parts.push(d);
  process.env.PATH = parts.join(':');
  log.info('PATH resolved for spawned tools:', process.env.PATH);
  log.info('AWS profile/region:', process.env.AWS_PROFILE || process.env.AWS_DEFAULT_PROFILE || '(default chain)',
    '/', process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || '(config/default)');
}

let mainWindow = null;

async function createWindow() {
  // Configure server paths before requiring it
  process.env.OASIS_SCRIPTS_DIR = setupScriptsDir();
  process.env.OASIS_PUBLIC_DIR = app.isPackaged
    ? path.join(app.getAppPath(), 'public')
    : path.join(__dirname, '..', 'public');
  process.env.OASIS_CONFIG = setupConfig();

  // Start the embedded server on a free port
  const { start } = require('../server');
  const { url } = await start(0);

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,        // restore size when the user un-maximizes
    minWidth: 980,
    minHeight: 640,
    show: false,        // wait until maximized + content ready to avoid a resize flicker
    title: 'i-Ready OASIS',
    icon: ICON_PATH,
    backgroundColor: '#0b0d10',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  // Open maximized (fills the screen). The window stays a normal resizable
  // window — set `mainWindow.setFullScreen(true)` instead for true OS fullscreen.
  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize();
    mainWindow.show();
  });

  // Clear renderer cache on every launch so JS/CSS changes take effect immediately.
  mainWindow.webContents.session.clearCache().then(() => mainWindow.loadURL(url));
  mainWindow.on('closed', () => { mainWindow = null; });

  // Open external links in the system browser, not in-app
  mainWindow.webContents.setWindowOpenHandler(({ url: target }) => {
    if (/^https?:/.test(target)) { shell.openExternal(target); return { action: 'deny' }; }
    return { action: 'allow' };
  });
}

// ── Auto-update ────────────────────────────────────────────────────────────
function setupAutoUpdate() {
  if (!app.isPackaged) return;            // updater only runs in built apps
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;

  autoUpdater.on('update-available', (info) => {
    log.info('Update available:', info.version);
  });
  autoUpdater.on('error', (err) => {
    log.error('Update error:', err == null ? 'unknown' : (err.stack || err).toString());
  });
  autoUpdater.on('update-downloaded', async (info) => {
    const { response } = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      buttons: ['Restart now', 'Later'],
      defaultId: 0,
      cancelId: 1,
      title: 'Update ready',
      message: `i-Ready OASIS ${info.version} has been downloaded.`,
      detail: 'Restart the app to apply the update.',
    });
    if (response === 0) autoUpdater.quitAndInstall();
  });

  // Check on launch, then every 4 hours while running
  autoUpdater.checkForUpdates().catch(() => {});
  setInterval(() => autoUpdater.checkForUpdates().catch(() => {}), 4 * 60 * 60 * 1000);
}

// Manual "Check for Updates…" entry point
async function checkForUpdatesManually() {
  if (!app.isPackaged) {
    dialog.showMessageBox(mainWindow, { type: 'info', message: 'Updates are only available in the installed app.' });
    return;
  }
  try {
    const r = await autoUpdater.checkForUpdates();
    const current = app.getVersion();
    const latest = r && r.updateInfo && r.updateInfo.version;
    if (!latest || latest === current) {
      dialog.showMessageBox(mainWindow, { type: 'info', message: `You're up to date (v${current}).` });
    }
    // if an update exists, the 'update-downloaded' handler will prompt to restart
  } catch (e) {
    dialog.showMessageBox(mainWindow, { type: 'error', message: 'Could not check for updates.', detail: e.message });
  }
}

function buildMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{
      label: app.name,
      submenu: [
        { role: 'about' },
        { label: 'Check for Updates…', click: checkForUpdatesManually },
        { type: 'separator' },
        { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' },
      ],
    }] : []),
    { role: 'editMenu' },
    { role: 'viewMenu' },
    {
      role: 'help',
      submenu: [
        ...(!isMac ? [{ label: 'Check for Updates…', click: checkForUpdatesManually }] : []),
        { label: 'Learn More', click: () => shell.openExternal('https://github.cainc.com/iready/iready-oasis') },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// Single-instance lock so only one OASIS runs at a time
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
  });

  app.whenReady().then(async () => {
    resolveUserPath(); // make toolchains (mvn/java/git/idea) findable for GUI launches

    // Set dock icon inside whenReady — calling it before ready is unreliable on macOS
    // and results in the default Electron icon showing when the window is minimized.
    if (process.platform === 'darwin' && app.dock) {
      try {
        const { nativeImage } = require('electron');
        const img = nativeImage.createFromPath(ICON_PATH);
        if (!img.isEmpty()) app.dock.setIcon(img);
      } catch (_) { /* non-fatal */ }
    }

    buildMenu();
    await createWindow();
    setupAutoUpdate();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
      } else if (!global._wellnessPopupActive && mainWindow && !mainWindow.isDestroyed() && !mainWindow.isVisible()) {
        // Main window was hidden by a wellness popup — restore on explicit dock click
        mainWindow.show();
      }
    });
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
}
