/**
 * i-Ready OASIS — Server
 * Express + WebSocket backend
 *  - Proxies GitHub Enterprise API calls (avoids CORS from browser)
 *  - Runs per-repo setup scripts and streams logs via WebSocket
 *  - Stores session credentials in memory (never written to disk)
 */

'use strict';

const express    = require('express');
const http       = require('http');
const path       = require('path');
const fs         = require('fs');
const { exec, spawn } = require('child_process');
const WebSocket  = require('ws');
const axios      = require('axios');
const cors       = require('cors');
const yaml       = require('js-yaml');
require('dotenv').config();

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

const PORT         = process.env.PORT || 3000;
// Paths can be overridden when packaged (Electron) — scripts live in a writable
// location so users can add their own <repo>.sh and keep them across updates.
const SCRIPTS_DIR  = process.env.OASIS_SCRIPTS_DIR || path.join(__dirname, '..', 'scripts');
const PUBLIC_DIR   = process.env.OASIS_PUBLIC_DIR  || path.join(__dirname, '..', 'public');
const CONFIG_PATH  = process.env.OASIS_CONFIG      || path.join(__dirname, '..', 'config', 'oasis.yml');

// Load the YAML config fresh each read so edits apply without a restart.
function loadConfig() {
  try { return yaml.load(fs.readFileSync(CONFIG_PATH, 'utf8')) || {}; }
  catch (e) { return {}; }
}

// Simple exec wrapper — used for git status checks and fire-and-forget IDE launch.
function execQuiet(cmd, opts = {}) {
  return new Promise((resolve, reject) => {
    exec(cmd, { timeout: 25000, ...opts }, (err, stdout) => {
      err ? reject(err) : resolve(stdout.trim());
    });
  });
}

// Distinctive PS4 prefix for `bash -x` so xtrace lines can be told apart from
// real stderr. bash replicates the first char of PS4 per nesting level, so a
// top-level command is "▶ cmd" and nested ones are "▶▶ cmd", etc.
const TRACE_PS4     = '▶ ';
const TRACE_RE      = /^▶+ /;   // any xtrace line
const TRACE_TOP_RE  = /^▶ /;    // top-level command only

// ── In-memory session store (keyed by sessionId) ──────────────────────────
const sessions = {};

// ── Middleware ────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(PUBLIC_DIR));

// ── WebSocket connections map: sessionId → [ws, ...] ─────────────────────
const wsClients = {};

wss.on('connection', (ws, req) => {
  const url    = new URL(req.url, `http://localhost`);
  const sid    = url.searchParams.get('session');
  if (!sid) { ws.close(); return; }
  if (!wsClients[sid]) wsClients[sid] = [];
  wsClients[sid].push(ws);

  ws.on('close', () => {
    wsClients[sid] = (wsClients[sid] || []).filter(c => c !== ws);
  });

  ws.send(JSON.stringify({ type: 'connected', session: sid }));
});

function broadcast(sessionId, payload) {
  const clients = wsClients[sessionId] || [];
  const msg = JSON.stringify(payload);
  clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

// ── ROUTES ────────────────────────────────────────────────────────────────

/** Health check */
app.get('/api/health', (_req, res) => res.json({ ok: true, ts: Date.now() }));

/** Returns the local Mac username — used to personalise the Jenkins token page link. */
app.get('/api/whoami', (_req, res) => res.json({ username: process.env.USER || '' }));

/**
 * POST /api/launch-fuselage
 * Triggers the "Launch Fuselage" Jenkins job.
 * Fetches a fresh crumb first (anti-CSRF), then POSTs to the build endpoint.
 */
app.post('/api/launch-fuselage', async (req, res) => {
  const { session, launch = true, doDelete = false } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const jUrl   = 'https://jenkins2.cainc.com';
  const jToken = sess.jenkinsToken || '';
  const jUser  = sess.jenkinsUser  || sess.githubLogin || '';
  if (!jToken) return res.status(400).json({ error: 'Jenkins API token not configured — add it in Settings.' });

  const auth = { username: jUser, password: jToken };

  try {
    // 1. Fetch a fresh crumb
    const crumbResp = await axios.get(`${jUrl}/crumbIssuer/api/json`, { auth, timeout: 8000 });
    const crumbField = crumbResp.data.crumbRequestField;
    const crumb      = crumbResp.data.crumb;

    // 2. Trigger the build
    const params = new URLSearchParams();
    params.append('json', JSON.stringify({
      parameter: [{ name: 'LAUNCH', value: !!launch }, { name: 'DELETE', value: !!doDelete }],
      statusCode: '303', redirectTo: '.',
    }));

    await axios.post(
      `${jUrl}/job/utility/job/Launch%20Fuselage/build?delay=0sec`,
      params.toString(),
      {
        auth,
        headers: { [crumbField]: crumb, 'Content-Type': 'application/x-www-form-urlencoded' },
        maxRedirects: 0,
        validateStatus: s => s < 400,
        timeout: 15000,
      }
    );

    res.json({ ok: true });
  } catch (e) {
    const status = e.response?.status;
    const msg = status === 401 || status === 403
      ? 'Jenkins auth failed — check your API token in Settings'
      : e.message?.slice(0, 200);
    res.status(500).json({ error: msg });
  }
});

/**
 * POST /api/validate-jenkins
 * Body: { token, user }
 * Validates a Jenkins API token by hitting the Jenkins user profile API.
 * Does NOT require an existing session — used during wizard before session exists.
 */
app.post('/api/validate-jenkins', async (req, res) => {
  const { token, user } = req.body;
  if (!token || !user) return res.json({ ok: false, error: 'Token and username required' });
  const jUrl = 'https://jenkins2.cainc.com';
  try {
    await axios.get(`${jUrl}/me/api/json`, {
      auth: { username: user, password: token },
      timeout: 8000,
    });
    res.json({ ok: true });
  } catch (e) {
    const status = e.response?.status;
    const msg = status === 401 || status === 403
      ? 'Invalid token or username'
      : `Could not reach Jenkins (${status || e.code || e.message})`;
    res.json({ ok: false, error: msg });
  }
});

/** GET /api/jenkins-discover?session=SID — finds the Jenkins job structure */
app.get('/api/jenkins-discover', async (req, res) => {
  const { session } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const jUrl   = (sess.jenkinsUrl || 'https://jenkins2.cainc.com').replace(/\/$/, '');
  const jToken = sess.jenkinsToken || '';
  const jUser  = sess.jenkinsUser || sess.githubLogin || '';
  if (!jToken) return res.json({ error: 'No Jenkins token' });

  const auth = { username: jUser, password: jToken };
  try {
    const root = await axios.get(`${jUrl}/api/json?depth=2`, { auth, timeout: 12000 });
    const jobs = root.data?.jobs || [];
    res.json({ jobs: jobs.map(j => ({ name: j.name, type: j._class, url: j.url, jobs: (j.jobs||[]).map(jj => ({ name: jj.name, type: jj._class })) })) });
  } catch (e) {
    res.json({ error: e.message, status: e.response?.status });
  }
});

/**
 * POST /api/session
 * Body: { githubUrl, org, token, cloneDir, intellijPath, mavenArgs, extraEnv }
 * Creates a session, returns sessionId
 */
app.post('/api/session', async (req, res) => {
  const { githubUrl, org, token, cloneDir, intellijPath, mavenArgs, extraEnv,
          jenkinsUrl, jenkinsUser, jenkinsToken, jenkinsPattern } = req.body;
  if (!githubUrl || !org || !token || !cloneDir) {
    return res.status(400).json({ error: 'githubUrl, org, token and cloneDir are required' });
  }

  // Validate credentials and capture the GitHub login (used as Jenkins username).
  const apiBase = githubUrl.replace(/\/$/, '') + '/api/v3';
  let githubLogin = '';
  try {
    const userResp = await axios.get(`${apiBase}/user`, {
      headers: {
        Authorization: `token ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      timeout: 12000,
    });
    githubLogin = userResp.data?.login || '';
  } catch (err) {
    const status = err.response?.status;
    const ghMsg  = err.response?.data?.message || '';
    if (status === 401) {
      return res.status(401).json({ error: `Invalid token — ${ghMsg || 'bad credentials'}. Re-generate your PAT and try again.` });
    }
    if (status === 403) {
      return res.status(403).json({ error: `Token lacks required permissions — ${ghMsg || 'check the repo scope'}. Re-generate your PAT with repo access.` });
    }
    if (status === 404) {
      return res.status(404).json({ error: `GitHub API not reachable at ${apiBase} — check the GitHub Enterprise URL.` });
    }
    // Network errors (timeout, ECONNREFUSED, self-signed certs) are not auth failures.
    // Let the session proceed so users can work offline or with untrusted certs.
    console.warn(`[session] credential pre-check failed with non-auth error (${err.code || status}): ${err.message}`);
  }

  const sid = `sess_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  sessions[sid] = { githubUrl, org, token, cloneDir, intellijPath, mavenArgs, extraEnv,
    githubLogin,
    jenkinsUrl: jenkinsUrl || 'https://jenkins2.cainc.com',
    jenkinsUser: githubLogin,   // same as CA GitHub login
    jenkinsToken,
    jobs: {}, sudoPassword: null };
  res.json({ sessionId: sid, githubLogin });
});

/**
 * POST /api/sudo-password
 * Body: { session, password }
 * Validates the Mac login password via `sudo -S -v` and stores it in the
 * session (memory only, never written to disk). Passed to every setup script
 * as OASIS_SUDO_PW so dl_prime_sudo never needs to pop a dialog.
 */
app.post('/api/sudo-password', async (req, res) => {
  const { session, password } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!password) return res.status(400).json({ error: 'password is required' });

  const valid = await validateSudoPassword(password);
  if (!valid) return res.json({ ok: false, error: 'Incorrect password — try again' });

  sess.sudoPassword = password;
  res.json({ ok: true });
});

/**
 * GET /api/sudo-status?session=SID
 * Returns whether the session has a stored password and whether sudo is
 * currently valid (timestamp still warm).
 */
app.get('/api/sudo-status', async (req, res) => {
  const sess = sessions[req.query.session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const hasPassword = !!sess.sudoPassword;
  // Check whether the sudo timestamp is still live without using the password.
  const timestampValid = await new Promise(resolve => {
    const p = spawn('sudo', ['-n', '-v'], { stdio: 'ignore' });
    p.on('close', code => resolve(code === 0));
  });
  res.json({ hasPassword, timestampValid });
});

// Returns the user's full interactive login environment (Homebrew, nvm, etc.
// all on PATH) by sourcing ~/.zshrc in a login shell. Cached after first call.
let _loginEnv = null;
async function getLoginEnv() {
  if (_loginEnv) return _loginEnv;
  try {
    const raw = await execQuiet(
      'bash -lc "env"',
      { timeout: 10000, env: { ...process.env, HOME: process.env.HOME, PATH: '/bin:/usr/bin:/usr/local/bin:/opt/homebrew/bin' } }
    );
    const env = {};
    raw.split('\n').forEach(line => {
      const idx = line.indexOf('=');
      if (idx > 0) env[line.slice(0, idx)] = line.slice(idx + 1);
    });
    _loginEnv = env;
  } catch {
    _loginEnv = { ...process.env };
  }
  return _loginEnv;
}

function validateSudoPassword(pw) {
  return new Promise(resolve => {
    const proc = spawn('sudo', ['-S', '-p', '', '-v'], {
      stdio: ['pipe', 'ignore', 'pipe'],
    });
    proc.stdin.write(pw + '\n');
    proc.stdin.end();
    proc.on('close', code => resolve(code === 0));
  });
}

/**
 * GET /api/repos?session=SID&page=1&per_page=100
 * Fetches org repos from GitHub Enterprise via server (avoids browser CORS)
 */
app.get('/api/repos', async (req, res) => {
  const { session, page = 1, per_page = 100 } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const resp = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
      headers: {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0'
      },
      params: { page, per_page, type: 'all', sort: 'updated', direction: 'desc' }
    });

    // Enrich: resolve which local setup script each repo would run
    const repos = resp.data.map(enrichRepo);

    // Pagination info from Link header
    const link    = resp.headers['link'] || '';
    const hasNext = link.includes('rel="next"');
    // Parse the last-page number from the Link header so the UI can show X/total.
    const lastMatch = link.match(/[?&]page=(\d+)[^>]*>;\s*rel="last"/);
    const lastPage  = lastMatch ? Number(lastMatch[1]) : Number(page);
    const estimatedTotal = hasNext ? lastPage * Number(per_page) : (Number(page) - 1) * Number(per_page) + repos.length;
    res.json({ repos, hasNext, page: Number(page), estimatedTotal });
  } catch (err) {
    const status = err.response?.status || 500;
    const msg    = err.response?.data?.message || err.message;
    res.status(status).json({ error: msg });
  }
});

/**
 * GET /api/repos/count?session=SID
 * Returns the exact total number of repos in the org via the search API.
 * Called once on startup so the UI can show "100 / 308" from the first page.
 */
app.get('/api/repos/count', async (req, res) => {
  const sess = sessions[req.query.session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const resp = await axios.get(`${apiBase}/search/repositories`, {
      headers: {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      params: { q: `org:${sess.org}`, per_page: 1 },
      timeout: 8000,
    });
    res.json({ total: resp.data.total_count });
  } catch (err) {
    res.status(err.response?.status || 500).json({ error: err.message });
  }
});

/**
 * GET /api/repos/search?session=SID&q=QUERY
 * Searches ALL repos in the org via GitHub's search API (not just loaded pages).
 * Returns up to 30 matches enriched with the same script-resolution fields.
 */
app.get('/api/repos/search', async (req, res) => {
  const { session, q } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!q || !q.trim()) return res.json({ repos: [] });

  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const resp = await axios.get(`${apiBase}/search/repositories`, {
      headers: {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      params: { q: `${q.trim()}+org:${sess.org}`, per_page: 30, sort: 'updated' },
      timeout: 10000,
    });
    const repos = (resp.data.items || []).map(enrichRepo);
    res.json({ repos, total: resp.data.total_count });
  } catch (err) {
    const status = err.response?.status || 500;
    const msg    = err.response?.data?.message || err.message;
    res.status(status).json({ error: msg });
  }
});

/**
 * POST /api/generate-scripts
 * Body: { session }
 * For every repo in the org that has no dedicated <repo-name>.sh:
 *   1. Fetches the README from GitHub.
 *   2. Asks Claude (Bedrock) whether the README describes setup steps beyond a
 *      standard Maven/npm build. If yes, Claude returns a complete bash script.
 *   3. Writes the script to scripts/<repo-name>.sh (skips repos that already
 *      have one, and repos where Claude says the default setup.sh is enough).
 * Progress is broadcast over WebSocket as script_gen_* events.
 */
app.post('/api/generate-scripts', async (req, res) => {
  const { session } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const cfg = loadConfig();
  if (!cfg?.bedrock?.model?.id && !cfg?.bedrock?.model?.arn) {
    return res.status(400).json({ error: 'Bedrock model not configured in config/oasis.yml' });
  }

  res.json({ ok: true });
  generateScriptsForOrg(session, sess, cfg).catch(e =>
    broadcast(session, { type: 'script_gen_error', message: e.message })
  );
});

async function generateScriptsForOrg(sessionId, sess, cfg) {
  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  const ghHeaders = {
    Authorization: `token ${sess.token}`,
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'iready-oasis/1.0',
  };

  // Collect all repos (paginated)
  broadcast(sessionId, { type: 'script_gen_start', message: 'Fetching repository list…' });
  let allRepos = [], page = 1;
  while (true) {
    const r = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
      headers: ghHeaders,
      params: { page, per_page: 100, type: 'all', sort: 'updated' },
    });
    allRepos = allRepos.concat(r.data);
    if (!r.headers['link']?.includes('rel="next"')) break;
    page++;
  }

  // Only process repos that don't already have a dedicated script
  const candidates = allRepos.filter(r => {
    const scriptPath = path.join(SCRIPTS_DIR, `${r.name}.sh`);
    const folderPath = path.join(SCRIPTS_DIR, r.name, 'setup.sh');
    return !fs.existsSync(scriptPath) && !fs.existsSync(folderPath);
  });

  broadcast(sessionId, {
    type: 'script_gen_progress',
    message: `${allRepos.length} repos found — ${candidates.length} need evaluation (${allRepos.length - candidates.length} already have scripts)`,
    total: candidates.length, done: 0,
  });

  const SCRIPT_TEMPLATE = fs.readFileSync(path.join(SCRIPTS_DIR, 'setup.sh'), 'utf8');

  const results = { generated: [], skipped: [], failed: [] };

  for (let i = 0; i < candidates.length; i++) {
    const repo = candidates[i];
    broadcast(sessionId, {
      type: 'script_gen_progress',
      message: `Analyzing ${repo.name} (${i + 1}/${candidates.length})…`,
      total: candidates.length, done: i,
    });

    try {
      // Fetch README — GitHub returns base64-encoded content
      let readme = '';
      try {
        const rmResp = await axios.get(`${apiBase}/repos/${sess.org}/${repo.name}/readme`, {
          headers: { ...ghHeaders, Accept: 'application/vnd.github.raw' },
          timeout: 10000,
        });
        readme = typeof rmResp.data === 'string' ? rmResp.data : '';
      } catch (e) {
        if (e.response?.status === 404) {
          results.skipped.push({ name: repo.name, reason: 'no README' });
          continue;
        }
        throw e;
      }

      // Trim README to fit in context (keep first ~4 000 chars where setup docs live)
      const readmeTrimmed = readme.slice(0, 4000);

      const script = await generateScriptFromReadme(repo.name, repo.language || 'unknown', readmeTrimmed, cfg);

      if (!script) {
        results.skipped.push({ name: repo.name, reason: 'no special setup steps' });
        continue;
      }

      const scriptPath = path.join(SCRIPTS_DIR, `${repo.name}.sh`);
      fs.writeFileSync(scriptPath, script, { mode: 0o755 });
      results.generated.push(repo.name);
      broadcast(sessionId, { type: 'script_gen_created', repo: repo.name, path: scriptPath });

    } catch (e) {
      results.failed.push({ name: repo.name, error: e.message });
      broadcast(sessionId, { type: 'script_gen_failed', repo: repo.name, error: e.message });
    }

    // Brief pause to avoid hammering Bedrock rate limits
    await new Promise(r => setTimeout(r, 300));
  }

  broadcast(sessionId, {
    type: 'script_gen_done',
    generated: results.generated,
    skipped: results.skipped.length,
    failed: results.failed.length,
    message: `Done — ${results.generated.length} scripts created, ${results.skipped.length} repos use default setup, ${results.failed.length} failed.`,
  });
}

const SCRIPT_GEN_SYSTEM = `You are a DevOps engineer creating non-interactive bash setup scripts for "i-Ready OASIS", an internal Curriculum Associates developer tool for macOS. The tool clones repos and runs bash setup scripts non-interactively (no stdin, no tty).

Given a repository name, language, and README, decide whether the repo needs a CUSTOM setup script beyond what the default setup already handles (Maven clean install / npm install / standard build).

Output SKIP if the README only shows: standard Maven/npm/gradle build, standard git clone, or has no dev-setup section. The default script handles those automatically.

Output a complete bash script ONLY if the README describes steps that are NOT in the default flow, such as:
- Specific environment variables required before building
- Database setup, seeding or migrations
- Docker Compose or extra local services to start
- Custom .env / config file population beyond .env.example
- AWS credential setup, localstack, or non-standard ports
- Steps unique to THIS repo not covered by a generic build

SCRIPT RULES (must follow exactly):
- First line: #!/usr/bin/env bash
- set -euo pipefail
- CLONE_DIR="\${1:?Usage: <repo>.sh <clone_dir>}"
- SCRIPT_DIR=$( cd -- "$( dirname -- "\${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
- cd "$CLONE_DIR"
- Source the common lib: source "$SCRIPT_DIR/lib/oasis-common.sh"
- Call dl_prime_sudo before any sudo operations
- Never use interactive prompts (read, sudo -p with a tty, etc.)
- Use \${ENV_VAR:-default} for optional vars
- For Java/Maven builds, end with: mvn clean install \${MAVEN_ARGS:--DskipTests -Dplugin.prettier.goal=skip}
- For Node, end with: npm install (or yarn/pnpm if lock file present)
- Keep script under 80 lines; only include the EXTRA steps from the README
- No markdown, no code fences, no explanation — raw bash only`;

async function generateScriptFromReadme(repoName, language, readme, cfg) {
  const { BedrockRuntimeClient, ConverseCommand } = require('@aws-sdk/client-bedrock-runtime');
  const region = cfg?.aws?.region || process.env.AWS_REGION || 'us-east-1';
  const clientCfg = { region };
  if (cfg?.aws?.profile) {
    const { fromIni } = require('@aws-sdk/credential-providers');
    clientCfg.credentials = fromIni({ profile: cfg.aws.profile });
  }
  const client = new BedrockRuntimeClient(clientCfg);
  const modelId = cfg?.bedrock?.model?.arn || cfg?.bedrock?.model?.id;

  const resp = await client.send(new ConverseCommand({
    modelId,
    system: [{ text: SCRIPT_GEN_SYSTEM }],
    messages: [{
      role: 'user',
      content: [{ text: `Repo: ${repoName}\nLanguage: ${language}\n\nREADME:\n${readme}` }],
    }],
    inferenceConfig: { maxTokens: 1024, temperature: 0.1 },
  }));

  const output = (resp?.output?.message?.content || []).map(b => b.text).filter(Boolean).join('').trim();
  if (!output || output.toUpperCase().startsWith('SKIP')) return null;
  // Ensure it starts with a shebang — guard against Claude adding prose
  const shebangIdx = output.indexOf('#!/');
  if (shebangIdx === -1) return null;
  return output.slice(shebangIdx);
}

/**
 * GET /api/scripts?session=SID&repo=REPO_NAME
 * Lists available setup scripts in the local scripts/<repo>/ folder
 */
app.get('/api/scripts', (req, res) => {
  const { session, repo } = req.query;
  if (!sessions[session]) return res.status(401).json({ error: 'Invalid session' });

  const repoScriptsDir = path.join(SCRIPTS_DIR, repo);
  if (!fs.existsSync(repoScriptsDir)) {
    // fall back to generic scripts
    const generic = fs.existsSync(SCRIPTS_DIR)
      ? fs.readdirSync(SCRIPTS_DIR).filter(f => f.endsWith('.sh'))
      : [];
    return res.json({ scripts: generic.map(f => ({ name: f, path: path.join(SCRIPTS_DIR, f), generic: true })) });
  }

  const scripts = fs.readdirSync(repoScriptsDir)
    .filter(f => f.endsWith('.sh'))
    .map(f => ({ name: f, path: path.join(repoScriptsDir, f), generic: false }));

  res.json({ scripts });
});

/**
 * POST /api/setup
 * Body: { session, repos: [{name, default_branch, clone_url, language}], options: {intellij, maven, parallel, openInIde} }
 * Kicks off setup jobs, streams progress via WebSocket
 */
app.post('/api/setup', (req, res) => {
  const { session, repos, options = {} } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repos || repos.length === 0) return res.status(400).json({ error: 'No repos specified' });
  if (repos.length > 10) return res.status(400).json({ error: 'Max 10 repos per run' });

  // Acknowledge immediately; work happens async via WS
  res.json({ ok: true, jobCount: repos.length });

  if (options.parallel) {
    repos.forEach(r => runSetup(session, sess, r, options));
  } else {
    (async () => {
      for (const r of repos) await runSetup(session, sess, r, options);
    })();
  }
});

/**
 * POST /api/suggest
 * Body: { session, repo, language, logs }
 * Returns a troubleshooting suggestion for a failed setup.
 *  - Uses Claude on AWS Bedrock when configured in config/oasis.yml (model +
 *    aws region/profile); otherwise falls back to an offline heuristic analyzer.
 */
app.post('/api/suggest', async (req, res) => {
  const { session, repo, language, logs } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const text = String(logs || '').slice(-6000);

  // Gather on-disk repo context so Claude can reason about the actual structure
  const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  const repoCtx = gatherRepoContext(cloneDir, repo);

  const cfg = loadConfig();
  const modelId = cfg?.bedrock?.model?.arn || cfg?.bedrock?.model?.id;
  const aiEnabled = cfg?.suggestions?.enabled !== false && !!modelId;
  const generic = () => heuristicSuggest({ repo, language, logs: text, repoCtx });

  if (aiEnabled) {
    try {
      // User has Claude/Bedrock access → return the AI-generated suggestion.
      const suggestion = await bedrockSuggest({ repo, language, logs: text, repoCtx }, cfg);
      return res.json({ suggestion, source: 'bedrock', commands: extractCommands(suggestion) });
    } catch (e) {
      // User lacks Claude/Bedrock access (denied or no valid credentials)
      // → show the generic message instead of the Claude suggestion.
      if (isAccessError(e)) {
        console.warn('No Bedrock/Claude access for this user — using generic suggestion:', e.name || e.message);
        // reason='no-access' lets the UI hint at refreshing AWS credentials.
        const g = generic();
        return res.json({ suggestion: g, source: 'generic', reason: 'no-access', commands: extractCommands(g) });
      }
      // Other failures (throttling, network, bad response) → also fall back.
      console.warn('Bedrock suggestion failed, using generic suggestion:', e.message);
    }
  }
  const g = generic();
  res.json({ suggestion: g, source: 'generic', commands: extractCommands(g) });
});

/**
 * POST /api/run-commands
 * Body: { session, repo, commands: [string] }
 * Runs the suggested fix commands in the repo's clone dir, streaming output to
 * the job terminal over WebSocket. Stops on the first failing command.
 * Note: this runs as the local user in their own clone dir — the same trust
 * level as the setup scripts the app already executes.
 */
app.post('/api/run-commands', (req, res) => {
  const { session, repo, commands, cmdIndex } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo) return res.status(400).json({ error: 'repo is required' });

  const safe = (Array.isArray(commands) ? commands : []).map(String).filter(isRunnableCommand).slice(0, 12);
  if (safe.length === 0) return res.status(400).json({ error: 'No runnable commands provided' });

  res.json({ ok: true, count: safe.length });

  const jobId = repo;
  const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  const env = buildEnv(sess, cloneDir);

  (async () => {
    broadcast(session, { type: 'fix_start', jobId, cmdIndex });
    const capture = [];
    try {
      if (!fs.existsSync(cloneDir)) {
        throw new Error(`Clone directory not found: ${cloneDir}. Set up the repo first.`);
      }
      for (const cmd of safe) {
        // Register the running process so /api/cancel-fix can kill it
        await shCancellable(cmd, session, jobId, cloneDir, env, capture);
      }
      const followups = extractFollowups(capture.join('\n'), safe);
      broadcast(session, { type: 'fix_done', jobId, success: true, cmdIndex, followups });
    } catch (err) {
      log(session, jobId, 'err', `✗ ${err.message}`);
      const followups = extractFollowups(capture.join('\n'), safe);
      const cancelled = sess._fixCancelled?.[jobId];
      broadcast(session, { type: 'fix_done', jobId, success: false, error: err.message, cmdIndex, followups, cancelled });
      if (sess._fixCancelled) delete sess._fixCancelled[jobId];
    }
  })();
});

/**
 * POST /api/cancel-fix
 * Body: { session, repo }
 * Kills the currently running fix command for a repo.
 */
app.post('/api/cancel-fix', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const proc = sess._fixProc?.[repo];
  if (proc) {
    if (!sess._fixCancelled) sess._fixCancelled = {};
    sess._fixCancelled[repo] = true;
    try { process.kill(-proc.pid, 'SIGTERM'); } catch (_) { proc.kill('SIGTERM'); }
    delete sess._fixProc[repo];
    res.json({ ok: true });
  } else {
    res.json({ ok: false, message: 'No running command for this repo' });
  }
});

// Like sh() but registers the spawned process in sess._fixProc[jobId] so it
// can be cancelled via /api/cancel-fix. The process is run in its own process
// group (detached) so SIGTERM propagates to child processes (e.g. mvn forks).
function shCancellable(cmd, sessionId, jobId, cloneDir, env, capture) {
  const sess = sessions[sessionId];
  return new Promise((resolve, reject) => {
    const fullCmd = `cd "${cloneDir}" && ${cmd}`;
    log(sessionId, jobId, 'cmd', '$ ' + fullCmd.replace(/https:\/\/[^@]+@/, 'https://***@'));

    const proc = spawn('bash', ['-c', fullCmd], {
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,   // own process group → SIGTERM kills the whole tree (mvn + java forks)
    });

    if (sess) {
      if (!sess._fixProc) sess._fixProc = {};
      sess._fixProc[jobId] = proc;
    }

    const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');
    const makeLineHandler = (onLine) => {
      let buf = '';
      return {
        onData: (d) => { buf += d.toString(); const p = buf.split('\n'); buf = p.pop(); p.forEach(l => onLine(stripAnsi(l))); },
        flush:  ()  => { if (buf.length) { onLine(stripAnsi(buf)); buf = ''; } },
      };
    };

    const out = makeLineHandler(l => { capture.push(l); log(sessionId, jobId, 'out', l); });
    const err = makeLineHandler(l => { capture.push(l); log(sessionId, jobId, 'err', l); });
    proc.stdout.on('data', out.onData);
    proc.stderr.on('data', err.onData);
    proc.on('close', code => {
      out.flush(); err.flush();
      if (sess?._fixProc?.[jobId] === proc) delete sess._fixProc[jobId];
      code === 0 ? resolve() : reject(new Error(`Exit code ${code}`));
    });
  });
}

// Treat as "no access" when Bedrock/Claude rejects on auth/permissions or when
// no usable AWS credentials are available. These users get the generic message;
// other (transient) errors fall back too but are logged differently above.
function isAccessError(e) {
  const name = String(e?.name || '');
  const msg = String(e?.message || '');
  const status = e?.$metadata?.httpStatusCode;
  return (
    status === 403 ||
    /AccessDenied|UnrecognizedClient|Unauthorized|ExpiredToken|InvalidSignature|Forbidden|CredentialsProviderError/i.test(name) ||
    /could not load credentials|security token.*invalid|not authorized|access denied|credentials/i.test(msg)
  );
}

// Shell commands we'll offer to run from a suggestion. Only lines that START
// with one of these are treated as runnable — so prose, file edits (JSON/XML
// snippets) and bare identifiers are ignored, and a manual-only suggestion
// produces no commands (the UI then just shows the text, no Run button).
const RUNNABLE_HEADS = new Set([
  'npm', 'npx', 'yarn', 'pnpm', 'mvn', './mvnw', 'mvnw', 'gradle', './gradlew', 'gradlew',
  'brew', 'git', 'export', 'unset', 'source', 'cd', 'chmod', 'cp', 'mv', 'mkdir', 'ln',
  'java', 'javac', 'python', 'python3', 'pip', 'pip3', 'bundle', 'rails', 'node', 'docker',
  'make', 'curl', 'wget', 'sdk', 'asdf', 'nvm', 'open', 'idea', 'code', 'which',
  '/usr/libexec/java_home',
]);

function isRunnableCommand(line) {
  const c = String(line).trim().replace(/^[$#]\s+/, '');   // drop a leading shell prompt
  if (!c || c.length > 300) return false;
  if (!/\s/.test(c)) return false;                         // bare tool name (e.g. `mvn`) — a noun in prose, not a command to run
  if (/[{}<]/.test(c) || /^["']/.test(c)) return false;    // JSON/markup, not a command
  if (/^[A-Z0-9_]+=/.test(c)) return false;                // bare env assignment (set in Settings)
  const parts = c.split(/\s+/);
  const head = parts[0] === 'sudo' ? (parts[1] || '') : parts[0];
  return RUNNABLE_HEADS.has(head);
}

// Extract runnable commands from a suggestion's markdown (fenced blocks first,
// then inline `code`), de-duped and capped.
function extractCommands(md) {
  const text = String(md || '');
  const out = [];
  const add = (line) => {
    const c = String(line).trim().replace(/^[$#]\s+/, '');
    if (isRunnableCommand(c) && !out.includes(c)) out.push(c);
  };
  // Fenced ```code``` blocks — one command per line.
  (text.match(/```[\s\S]*?```/g) || []).forEach(block => {
    block.replace(/```[a-zA-Z]*\n?/, '').replace(/```\s*$/, '').split('\n').forEach(add);
  });
  // Inline `code` outside fenced blocks.
  text.replace(/```[\s\S]*?```/g, '').replace(/`([^`\n]+)`/g, (_, c) => { add(c); return ''; });
  return out.slice(0, 12);
}

// Pull runnable commands a tool printed in its OWN output — e.g. brew's
// "To link this version, run:\n  brew link pnpm". Looks for commands quoted in
// backticks/quotes and for lines that follow a "…run:/try:/use:" hint. Excludes
// commands we already ran. Used to offer a follow-up Run button after a command.
function extractFollowups(text, exclude = []) {
  const lines = String(text || '').split('\n');
  const excl = new Set(exclude.map(c => String(c).trim()));
  const out = [];
  const add = (raw) => {
    const c = String(raw).trim().replace(/^[$#>]\s+/, '');
    if (!isRunnableCommand(c) || excl.has(c) || out.includes(c)) return;
    out.push(c);
  };
  const INLINE_HINT = /\b(?:run|try|execute|use)\b\s*:?\s+(.+)$/i;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    // commands quoted in backticks or quotes anywhere on the line
    (line.match(/[`'"]([^`'"]+)[`'"]/g) || []).forEach(q => add(q.slice(1, -1)));
    // A short label line ending in ':' (e.g. "To force the link…:", "…run:")
    // introduces indented command line(s) below it — the common CLI convention.
    if (/:\s*$/.test(trimmed) && trimmed.length <= 140) {
      for (let j = i + 1; j < lines.length && j <= i + 4; j++) {
        if (!lines[j].trim()) break;          // stop at a blank line
        if (!/^\s/.test(lines[j])) break;     // stop once no longer indented
        add(lines[j]);
      }
    }
    // "run/try/execute/use: <cmd>" on the same line
    const m = trimmed.match(INLINE_HINT);
    if (m) add(m[1]);
  }
  return out.slice(0, 6);
}

const SUGGEST_SYSTEM_PROMPT =
  'You are a senior developer assistant inside "i-Ready OASIS", an internal Curriculum Associates tool that ' +
  'clones repos from GitHub Enterprise and runs setup scripts (git, Maven, npm) on macOS. A repo setup just ' +
  'failed. You will be given the failure logs PLUS the actual on-disk structure of the cloned repo (directory ' +
  'tree, pom.xml modules, README excerpt). Use this real context to give a precise, actionable fix — do not ' +
  'guess at paths or modules that are not present. Respond in markdown: one short diagnosis line, then 2-4 ' +
  'bullet steps with exact commands in backticks. Under 200 words. Do not invent product features.';

// Scan the cloned repo and return a compact context string for Claude.
// Reads: top-level directory tree, Maven module list from parent pom.xml,
// per-module pom.xml <artifactId>, README.md excerpt, and package.json name/scripts.
function gatherRepoContext(cloneDir, repoName) {
  if (!cloneDir || !fs.existsSync(cloneDir)) return null;

  const lines = [`=== Repo: ${repoName} (cloned at ${cloneDir}) ===`];

  // ── Directory tree (depth 2) ─────────────────────────────────────────────
  try {
    const entries = fs.readdirSync(cloneDir).filter(e => !e.startsWith('.')).slice(0, 40);
    lines.push('\nTop-level entries:');
    entries.forEach(e => {
      const full = path.join(cloneDir, e);
      const isDir = fs.statSync(full).isDirectory();
      if (isDir) {
        const sub = fs.readdirSync(full).filter(s => !s.startsWith('.')).slice(0, 15);
        lines.push(`  ${e}/`);
        sub.forEach(s => lines.push(`    ${s}${fs.statSync(path.join(full, s)).isDirectory() ? '/' : ''}`));
      } else {
        lines.push(`  ${e}`);
      }
    });
  } catch (_) {}

  // ── Parent pom.xml — modules + artifactId ───────────────────────────────
  const parentPom = path.join(cloneDir, 'pom.xml');
  if (fs.existsSync(parentPom)) {
    try {
      const xml = fs.readFileSync(parentPom, 'utf8').slice(0, 20000);
      const modules = [...xml.matchAll(/<module>(.*?)<\/module>/g)].map(m => m[1].trim());
      const artifactId = (xml.match(/<artifactId>(.*?)<\/artifactId>/) || [])[1] || '';
      lines.push(`\nParent pom.xml — artifactId: ${artifactId}`);
      if (modules.length) lines.push(`Modules: ${modules.join(', ')}`);

      // For each module, note its artifactId, directory presence, and key plugin config
      modules.forEach(mod => {
        const modDir = path.join(cloneDir, mod);
        const exists = fs.existsSync(modDir);
        const modPom = path.join(modDir, 'pom.xml');
        let modId = '', pluginNotes = '';
        if (exists && fs.existsSync(modPom)) {
          const mx = fs.readFileSync(modPom, 'utf8').slice(0, 8000);
          modId = (mx.match(/<artifactId>(.*?)<\/artifactId>/) || [])[1] || '';

          // Extract openapi-generator inputSpec so Claude knows exactly what file it needs
          const inputSpec = (mx.match(/<inputSpec>(.*?)<\/inputSpec>/s) || [])[1]?.trim();
          if (inputSpec) {
            // Check if the spec path resolves on disk
            const specPath = inputSpec.startsWith('http') ? inputSpec
              : path.resolve(modDir, inputSpec.replace(/\$\{project\.basedir\}/g, modDir)
                                                .replace(/\$\{basedir\}/g, modDir));
            const specExists = inputSpec.startsWith('http') ? '(remote URL)' :
              (fs.existsSync(specPath) ? 'EXISTS on disk' : 'MISSING on disk');
            pluginNotes += ` | openapi inputSpec: "${inputSpec}" → ${specExists}`;
          }

          // Extract other generator plugins that may need files
          const generators = [...mx.matchAll(/<configurationFile>(.*?)<\/configurationFile>/gs)].map(m => m[1].trim());
          if (generators.length) pluginNotes += ` | configFiles: ${generators.join(', ')}`;
        }
        lines.push(`  module "${mod}" → dir ${exists ? 'EXISTS' : 'MISSING'}${modId ? ` (artifactId: ${modId})` : ''}${pluginNotes}`);
      });
    } catch (_) {}
  }

  // ── package.json ─────────────────────────────────────────────────────────
  const pkgJson = path.join(cloneDir, 'package.json');
  if (fs.existsSync(pkgJson)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgJson, 'utf8'));
      lines.push(`\npackage.json — name: ${pkg.name || '?'}, scripts: ${Object.keys(pkg.scripts || {}).join(', ')}`);
    } catch (_) {}
  }

  // ── README excerpt (first 1500 chars) ────────────────────────────────────
  const readmes = ['README.md', 'README.MD', 'readme.md'].map(r => path.join(cloneDir, r));
  const readmePath = readmes.find(r => fs.existsSync(r));
  if (readmePath) {
    try {
      const excerpt = fs.readFileSync(readmePath, 'utf8').slice(0, 1500);
      lines.push(`\nREADME excerpt:\n${excerpt}`);
    } catch (_) {}
  }

  return lines.join('\n');
}

// Pull the most relevant error lines out of a build log (for specific feedback).
function extractErrors(t) {
  const lines = t.split('\n');
  const hits = [];
  const seen = new Set();
  const re = /(\[ERROR\]|ERROR:|error:|FAILED|fatal:|Caused by:|Exception|BUILD FAILURE|cannot find symbol|command not found)/i;
  for (const raw of lines) {
    const line = raw.replace(/^\s*\d+:\d+:\d+\s*/, '').trim();   // strip leading timestamps
    if (!line || !re.test(line)) continue;
    if (/^\[ERROR\]\s*$/.test(line) || /-{5,}/.test(line)) continue;
    const key = line.slice(0, 120);
    if (seen.has(key)) continue;
    seen.add(key);
    hits.push(line.length > 160 ? line.slice(0, 159) + '…' : line);
    if (hits.length >= 6) break;
  }
  return hits;
}

// Offline rule-based analyzer — no external calls, works fully internal/offline.
function heuristicSuggest({ repo, language, logs, repoCtx }) {
  const t = logs || '';

  // ── Maven module / directory mismatch (uses real on-disk context) ──────────
  if (repoCtx) {
    // Find modules declared in pom.xml but whose directories are MISSING on disk
    const missing = [...repoCtx.matchAll(/module "([^"]+)" → dir MISSING/g)].map(m => m[1]);
    if (missing.length) {
      // Check if the log error mentions any of those missing module paths
      const mentioned = missing.filter(m => t.includes(m));
      const target = mentioned.length ? mentioned : missing;

      // Look for an existing directory that matches the module name (different path)
      const existingDirs = [...repoCtx.matchAll(/module "([^"]+)" → dir EXISTS/g)].map(m => m[1]);
      const suggestions = target.map(mod => {
        // Try to find a matching module by artifactId in the context
        const altMatch = repoCtx.match(new RegExp(`module "([^"]+)" → dir EXISTS.*?artifactId: ${mod.replace(/[-/]/g, '[-/]')}`, 's'));
        const alt = altMatch ? altMatch[1] : existingDirs.find(d => d.includes(mod.split('-').pop()) || mod.includes(d.split('/').pop()));
        return alt
          ? `\`${mod}\` → directory missing, but found at \`${alt}\` — check the \`<module>\` path in \`pom.xml\``
          : `\`${mod}\` → directory is missing from the repo`;
      });

      return `**Diagnosis:** Maven module path mismatch — declared in \`pom.xml\` but directory not found.\n\n` +
        suggestions.map(s => `- ${s}`).join('\n') + '\n\n' +
        `- Open the parent \`pom.xml\` and correct the \`<module>\` path to match the actual directory.\n` +
        `- Or skip the missing module temporarily:\n\`\`\`\nmvn clean install -pl \'!${target[0]}\'\n\`\`\``;
    }
  }

  // ── Mac password not provided ──────────────────────────────────────────────
  if (/(Could not obtain administrator access|sudo.*password|Administrator access is required|dl_prime_sudo)/i.test(t)) {
    return `**Diagnosis:** Setup needs your Mac login password to run \`sudo\` commands.\n\n` +
      `- Open **Settings** (top-right) → scroll to **Mac Password** → enter your login password and click **Verify**.\n` +
      `- Check **Save password on this device** so you won't be prompted again.\n` +
      `- Then click **↻ Retry**.`;
  }
  const cmdMatch = t.match(/(?:^|\s)([\w.-]+): command not found/) ||
                   t.match(/command not found: ([\w.-]+)/) ||
                   t.match(/([\w.-]+): No such file or directory[\s\S]*?exec/);
  const errBlock = () => {
    const e = extractErrors(t);
    return e.length ? `\n\n**Key errors from the log:**\n\`\`\`\n${e.join('\n')}\n\`\`\`` : '';
  };

  // ── Maven / Java build failures ──────────────────────────────────────────
  if (/COMPILATION ERROR|cannot find symbol|\[ERROR\].*\.java:\[\d+/i.test(t)) {
    return `**Diagnosis:** Java compilation failed.${errBlock()}\n\n` +
      `- Fix the compile errors shown above (missing import/symbol, syntax).\n` +
      `- Make sure the right **JDK** is active (set **Java Home** in Settings if needed).`;
  }
  if (/(There are test failures|Failed tests:|Tests run:.*Failures: [1-9]|BUILD FAILURE[\s\S]*surefire)/i.test(t)) {
    return `**Diagnosis:** The Maven build failed on **tests**.${errBlock()}\n\n` +
      `- To set up without running tests, add \`-DskipTests\` to **Maven Args** in Settings, then Retry.\n` +
      `- Or fix the failing tests listed above.`;
  }
  if (/(OutOfMemoryError|Java heap space|GC overhead limit)/i.test(t)) {
    return `**Diagnosis:** Maven ran out of memory.\n\n` +
      `- Increase the heap: set \`MAVEN_OPTS=-Xmx2g\` (add it under Extra Env Vars in Settings), then Retry.`;
  }
  if (/(invalid target release|release version .* not supported|Source option .* no longer supported|Unsupported class file major version|No compiler is provided|tools\.jar)/i.test(t)) {
    return `**Diagnosis:** JDK version mismatch (or a JRE is being used instead of a JDK).${errBlock()}\n\n` +
      `- Point **Java Home** in Settings at the JDK version the project needs.\n` +
      `- Find installed JDKs with \`/usr/libexec/java_home -V\`.`;
  }

  if (cmdMatch || /Exit code 127/.test(t)) {
    const cmd = cmdMatch ? cmdMatch[1] : 'the required tool';
    return `**Diagnosis:** \`${cmd}\` isn't on the app's PATH.\n\n` +
      `- OASIS (launched from the dock) may not see tools installed in custom/Homebrew/SDKMAN dirs.\n` +
      `- Confirm it's installed: run \`which ${cmd}\` in Terminal.\n` +
      `- If installed, the app's PATH resolution should pick it up — restart OASIS.\n` +
      `- If missing, install it (e.g. \`brew install ${cmd}\`) or set its location in **Settings**.`;
  }
  if (/JAVA_HOME/.test(t) && /(not set|invalid|No such)/i.test(t)) {
    return `**Diagnosis:** \`JAVA_HOME\` is unset or wrong.\n\n` +
      `- Set **Java Home** in OASIS **Settings** to your JDK path.\n` +
      `- Find it with \`/usr/libexec/java_home\`.`;
  }
  if (/(Non-resolvable|Could not resolve dependencies|Failed to (read|collect).*dependencies|Cannot access .* in offline mode|Could not transfer artifact)/i.test(t)) {
    return `**Diagnosis:** Maven couldn't resolve dependencies.\n\n` +
      `- Check you're on **VPN** and can reach the internal Nexus/artifact repo.\n` +
      `- Verify your \`~/.m2/settings.xml\` has the right mirror/credentials.\n` +
      `- Retry — transient registry/network errors are common.`;
  }
  if (/(Authentication failed|could not read Username|Permission denied \(publickey\)|Invalid username or password|fatal: Authentication|403 Forbidden)/i.test(t)) {
    return `**Diagnosis:** Git authentication to GitHub Enterprise failed.\n\n` +
      `- Your **PAT** may be expired or missing scope — regenerate one with \`repo\` (or Contents: Read) access.\n` +
      `- Update it in **Settings**, then **Retry**.`;
  }
  if (/(repository .* not found|fatal: repository|Could not read from remote repository)/i.test(t)) {
    return `**Diagnosis:** The repository couldn't be reached.\n\n` +
      `- Confirm the repo name and that your PAT can access it.\n` +
      `- Check VPN / GitHub Enterprise connectivity.`;
  }
  if (/(EADDRINUSE|address already in use)/i.test(t)) {
    return `**Diagnosis:** A required port is already in use.\n\n` +
      `- Another process/instance is bound to it — stop it, or change the port in the project config.`;
  }
  if (/ERESOLVE|unable to resolve dependency tree|peer dep/i.test(t)) {
    return `**Diagnosis:** npm dependency conflict (peer deps).\n\n` +
      `- Try installing with \`npm install --legacy-peer-deps\`.\n` +
      `- Or align the conflicting package versions.`;
  }
  if (/(getaddrinfo ENOTFOUND|Could not resolve host|ETIMEDOUT|Connection refused|Network is unreachable)/i.test(t)) {
    return `**Diagnosis:** Network/connectivity problem.\n\n` +
      `- Check your **VPN** and that internal hosts (GitHub Enterprise, Nexus) are reachable.\n` +
      `- Retry once connected.`;
  }
  if (/(Unsupported class file major version|compiled by a more recent version of the Java)/i.test(t)) {
    return `**Diagnosis:** JDK version mismatch.\n\n` +
      `- The project needs a different Java version. Point **Java Home** in Settings at the required JDK.`;
  }
  // Fallback
  const lang = language ? ` (${language})` : '';
  return `**Couldn't pinpoint the cause automatically${lang}.**\n\n` +
    `- Expand the **Logs** and look for the first \`ERROR\`/\`command not found\`/\`fatal\` line.\n` +
    `- Verify required tools are installed and on PATH, and that you're on VPN.\n` +
    `- Fix the issue, then click **Retry**.`;
}

// Claude-on-Bedrock analyzer. Driven by config/oasis.yml; uses the AWS
// credential chain (or the named profile). Only called when a model is configured.
async function bedrockSuggest({ repo, language, logs, repoCtx }, cfg) {
  const { BedrockRuntimeClient, ConverseCommand } = require('@aws-sdk/client-bedrock-runtime');

  const region = cfg?.aws?.region || process.env.AWS_REGION || 'us-east-1';
  const clientCfg = { region };
  if (cfg?.aws?.profile) {
    const { fromIni } = require('@aws-sdk/credential-providers');
    clientCfg.credentials = fromIni({ profile: cfg.aws.profile });
  }
  const client = new BedrockRuntimeClient(clientCfg);

  const modelId = cfg?.bedrock?.model?.arn || cfg?.bedrock?.model?.id;
  // Suggestions are short — cap regardless of the (possibly large) config value.
  const maxTokens = Math.min(Number(cfg?.bedrock?.['max-tokens']) || 1024, 1024);

  const resp = await client.send(new ConverseCommand({
    modelId,
    system: [{ text: SUGGEST_SYSTEM_PROMPT }],
    messages: [{
      role: 'user',
      content: [{ text: [
        `Repo: ${repo}`,
        `Language: ${language || 'unknown'}`,
        repoCtx ? `\n${repoCtx}` : '',
        `\nSetup log (tail):\n${logs}`,
      ].join('\n') }],
    }],
    inferenceConfig: { maxTokens, temperature: 0.2 },
  }));

  const blocks = resp?.output?.message?.content || [];
  const out = blocks.map(b => b.text).filter(Boolean).join('\n').trim();
  if (!out) throw new Error('Empty Bedrock response');
  return out;
}

// ── Core setup runner ─────────────────────────────────────────────────────
async function runSetup(sessionId, sess, repo, options) {
  const jobId = repo.name;
  broadcast(sessionId, { type: 'job_start', jobId, repo: repo.name });

  const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo.name);
  const authedUrl = sess.githubUrl.replace(/\/$/, '') +
    `/${sess.org}/${repo.name}.git`;
  const tokenUrl = authedUrl.replace('https://', `https://${sess.token}@`);

  try {
    // ── Step 1: Clone or pull ──────────────────────────────────────────
    const gitEnv = buildEnv(sess, cloneDir);
    await runStep(sessionId, jobId, 'clone', 'Cloning repository', async () => {
      if (fs.existsSync(cloneDir)) {
        await sh(`git -C "${cloneDir}" pull "${tokenUrl}" ${repo.default_branch}`, sessionId, jobId, { env: gitEnv });
      } else {
        await sh(`git clone --no-single-branch --branch ${repo.default_branch} "${tokenUrl}" "${cloneDir}"`, sessionId, jobId, { env: gitEnv });
      }
    });

    // ── Step 2: Detect & run setup script ─────────────────────────────
    const scriptPath = detectScript(repo.name);
    if (scriptPath) {
      await runStep(sessionId, jobId, 'script', `Running ${path.basename(scriptPath)}`, async () => {
        const env = buildEnv(sess, cloneDir);
        // Run with xtrace + a distinctive PS4 so we can surface each command the
        // script executes (mvn clean install, cp, etc.) in the UI.
        env.PS4 = TRACE_PS4;
        await sh(`bash -x "${scriptPath}" "${cloneDir}"`, sessionId, jobId, { env, trace: true });
      });
    } else {
      // Auto-detect from project type
      await runAutoSetup(sessionId, jobId, sess, repo, cloneDir);
    }

    // ── Step 3: Open in IDE ───────────────────────────────────────────
    if (options.intellij) {
      await runStep(sessionId, jobId, 'ide', 'Opening in IntelliJ IDEA', async () => {
        const cmd = ideaOpenCommand(sess.intellijPath, cloneDir);
        try {
          await sh(cmd, sessionId, jobId);
        } catch (e) {
          // Don't fail the whole setup just because the IDE couldn't launch
          log(sessionId, jobId, 'warn', `Could not open IntelliJ IDEA (${e.message}). ` +
            `Set the IntelliJ CLI path in Settings, or create the launcher via IDEA → Tools → Create Command-line Launcher.`);
        }
      });
    }

    broadcast(sessionId, { type: 'job_done', jobId, success: true });
  } catch (err) {
    // If the failure looks sudo-related, ask the frontend to re-collect the password.
    if (isSudoError(err.message)) {
      broadcast(sessionId, { type: 'sudo_required', jobId, reason: 'Password expired or incorrect — re-enter your Mac password to continue.' });
    }
    broadcast(sessionId, { type: 'job_done', jobId, success: false, error: err.message });
  }
}

function isSudoError(msg) {
  return /incorrect password|sudo.*failed|sorry.*try again|password.*incorrect|authentication failure/i.test(msg);
}

/**
 * Resolve which setup script a repo should run.
 * Resolution order (first match wins):
 *   1. scripts/<repo-name>.sh        — repo has its own script (dedicated)
 *   2. scripts/<repo-name>/setup.sh  — repo folder form (dedicated, legacy)
 *   3. scripts/setup.sh              — the default, used by everything else
 * Returns { path, name, dedicated } or null if nothing exists.
 */

// Shared repo enrichment: adds script-resolution fields to a raw GitHub repo object.
function enrichRepo(r) {
  const resolved = resolveScript(r.name);
  return {
    id:             r.id,
    name:           r.name,
    full_name:      r.full_name,
    description:    r.description || '',
    language:       r.language || 'Unknown',
    updated_at:     r.updated_at,
    default_branch: r.default_branch,
    private:        r.private,
    topics:         r.topics || [],
    size:           r.size,
    clone_url:      r.clone_url,
    html_url:       r.html_url,
    _hasScript:     !!resolved?.dedicated,
    _script:        resolved?.name || null,
    _scriptDefault: resolved ? !resolved.dedicated : false,
  };
}

function resolveScript(repoName) {
  // 1. Flat repo-specific script: scripts/<repo-name>.sh
  const flat = path.join(SCRIPTS_DIR, `${repoName}.sh`);
  if (fs.existsSync(flat)) return { path: flat, name: path.basename(flat), dedicated: true };

  // 2. Folder repo-specific script: scripts/<repo-name>/setup.sh
  const folder = path.join(SCRIPTS_DIR, repoName, 'setup.sh');
  if (fs.existsSync(folder)) return { path: folder, name: `${repoName}/setup.sh`, dedicated: true };

  // 3. Default catch-all: scripts/setup.sh
  const generic = path.join(SCRIPTS_DIR, 'setup.sh');
  if (fs.existsSync(generic)) return { path: generic, name: path.basename(generic), dedicated: false };

  return null;
}

function detectScript(repoName) {
  return resolveScript(repoName)?.path || null;
}

async function runAutoSetup(sessionId, jobId, sess, repo, cloneDir) {
  const lang = (repo.language || '').toLowerCase();

  if (lang === 'java') {
    const mvnArgs = sess.mavenArgs || '-DskipTests';
    await runStep(sessionId, jobId, 'maven', 'Running Maven build', async () => {
      await sh(`cd "${cloneDir}" && mvn clean install ${mvnArgs}`, sessionId, jobId);
    });
  } else if (lang === 'javascript' || lang === 'typescript') {
    const pm = fs.existsSync(path.join(cloneDir, 'yarn.lock')) ? 'yarn' :
               fs.existsSync(path.join(cloneDir, 'pnpm-lock.yaml')) ? 'pnpm' : 'npm';
    await runStep(sessionId, jobId, 'install', `Installing dependencies (${pm})`, async () => {
      await sh(`cd "${cloneDir}" && ${pm} install`, sessionId, jobId);
    });
    if (fs.existsSync(path.join(cloneDir, '.env.example')) && !fs.existsSync(path.join(cloneDir, '.env'))) {
      await runStep(sessionId, jobId, 'env', 'Setting up .env', async () => {
        fs.copyFileSync(path.join(cloneDir, '.env.example'), path.join(cloneDir, '.env'));
        if (sess.extraEnv) fs.appendFileSync(path.join(cloneDir, '.env'), '\n' + sess.extraEnv);
        log(sessionId, jobId, 'ok', '.env configured');
      });
    }
  } else if (lang === 'ruby') {
    await runStep(sessionId, jobId, 'bundle', 'Bundle install', async () => {
      await sh(`cd "${cloneDir}" && bundle install`, sessionId, jobId);
    });
    await runStep(sessionId, jobId, 'db', 'Database setup', async () => {
      await sh(`cd "${cloneDir}" && bundle exec rails db:setup`, sessionId, jobId);
    });
  } else if (lang === 'python') {
    await runStep(sessionId, jobId, 'venv', 'Creating virtual environment', async () => {
      await sh(`python3 -m venv "${cloneDir}/venv"`, sessionId, jobId);
      await sh(`"${cloneDir}/venv/bin/pip" install -r "${cloneDir}/requirements.txt"`, sessionId, jobId);
    });
  } else {
    log(sessionId, jobId, 'warn', `No setup script found for language: ${repo.language || 'unknown'}. Skipping.`);
  }
}

async function runStep(sessionId, jobId, stepId, label, fn) {
  broadcast(sessionId, { type: 'step_start', jobId, stepId, label });
  log(sessionId, jobId, 'info', `▶ ${label}`);
  await fn();
  broadcast(sessionId, { type: 'step_done', jobId, stepId });
}

function log(sessionId, jobId, level, message) {
  broadcast(sessionId, { type: 'log', jobId, level, message, ts: Date.now() });
  // If the script signals it couldn't get a sudo password, prompt the UI immediately.
  if (/Could not obtain administrator access|Administrator access is required/i.test(message)) {
    broadcast(sessionId, {
      type: 'sudo_required',
      jobId,
      reason: 'This setup needs your Mac login password to run administrator commands. Enter it in Settings → Mac Password, then Retry.',
    });
  }
}

/**
 * Build the command used to open a project in IntelliJ IDEA.
 *  - If the user configured an explicit CLI path, use it.
 *  - Otherwise prefer the `idea` launcher on PATH, then fall back to macOS `open`.
 */
function ideaOpenCommand(intellijPath, dir) {
  if (intellijPath) return `"${intellijPath}" "${dir}"`;
  if (process.platform === 'darwin') {
    // Try the `idea` CLI first, then fall back to launching the app bundle
    return `command -v idea >/dev/null 2>&1 && idea "${dir}" || open -a "IntelliJ IDEA" "${dir}"`;
  }
  return `idea "${dir}"`;
}

function buildEnv(sess, cloneDir) {
  const env = {
    ...process.env,
    CLONE_DIR: cloneDir,
    GIT_TERMINAL_PROMPT: '0',
    GIT_ASKPASS: 'echo',
    // Tell dl_prime_sudo to never show a GUI dialog — the OASIS UI
    // collects the Mac password instead (via Settings or the password modal).
    OASIS_NO_DIALOG: '1',
  };
  // Pass the Mac login password so dl_prime_sudo uses it silently.
  if (sess.sudoPassword) env.OASIS_SUDO_PW = sess.sudoPassword;
  if (sess.intellijPath) env.INTELLIJ_PATH = sess.intellijPath;
  if (sess.mavenArgs)    env.MAVEN_ARGS    = sess.mavenArgs;
  if (sess.extraEnv) {
    sess.extraEnv.split('\n').forEach(line => {
      const [k, ...v] = line.split('=');
      if (k && v.length) env[k.trim()] = v.join('=').trim();
    });
  }
  return env;
}

function sh(cmd, sessionId, jobId, opts = {}) {
  return new Promise((resolve, reject) => {
    log(sessionId, jobId, 'cmd', '$ ' + cmd.replace(/https:\/\/[^@]+@/, 'https://***@'));
    const proc = spawn('bash', ['-c', cmd], {
      env: opts.env || process.env,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    // Buffer partial lines: a chunk may end mid-line, so keep the remainder
    // until the next chunk completes it. Only emit on real newlines.
    // Strip ANSI escape codes so Maven/npm colour output renders cleanly in the terminal.
    const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');

    const makeLineHandler = (onLine) => {
      let buf = '';
      const onData = (d) => {
        buf += d.toString();
        const parts = buf.split('\n');
        buf = parts.pop();           // last element is the incomplete line (or '')
        parts.forEach(l => onLine(stripAnsi(l)));
      };
      const flush = () => { if (buf.length) { onLine(stripAnsi(buf)); buf = ''; } };
      return { onData, flush };
    };

    // stderr handler. When tracing, bash xtrace lines (prefixed with our PS4
    // marker) are surfaced as the executed command + a live step label; all
    // other stderr is logged normally. (macOS bash 3.2 has no BASH_XTRACEFD,
    // so trace must be parsed out of stderr.)
    const onErrLine = (l) => {
      if (opts.capture) opts.capture.push(l);
      if (opts.trace && TRACE_RE.test(l)) {
        const cleaned = l.replace(TRACE_RE, '').trim();
        if (!cleaned) return;
        log(sessionId, jobId, 'cmd', cleaned);
        if (TRACE_TOP_RE.test(l)) {  // top-level command (single marker) → show in label
          broadcast(sessionId, { type: 'step_label', jobId, label: 'Running: ' + truncate(cleaned, 90) });
        }
      } else {
        log(sessionId, jobId, 'err', l);
      }
    };

    const out = makeLineHandler(l => { if (opts.capture) opts.capture.push(l); log(sessionId, jobId, 'out', l); });
    const err = makeLineHandler(onErrLine);
    proc.stdout.on('data', out.onData);
    proc.stderr.on('data', err.onData);

    proc.on('close', code => {
      out.flush();                   // emit any trailing partial line
      err.flush();
      code === 0 ? resolve() : reject(new Error(`Exit code ${code}`));
    });
  });
}

function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

/**
 * GET /api/pull-status?session=SID&repos=name1,name2
 * For each cloned repo, git-fetches from origin and returns how many commits
 * it is behind the upstream. Repos not yet cloned are flagged as such.
 */
app.get('/api/pull-status', async (req, res) => {
  const { session, repos: reposParam } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const names = String(reposParam || '').split(',').filter(Boolean);
  const results = {};

  await Promise.all(names.map(async (name) => {
    const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), name);
    if (!fs.existsSync(cloneDir)) { results[name] = { cloned: false }; return; }
    try {
      const tokenUrl = `${sess.githubUrl.replace(/\/$/, '')}/${sess.org}/${name}.git`
        .replace('https://', `https://${sess.token}@`);
      await execQuiet(`git -C "${cloneDir}" fetch --quiet "${tokenUrl}"`);
      const behind = await execQuiet(`git -C "${cloneDir}" rev-list HEAD..FETCH_HEAD --count`);
      results[name] = { cloned: true, behind: parseInt(behind) || 0 };
    } catch (e) {
      results[name] = { cloned: true, behind: 0, fetchError: e.message?.slice(0, 100) };
    }
  }));

  res.json(results);
});

/**
 * POST /api/open-intellij
 * Body: { session, repo }
 * Opens the cloned project directory in IntelliJ IDEA (fire-and-forget).
 */

/** GET /api/branches?session=SID&repo=REPO — lists local and remote branches */
app.get('/api/branches', async (req, res) => {
  const { session, repo } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const dir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  try {
    // Local branches
    const localRaw = await execQuiet(`git -C "${dir}" branch --format="%(refname:short)|%(HEAD)"`, { timeout: 8000 });
    const local = localRaw.split('\n').filter(Boolean).map(line => {
      const [name, head] = line.split('|');
      return { name: name.trim(), current: head.trim() === '*', remote: false };
    });
    const localNames = new Set(local.map(b => b.name));

    // Remote branches — query the server directly with ls-remote. OASIS
    // clones are single-branch (only the cloned branch's objects/refs exist
    // locally), so `git branch -r` would only ever show one branch. ls-remote
    // returns the authoritative server branch list WITHOUT downloading any
    // history — a branch's objects are fetched lazily when you switch to it
    // (see /api/switch-branch). Falls back to local remote-tracking refs if the
    // server is unreachable (offline).
    let remote = [];
    try {
      // github.cainc.com's HTTP/2 endpoint intermittently drops connections, so
      // force HTTP/1.1 and retry a few times before falling back to local refs.
      let lsRaw = null, lastErr = null;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          lsRaw = await execQuiet(`git -C "${dir}" -c http.version=HTTP/1.1 ls-remote --heads origin`, { timeout: 30000 });
          lastErr = null; break;
        } catch (err) {
          lastErr = err;
          if (attempt < 3) await new Promise(r => setTimeout(r, 5000)); // brief pause before retry
        }
      }
      if (lastErr) throw lastErr;
      remote = lsRaw.split('\n').filter(Boolean)
        .map(line => (line.split('\t')[1] || ''))        // "<sha>\trefs/heads/<name>"
        .filter(ref => ref.startsWith('refs/heads/'))
        .map(ref => ref.slice('refs/heads/'.length))
        .filter(name => !localNames.has(name))           // skip if a local branch exists
        .map(name => ({ name, remoteFull: `origin/${name}`, remote: true, current: false }));
    } catch {
      // Offline / server unreachable → show whatever remote-tracking refs exist
      const remoteRaw = await execQuiet(`git -C "${dir}" branch -r --format="%(refname:short)"`, { timeout: 8000 });
      remote = remoteRaw.split('\n').filter(Boolean)
        .map(r => r.trim())
        .filter(r => !r.endsWith('/HEAD'))
        .map(r => ({ name: r.replace(/^origin\//, ''), remoteFull: r, remote: true, current: false }))
        .filter(r => !localNames.has(r.name));
    }

    res.json({ branches: local, remoteBranches: remote });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

/** POST /api/switch-branch — git checkout <branch> (local) or create tracking branch (remote) */
app.post('/api/switch-branch', async (req, res) => {
  const { session, repo, branch, remoteFull } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const dir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  try {
    // Does a local branch with this name already exist?
    let localExists = false;
    try {
      await execQuiet(`git -C "${dir}" rev-parse --verify --quiet "refs/heads/${branch}"`, { timeout: 10000 });
      localExists = true;
    } catch { /* no local branch */ }

    if (localExists) {
      // Local branch already present → just switch to it
      await execQuiet(`git -C "${dir}" checkout "${branch}"`, { timeout: 15000 });
    } else if (remoteFull) {
      // No local branch → this is a remote branch chosen from the ls-remote
      // list, so its objects/tracking ref don't exist locally yet. Fetch just
      // this one branch, then create a local tracking branch from it.
      //
      // Two hazards on github.cainc.com to design around:
      //  • Shallow clones (no shared history) make a normal branch fetch pull
      //    the branch's ENTIRE history. When the clone is shallow, fetch only
      //    the tip (--depth=1) — a single snapshot instead of full history.
      //  • The HTTP/2 endpoint intermittently drops connections ("HTTP2 framing
      //    layer" / "early EOF") — the same fetch fails then succeeds. So force
      //    HTTP/1.1 + a large post buffer and retry a few times.
      const shallow = fs.existsSync(path.join(dir, '.git', 'shallow'));
      const depthFlag = shallow ? '--depth=1' : '';
      const fetchCmd = `git -C "${dir}" -c http.version=HTTP/1.1 -c http.postBuffer=524288000 fetch ${depthFlag} origin "${branch}:refs/remotes/origin/${branch}"`;
      let lastErr = null;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try { await execQuiet(fetchCmd, { timeout: 300000 }); lastErr = null; break; }
        catch (err) { lastErr = err; }
      }
      if (lastErr) throw lastErr;
      // checkout -b --track and --set-upstream-to both require the remote branch
      // to be registered in .git/config's remote config — our manual fetch via
      // an explicit refspec doesn't register it there, so both fail with
      // "is not a branch". Instead: check out at the fetched ref's commit, then
      // write the tracking config directly into .git/config.
      await execQuiet(`git -C "${dir}" checkout -b "${branch}" "refs/remotes/origin/${branch}"`, { timeout: 20000 });
      await execQuiet(`git -C "${dir}" config "branch.${branch}.remote" "origin"`, { timeout: 5000 }).catch(() => {});
      await execQuiet(`git -C "${dir}" config "branch.${branch}.merge" "refs/heads/${branch}"`, { timeout: 5000 }).catch(() => {});
    } else {
      // Fall back: let git resolve (handles "guess" from a single remote)
      await execQuiet(`git -C "${dir}" checkout "${branch}"`, { timeout: 15000 });
    }
    res.json({ ok: true });
  } catch (e) {
    let msg = e.message.slice(0, 300);
    if (/resolve your current index first/i.test(msg)) {
      msg = `The "${repo}" repo has an unresolved merge/rebase or conflicted index, so git won't switch branches. ` +
            `Resolve it in that repo first (e.g. \`git -C "${dir}" merge --abort\` or \`git rebase --abort\`), then retry.`;
    }
    res.status(500).json({ error: msg });
  }
});

/** POST /api/create-branch — git checkout -b <branch> */
app.post('/api/create-branch', async (req, res) => {
  const { session, repo, branch } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const dir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  try {
    await execQuiet(`git -C "${dir}" checkout -b "${branch}"`, { timeout: 10000 });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message.slice(0, 200) }); }
});

/** POST /api/delete-branch — git branch -d <branch> */
app.post('/api/delete-branch', async (req, res) => {
  const { session, repo, branch, force } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const dir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  try {
    const flag = force ? '-D' : '-d';
    await execQuiet(`git -C "${dir}" branch ${flag} "${branch}"`, { timeout: 10000 });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message.slice(0, 200) }); }
});

app.post('/api/open-intellij', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  if (!fs.existsSync(cloneDir)) {
    return res.status(400).json({ error: `Repo not yet cloned at: ${cloneDir}` });
  }

  const cmd = ideaOpenCommand(sess.intellijPath, cloneDir);
  exec(cmd, (err) => { if (err) console.warn('IntelliJ open error:', err.message); });
  res.json({ ok: true });
});

/**
 * GET /api/repo-badges?session=SID&repos=name1,name2&branches=branch1,branch2
 * For each repo: open PR info from GitHub + last Jenkins build status.
 * Best-effort — missing config or errors silently return nulls.
 */
app.get('/api/repo-badges', async (req, res) => {
  const { session, repos: reposParam, branches: branchesParam } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const names    = String(reposParam    || '').split(',').filter(Boolean);
  const branches = String(branchesParam || '').split(',').filter(Boolean);
  const cfg      = loadConfig();
  const apiBase  = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  const ghHeaders = {
    Authorization: `token ${sess.token}`,
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'iready-oasis/1.0',
  };

  const results = {};
  await Promise.all(names.map(async (name, i) => {
    const branch = branches[i] || '';
    const out = { pr: null, jenkins: null };

    // ── Open PR for this branch ────────────────────────────────────────────
    try {
      const q = branch ? `&head=${encodeURIComponent(sess.org + ':' + branch)}` : '';
      const r = await axios.get(
        `${apiBase}/repos/${sess.org}/${name}/pulls?state=open&per_page=5${q}`,
        { headers: ghHeaders, timeout: 8000 }
      );
      const pr = (r.data || [])[0];
      if (pr) {
        out.pr = { number: pr.number, title: pr.title, url: pr.html_url, author: pr.user?.login };
      }
    } catch (_) {}

    // ── Jenkins last build status ──────────────────────────────────────────
    const jUrl   = (sess.jenkinsUrl   || 'https://jenkins2.cainc.com').replace(/\/$/, '');
    const jToken = sess.jenkinsToken || '';
    const jUser  = sess.jenkinsUser  || sess.githubLogin || '';

    if (!jToken) {
      out.jenkins = { error: 'no-token' };
    } else if (branch) {
      // Jenkins multibranch pipeline: slashes in branch names are single-encoded (%2F)
      const encodedBranch = encodeURIComponent(branch);
      const jApiUrl = `${jUrl}/job/iready/job/${encodeURIComponent(name)}/job/${encodedBranch}/lastBuild/api/json`;
      try {
        const jr = await axios.get(jApiUrl, {
          auth: { username: jUser, password: jToken },
          timeout: 8000,
        });
        const d = jr.data;
        out.jenkins = { result: d.result, url: d.url, building: d.building, number: d.number };
      } catch (e) {
        const status = e.response?.status;
        const errMsg = status === 404 ? `Job not found: ${name}/${branch}`
          : status === 401 || status === 403 ? 'Jenkins auth failed — check your API token'
          : e.message?.slice(0, 120);
        console.warn(`[jenkins] ${name}@${branch}: ${errMsg}`);
        out.jenkins = { error: errMsg, url: jApiUrl };
      }
    }

    results[name] = out;
  }));

  res.json(results);
});

/**
 * POST /api/pull
 * Body: { session, repos: [{name, default_branch}] }
 * Pulls latest code for each cloned repo; progress arrives via WebSocket.
 */
app.post('/api/pull', (req, res) => {
  const { session, repos } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const repoList = Array.isArray(repos) ? repos : [];
  if (!repoList.length) return res.status(400).json({ error: 'No repos specified' });

  res.json({ ok: true, count: repoList.length });

  (async () => {
    for (const repo of repoList) {
      const name = repo.name || String(repo);
      const branch = repo.default_branch || 'main';
      const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), name);

      broadcast(session, { type: 'pull_start', repo: name });
      if (!fs.existsSync(cloneDir)) {
        broadcast(session, { type: 'pull_done', repo: name, success: false, error: 'Not cloned locally' });
        continue;
      }
      try {
        const tokenUrl = `${sess.githubUrl.replace(/\/$/, '')}/${sess.org}/${name}.git`
          .replace('https://', `https://${sess.token}@`);

        // If there are local changes that would block the merge, stash them first
        // then restore after the pull (non-destructive).
        const status = await execQuiet(`git -C "${cloneDir}" status --porcelain`, { timeout: 5000 }).catch(() => '');
        const hasChanges = status.trim().length > 0;

        if (hasChanges) {
          await execQuiet(`git -C "${cloneDir}" stash --include-untracked`, { timeout: 15000 });
          try {
            await execQuiet(`git -C "${cloneDir}" pull "${tokenUrl}" ${branch}`, { timeout: 60000 });
          } finally {
            await execQuiet(`git -C "${cloneDir}" stash pop`, { timeout: 10000 }).catch(() => {});
          }
          broadcast(session, { type: 'pull_done', repo: name, success: true, note: 'Local changes were stashed and restored.' });
        } else {
          await execQuiet(`git -C "${cloneDir}" pull "${tokenUrl}" ${branch}`, { timeout: 60000 });
          broadcast(session, { type: 'pull_done', repo: name, success: true });
        }
      } catch (e) {
        broadcast(session, { type: 'pull_done', repo: name, success: false, error: e.message });
      }
    }
  })();
});

/**
 * GET /api/pick-directory
 * Opens a native Electron directory-picker dialog. Only works inside the
 * desktop app; returns { canceled: true } when run as a plain web server.
 */
app.get('/api/pick-directory', async (req, res) => {
  let dialog;
  try { dialog = require('electron').dialog; } catch (e) {}
  if (!dialog) return res.json({ canceled: true });
  try {
    const result = await dialog.showOpenDialog({
      properties: ['openDirectory', 'createDirectory'],
      title: 'Select clone base directory',
      buttonLabel: 'Select',
    });
    res.json(result);
  } catch (e) {
    res.json({ canceled: true, error: e.message });
  }
});

/**
 * GET /api/detect-tools
 * Auto-detects IntelliJ IDEA CLI and Java Home on the local machine.
 */
app.get('/api/detect-tools', async (req, res) => {
  const os = require('os');
  const homeDir = process.env.HOME || os.homedir();
  const tools = {};

  // Java Home — macOS utility gives the active JDK path
  try {
    const jh = await execQuiet('/usr/libexec/java_home 2>/dev/null', { timeout: 6000 });
    tools.javaHome = jh || null;
  } catch (e) { tools.javaHome = null; }

  // IntelliJ IDEA CLI — check the most common locations in priority order
  const ideaCandidates = [
    path.join(homeDir, 'Library/Application Support/JetBrains/Toolbox/scripts/idea'),
    '/usr/local/bin/idea',
    '/Applications/IntelliJ IDEA.app/Contents/MacOS/idea',
    '/Applications/IntelliJ IDEA CE.app/Contents/MacOS/idea',
    '/Applications/IntelliJ IDEA Ultimate.app/Contents/MacOS/idea',
  ];
  tools.intellijPath = ideaCandidates.find(p => fs.existsSync(p)) || null;

  // Also try `which idea` on PATH
  if (!tools.intellijPath) {
    try {
      const which = await execQuiet('which idea 2>/dev/null', { timeout: 4000 });
      if (which && fs.existsSync(which)) tools.intellijPath = which;
    } catch (e) {}
  }

  res.json(tools);
});

/**
 * GET /api/existing-repos?session=SID
 * Lists all directories inside the configured clone base that contain a .git
 * folder — i.e. repos that have already been set up locally.
 */
app.get('/api/existing-repos', async (req, res) => {
  const { session } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const base = sess.cloneDir.replace('~', process.env.HOME || '/tmp');
  if (!fs.existsSync(base)) return res.json({ repos: [] });

  try {
    const entries = fs.readdirSync(base);
    const repos = [];
    for (const d of entries) {
      const fullPath = path.join(base, d);
      try {
        if (!fs.statSync(fullPath).isDirectory()) continue;
        if (!fs.existsSync(path.join(fullPath, '.git'))) continue;
        let branch = 'unknown', lastCommit = null;
        try { branch     = await execQuiet(`git -C "${fullPath}" rev-parse --abbrev-ref HEAD`, { timeout: 5000 }); } catch (e) {}
        try { lastCommit = await execQuiet(`git -C "${fullPath}" log -1 --format=%ci`, { timeout: 5000 }); } catch (e) {}
        repos.push({ name: d, path: fullPath, branch, lastCommit });
      } catch (e) {}
    }
    res.json({ repos });
  } catch (e) {
    res.json({ repos: [], error: e.message });
  }
});

/**
 * GET /api/dependency-graph?session=SID
 * Scans cloned repos for pom.xml / package.json and returns a dependency graph.
 * Response: { nodes: [{name, language}], edges: [{from, to}] }  ("from depends on to")
 *
 * Accuracy strategy for Maven repos:
 *  1. Extract each repo's own groupId + artifactId.
 *  2. Detect the org groupId prefix (longest common prefix of all repo groupIds, e.g. "com.cainc").
 *  3. When scanning <dependency> blocks, skip any dep whose groupId does NOT start with the
 *     org prefix — this eliminates Spring, AWS, etc. entirely.
 *  4. Match the remaining (internal) dep's artifactId EXACTLY against known repos — no fuzzy
 *     substring matching which was the root cause of false positives.
 */
app.get('/api/dependency-graph',  _depGraphHandler);
app.post('/api/dependency-graph', _depGraphHandler);
async function _depGraphHandler(req, res) {
  const session     = req.query.session || req.body?.session;
  const refresh     = req.query.refresh || req.body?.refresh;
  const passedRepos = req.body?.repos;   // [{name, language}] passed from frontend allRepos
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!refresh && sess._depGraph) return res.json(sess._depGraph);

  const base = sess.cloneDir.replace('~', process.env.HOME || '/tmp');
  if (!fs.existsSync(base)) return res.json({ nodes: [], edges: [] });

  try {
    const entries  = fs.readdirSync(base);
    const repoNames = [];
    const repoMeta  = {}; // name -> { language, groupId, artifactId, pkgName }

    // ── Pass 1: collect repo metadata ────────────────────────────────────────
    for (const d of entries) {
      const fp = path.join(base, d);
      try {
        if (!fs.statSync(fp).isDirectory()) continue;
        if (!fs.existsSync(path.join(fp, '.git'))) continue;
        repoNames.push(d);
        let language = null, groupId = null, artifactId = null, pkgName = null;

        if (fs.existsSync(path.join(fp, 'pom.xml'))) {
          language = 'Java';
          try {
            const pom = fs.readFileSync(path.join(fp, 'pom.xml'), 'utf8');
            // Strip <parent> so we don't accidentally pick up the parent's groupId/artifactId
            const stripped = pom.replace(/<parent>[\s\S]*?<\/parent>/g, '');
            groupId    = stripped.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim()    || null;
            artifactId = stripped.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || null;
            // Fall back to parent groupId if own groupId is absent (inherited)
            if (!groupId) {
              groupId = pom.match(/<parent>[\s\S]*?<groupId>([^<]+)<\/groupId>[\s\S]*?<\/parent>/)?.[1]?.trim() || null;
            }
          } catch (_) {}
        } else if (fs.existsSync(path.join(fp, 'package.json'))) {
          language = 'JavaScript';
          try {
            const pkg = JSON.parse(fs.readFileSync(path.join(fp, 'package.json'), 'utf8'));
            pkgName = pkg.name || null;
          } catch (_) {}
        } else if (fs.existsSync(path.join(fp, 'build.gradle')) ||
                   fs.existsSync(path.join(fp, 'build.gradle.kts'))) {
          language = 'Kotlin';
        }
        repoMeta[d] = { language, groupId, artifactId, pkgName };
      } catch (_) {}
    }

    // ── Detect org groupId prefix ─────────────────────────────────────────────
    // Use majority-vote on the first 2 dot-segments so a single outlier repo
    // (e.g. "tests.selenium") doesn't break detection of the main org prefix.
    function detectOrgPrefix(ids) {
      const tally = {};
      for (const gid of ids) {
        const segs = gid.split('.');
        if (segs.length >= 2) {
          const p = segs.slice(0, 2).join('.');
          tally[p] = (tally[p] || 0) + 1;
        }
      }
      const sorted = Object.entries(tally).sort((a, b) => b[1] - a[1]);
      return (sorted[0] && sorted[0][1] >= 2) ? sorted[0][0] : null;
    }
    const repoGroupIds = Object.values(repoMeta).map(m => m.groupId).filter(Boolean);
    const orgPrefix    = detectOrgPrefix(repoGroupIds);   // e.g. "com.cainc"

    // ── Fetch ALL org repos from GitHub so lookup covers non-cloned repos too ──
    const apiBase   = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
    const ghHeaders = {
      Authorization: `token ${sess.token}`,
      Accept: 'application/vnd.github.v3+json',
      'User-Agent': 'iready-oasis/1.0',
    };
    let allOrgRepos = [];
    try {
      let page = 1;
      while (true) {
        const r = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
          headers: ghHeaders, params: { page, per_page: 100, type: 'all' }, timeout: 10000,
        });
        allOrgRepos = allOrgRepos.concat(r.data);
        if (!r.headers['link']?.includes('rel="next"')) break;
        page++;
      }
    } catch (_) {}

    // Seed repoMeta and repoNames for every org repo (not just cloned ones).
    // Prefer the list passed by the frontend (already loaded) to avoid a second
    // paginated fetch — fall back to what the GitHub API returned.
    const clonedSet = new Set(repoNames);
    const orgRepoSource = (passedRepos && passedRepos.length) ? passedRepos : allOrgRepos;
    for (const r of orgRepoSource) {
      if (!repoMeta[r.name]) {
        repoNames.push(r.name);
        repoMeta[r.name] = { language: r.language || null, artifactId: null, pkgName: null, groupId: null };
      }
    }

    // ── Build lookup from ALL known repo names + ALL submodule artifactIds ──────
    // For cloned repos, scan every pom.xml in the tree and map its artifactId to
    // the top-level repo directory name. This is what lets us resolve e.g.
    // "com.cainc.queuing:queuing-service-client" → "queuing-service" repo.
    const lookup = {};
    for (const [name, meta] of Object.entries(repoMeta)) {
      if (meta.artifactId) lookup[meta.artifactId.toLowerCase()] = name;
      if (meta.pkgName)    lookup[meta.pkgName.toLowerCase()]    = name;
      lookup[name.toLowerCase()] = name;
    }
    // Extra pass: scan all pom.xml files in every cloned repo and register every
    // <artifactId> found (stripped of the <parent> block) → parent repo name.
    for (const repoName of clonedSet) {
      const fp = path.join(base, repoName);
      for (const pomPath of findAllPoms(fp)) {
        try {
          const raw = fs.readFileSync(pomPath, 'utf8');
          // Skip the parent element so we don't accidentally capture the parent's artifactId
          const stripped = raw.replace(/<parent>[\s\S]*?<\/parent>/g, '');
          const aid = stripped.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim();
          if (aid && !lookup[aid.toLowerCase()]) {
            lookup[aid.toLowerCase()] = repoName;
          }
        } catch (_) {}
      }
    }

    const edges  = [];
    const edgeSet = new Set();
    const addEdge = (from, to) => {
      const k = `${from}→${to}`;
      if (!edgeSet.has(k)) { edgeSet.add(k); edges.push({ from, to }); }
    };

    // Collect all pom.xml paths within a repo directory, excluding build output and
    // hidden directories. Multi-module Maven projects (e.g. iready-core) have their
    // real <dependencies> in submodule pom.xml files, not the root aggregator.
    function findAllPoms(repoDir) {
      const SKIP = new Set(['target', 'node_modules', '.git', '.mvn', 'vendor', 'dist', 'build']);
      const results = [];
      function walk(dir, depth) {
        if (depth > 4) return;
        try {
          const pomPath = path.join(dir, 'pom.xml');
          if (fs.existsSync(pomPath)) results.push(pomPath);
          for (const entry of fs.readdirSync(dir)) {
            if (SKIP.has(entry) || entry.startsWith('.')) continue;
            const child = path.join(dir, entry);
            try { if (fs.statSync(child).isDirectory()) walk(child, depth + 1); } catch (_) {}
          }
        } catch (_) {}
      }
      walk(repoDir, 0);
      return results;
    }

    // Always filter by "com.cain" — covers com.cainc, com.cainc.iready, etc.
    const CAIN_PREFIX = 'com.cain';

    // Returns true when a dep should be included.
    // Accepts: literal com.cain* groupIds, inherited "${...}" expressions (common
    // in submodule pom.xml files), and empty groupIds — as long as the artifactId
    // is a known org repo.
    const isCainDep = (gid, aid) => {
      if (!aid) return false;
      const g = gid.toLowerCase();
      if (g.startsWith(CAIN_PREFIX)) return true;          // literal com.cain*
      if (!g || g.startsWith('${')) return !!lookup[aid.toLowerCase()]; // property/blank → trust lookup
      return false;
    };

    // ── Pass 2: extract dependencies ──────────────────────────────────────────
    for (const d of repoNames) {
      const fp = path.join(base, d);

      // Maven: scan ALL pom.xml files in the repo (root + every submodule).
      // Each pom.xml is scanned independently; deps in any submodule count as a
      // dep of the top-level repo (the directory that was cloned).
      const pomFiles = findAllPoms(fp);
      if (d === 'iready-core') console.log(`[dep-debug] iready-core: found ${pomFiles.length} pom.xml files:`, pomFiles.map(p => p.replace(base + '/', '')));
      for (const pomPath of pomFiles) {
        try {
          const pom = fs.readFileSync(pomPath, 'utf8');
          const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
          const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
          for (const sec of sections) {
            const depBlocks = sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [];
            for (const dep of depBlocks) {
              const depGid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim()    || '';
              const depAid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
              if (!isCainDep(depGid, depAid)) continue;
              const target = lookup[depAid.toLowerCase()];
              if (d === 'iready-core') console.log(`[dep-debug] iready-core: ${depGid}:${depAid} → target=${target}`);
              if (target && target !== d) addEdge(d, target);
            }
          }
        } catch (_) {}
      }

      // Node.js: exact package name match against other repos' pkgName or dir name
      const pkgPath = path.join(fp, 'package.json');
      if (fs.existsSync(pkgPath)) {
        try {
          const pkg     = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
          const allDeps = Object.assign({}, pkg.dependencies, pkg.devDependencies, pkg.peerDependencies);
          for (const depName of Object.keys(allDeps)) {
            const bare   = depName.replace(/^@[^/]+\//, ''); // strip @scope/
            const target = lookup[depName.toLowerCase()] || lookup[bare.toLowerCase()];
            if (target && target !== d) addEdge(d, target);
          }
        } catch (_) {}
      }
    }

    // ── Dependency map: repo → ["groupId:artifactId", ...] for all com.cain* deps ─
    const depMap = {};
    for (const d of repoNames) {
      const fp   = path.join(base, d);
      const deps = new Set();
      for (const pomPath of findAllPoms(fp)) {
        try {
          const pom = fs.readFileSync(pomPath, 'utf8');
          const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
          const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
          for (const sec of sections) {
            const depBlocks = sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [];
            for (const dep of depBlocks) {
              const gid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
              const aid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
              if (!isCainDep(gid, aid)) continue;
              deps.add(`${gid}:${aid}`);
            }
          }
        } catch (_) {}
      }
      if (deps.size) depMap[d] = [...deps].sort();
    }

    // ── Fetch pom.xml for non-cloned repos from GitHub API ────────────────────
    const nonCloned = allOrgRepos.filter(r => !clonedSet.has(r.name));

    // Fetch pom.xml for non-cloned repos concurrently (10 at a time)
    // Semaphore: allows up to MAX_CONCURRENT GitHub API calls at any time
    const MAX_CONCURRENT = 50;
    let _active = 0;
    const _queue = [];
    const throttle = (fn) => new Promise((resolve, reject) => {
      const run = async () => {
        _active++;
        try { resolve(await fn()); } catch (e) { reject(e); } finally {
          _active--;
          if (_queue.length) _queue.shift()();
        }
      };
      _active < MAX_CONCURRENT ? run() : _queue.push(run);
    });
    // Helper: decode a GitHub contents API response to pom.xml text
    const decodePom = (data) => {
      const c = data?.content;
      return c ? Buffer.from(c.replace(/\n/g, ''), 'base64').toString('utf8') : null;
    };

    // Helper: extract com.cain* deps from a pom.xml string
    const extractCainDeps = (pom) => {
      const deps = new Set();
      const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
      const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
      for (const sec of sections) {
        for (const dep of (sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [])) {
          const gid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
          const aid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
          if (isCainDep(gid, aid)) deps.add(`${gid}:${aid}`);
        }
      }
      return deps;
    };

    // Helper: fetch a file from GitHub contents API (throttled)
    const ghFetch = async (repoName, filePath) => throttle(async () => {
      try {
        const r = await axios.get(
          `${apiBase}/repos/${sess.org}/${repoName}/contents/${filePath}`,
          { headers: ghHeaders, timeout: 8000 }
        );
        return r.data;
      } catch (_) { return null; }
    });

    // Process ALL non-cloned repos in parallel — throttle controls the concurrency.
    // Fetch root pom.xml + direct module pom.xml files (1 level deep).
    // No deeper recursion — keeps API calls at O(N + N×modules) which is fast enough.
    await Promise.all(nonCloned.map(async repo => {
        try {
          const rootData = await ghFetch(repo.name, 'pom.xml');
          const rootPom  = rootData ? decodePom(rootData) : null;
          if (!rootPom) return;

          const allDeps = new Set();
          for (const d of extractCainDeps(rootPom)) allDeps.add(d);

          // Fetch each declared module's pom.xml (1 level only)
          const modules = [...rootPom.matchAll(/<module>([^<]+)<\/module>/g)].map(m => m[1].trim());
          if (modules.length) {
            await Promise.all(modules.map(async mod => {
              const modData = await ghFetch(repo.name, `${mod}/pom.xml`);
              const modPom  = modData ? decodePom(modData) : null;
              if (modPom) for (const d of extractCainDeps(modPom)) allDeps.add(d);
            }));
          }

          if (allDeps.size) {
            depMap[repo.name] = [...new Set([...(depMap[repo.name] || []), ...allDeps])].sort();
            if (!repoNames.includes(repo.name)) {
              repoNames.push(repo.name);
              repoMeta[repo.name] = { language: repo.language || null };
            }
            for (const dep of allDeps) {
              const aid    = dep.split(':')[1] || '';
              const target = lookup[aid.toLowerCase()];
              if (target && target !== repo.name) addEdge(repo.name, target);
            }
          }
        } catch (_) {}
    }));

    console.log(`[depmap] ${Object.keys(depMap).length} repos with com.cain* deps | ${edges.length} edges | ${nonCloned.length} fetched from GitHub`);

    const nodes = repoNames.map(name => ({ name, language: repoMeta[name]?.language || null, cloned: clonedSet.has(name) }));
    const result = { nodes, edges, orgPrefix: orgPrefix || null, depMap };
    sess._depGraph = result;   // cache for this session
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

/**
 * POST /api/delete-repo
 * Body: { session, repo }
 * Deletes the local clone directory for the given repo (irreversible).
 * Safety check: the resolved path must be a direct child of the configured cloneDir.
 */
app.post('/api/delete-repo', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo || /[/\\]/.test(repo)) return res.status(400).json({ error: 'Invalid repo name' });

  const base     = sess.cloneDir.replace('~', process.env.HOME || '/tmp');
  const cloneDir = path.join(base, repo);

  // Must be a direct child — no traversal
  if (path.dirname(cloneDir) !== base) return res.status(400).json({ error: 'Invalid path' });
  if (!fs.existsSync(cloneDir)) return res.json({ ok: true });

  try {
    fs.rmSync(cloneDir, { recursive: true, force: true });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /api/refresh-credentials
 * Refreshes AWS SSO credentials so Bedrock becomes available.
 * Spawns the refresh script with the user's full login environment so that
 * `aws`, `python3` etc. are on PATH. `aws sso login` opens the system
 * browser automatically — no terminal required.
 */
app.post('/api/refresh-credentials', async (req, res) => {
  const { session } = req.body;
  if (!sessions[session]) return res.status(401).json({ error: 'Invalid session' });

  const scriptPath = path.join(SCRIPTS_DIR, 'refresh-aws-creds.sh');
  if (!fs.existsSync(scriptPath)) {
    return res.status(404).json({ error: 'Credential refresh script not found.' });
  }

  // Resolve the user's interactive login environment so tools installed via
  // Homebrew, nvm, SDKMAN etc. are on PATH — the same as opening Terminal.
  const loginEnv = await getLoginEnv();

  return new Promise(resolve => {
    const proc = spawn('bash', [scriptPath], {
      env: loginEnv,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let out = '';
    proc.stdout.on('data', d => { out += d; });
    proc.stderr.on('data', d => { out += d; });

    // 3-minute timeout — SSO browser login can take a while
    const timer = setTimeout(() => { proc.kill(); }, 180000);

    proc.on('close', code => {
      clearTimeout(timer);
      const snippet = out.slice(-600);
      if (code === 0) {
        res.json({ ok: true, output: snippet });
      } else if (code === 3) {
        // Exit 3 = SSO expired but non-interactive flag prevented login
        // This shouldn't happen since we removed OASIS_NONINTERACTIVE,
        // but handle it gracefully.
        res.json({ ok: false, ssoRequired: true, output: snippet });
      } else {
        res.status(500).json({ ok: false, error: snippet || `Exit code ${code}` });
      }
      resolve();
    });
  });
});

// ── Project chat ──────────────────────────────────────────────────────────

const CHAT_SYSTEM_PROMPT = (repo) =>
  `You are a developer assistant helping explain the "${repo}" project from the i-Ready (Curriculum Associates) ` +
  `GitHub Enterprise organization. Answer questions about architecture, how the code works, development flow, ` +
  `setup steps, and any technical questions. Be concise and practical. Use the project context below when available. ` +
  `If something is not covered by the context, say you are not sure rather than guessing.`;

function getProjectContext(sess, repo) {
  const cloneDir = path.join(sess.cloneDir.replace('~', process.env.HOME || '/tmp'), repo);
  if (!fs.existsSync(cloneDir)) return null;

  let ctx = '';

  for (const f of ['README.md', 'readme.md', 'README.txt', 'README']) {
    const p = path.join(cloneDir, f);
    if (fs.existsSync(p)) {
      ctx += `\n\n--- README ---\n${fs.readFileSync(p, 'utf8').slice(0, 4000)}`;
      break;
    }
  }

  const pkg = path.join(cloneDir, 'package.json');
  if (fs.existsSync(pkg)) {
    try {
      const j = JSON.parse(fs.readFileSync(pkg, 'utf8'));
      ctx += `\n\n--- package.json ---\nname: ${j.name || ''}\ndescription: ${j.description || ''}\n` +
             `scripts: ${JSON.stringify(j.scripts || {}, null, 2)}`;
    } catch (e) {}
  }

  const pom = path.join(cloneDir, 'pom.xml');
  if (fs.existsSync(pom)) ctx += `\n\n--- pom.xml (partial) ---\n${fs.readFileSync(pom, 'utf8').slice(0, 1500)}`;

  try {
    const ignore = new Set(['node_modules', 'target', 'build', 'dist', '.git', '.idea']);
    const entries = fs.readdirSync(cloneDir).filter(e => !e.startsWith('.') && !ignore.has(e));
    ctx += `\n\n--- Top-level structure ---\n${entries.join(', ')}`;
    for (const dir of entries.slice(0, 5)) {
      const dp = path.join(cloneDir, dir);
      try {
        if (fs.statSync(dp).isDirectory()) {
          const sub = fs.readdirSync(dp).filter(e => !e.startsWith('.')).slice(0, 10);
          ctx += `\n${dir}/: ${sub.join(', ')}`;
        }
      } catch (e) {}
    }
  } catch (e) {}

  return ctx || null;
}

function heuristicChatReply(repo, messages) {
  const q = ((messages || []).slice(-1)[0]?.content || '').toLowerCase();
  if (/how.*work|architecture|flow|explain|overview|structure/i.test(q)) {
    return `**${repo}** — offline overview\n\n` +
      `- Check **README.md** in the cloned repo for the architecture overview\n` +
      `- Look at the top-level **src/** folder structure for package layout\n` +
      `- Setup logs (expand the job card) show the exact Maven/npm steps run\n\n` +
      `_AI-powered answers are unavailable right now — click **Refresh AWS Credentials** to enable them._`;
  }
  if (/setup|install|run|start|build/i.test(q)) {
    return `**Setup steps for ${repo}:**\n` +
      `1. Select it in the repo list and click **Setup Workspace**\n` +
      `2. The setup script handles Maven/npm install automatically\n` +
      `3. Check **README.md** in the repo for any extra manual steps\n\n` +
      `_AI-powered answers are unavailable right now — click **Refresh AWS Credentials** to enable them._`;
  }
  return `AI-powered answers for **${repo}** are temporarily unavailable.\n\n` +
    `Your AWS Bedrock credentials may have expired. Click **Refresh AWS Credentials** below to renew them automatically, then ask again.`;
}

/**
 * POST /api/chat
 * Body: { session, repo, messages: [{role, content}] }
 * Multi-turn chat about a project. Uses Claude on Bedrock when configured,
 * falls back to heuristic replies otherwise.
 */
app.post('/api/chat', async (req, res) => {
  const { session, repo, messages } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'repo and messages are required' });
  }

  const context = getProjectContext(sess, repo);
  const systemText = CHAT_SYSTEM_PROMPT(repo) +
    (context
      ? `\n\nProject context:${context}`
      : '\n\n(Note: this project has not been cloned locally yet — limited context available.)');

  const convMessages = messages
    .map(m => ({ role: m.role, content: [{ text: String(m.content || '').slice(0, 4000) }] }))
    .slice(-20);

  const cfg = loadConfig();
  const modelId = cfg?.bedrock?.model?.arn || cfg?.bedrock?.model?.id;
  const aiEnabled = cfg?.suggestions?.enabled !== false && !!modelId;

  if (aiEnabled) {
    try {
      const { BedrockRuntimeClient, ConverseCommand } = require('@aws-sdk/client-bedrock-runtime');
      const region = cfg?.aws?.region || process.env.AWS_REGION || 'us-east-1';
      const clientCfg = { region };
      if (cfg?.aws?.profile) {
        const { fromIni } = require('@aws-sdk/credential-providers');
        clientCfg.credentials = fromIni({ profile: cfg.aws.profile });
      }
      const client = new BedrockRuntimeClient(clientCfg);
      const maxTokens = Math.min(Number(cfg?.bedrock?.['max-tokens']) || 2048, 2048);
      const resp = await client.send(new ConverseCommand({
        modelId,
        system: [{ text: systemText }],
        messages: convMessages,
        inferenceConfig: { maxTokens, temperature: 0.3 },
      }));
      const blocks = resp?.output?.message?.content || [];
      const reply = blocks.map(b => b.text).filter(Boolean).join('\n').trim();
      if (!reply) throw new Error('Empty response');
      return res.json({ reply, source: 'bedrock' });
    } catch (e) {
      if (isAccessError(e)) {
        return res.json({ reply: heuristicChatReply(repo, messages), source: 'generic', reason: 'no-access' });
      }
      console.warn('Chat Bedrock error:', e.message);
    }
  }

  res.json({ reply: heuristicChatReply(repo, messages), source: 'generic' });
});

// ── Serve index for all unmatched routes ──────────────────────────────────
app.get('*', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

// ── Start ─────────────────────────────────────────────────────────────────
// Listen on the given port (0 = OS-assigned free port) and resolve with the
// actual URL. Used both by the CLI (`npm start`) and the Electron main process.
function start(port = PORT) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, () => {
      const actualPort = server.address().port;
      console.log(`\n  ⚡ i-Ready OASIS running at http://localhost:${actualPort}\n`);
      resolve({ server, port: actualPort, url: `http://localhost:${actualPort}` });
    });
  });
}

// Run directly via `node server/index.js`; when required (Electron) just export.
if (require.main === module) {
  start();
}

module.exports = { app, server, start };
