const WebSocket = require('ws');

const WS_URL = process.argv[2];
if (!WS_URL) { console.error('Usage: node cdp_driver.js <ws-url>'); process.exit(1); }

let msgId = 1;
const pending = new Map();

const ws = new WebSocket(WS_URL);
ws.on('message', raw => {
  const msg = JSON.parse(raw);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id);
    pending.delete(msg.id);
    if (msg.error) reject(new Error(msg.error.message));
    else resolve(msg.result);
  }
});

function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = msgId++;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
    setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); reject(new Error(`Timeout: ${method}`)); }
    }, 15000);
  });
}

async function evaluate(expression, awaitPromise = false) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || 'JS error');
  return r.result?.value;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function screenshot(path) {
  const { data } = await send('Page.captureScreenshot', { format: 'png', quality: 90 });
  require('fs').writeFileSync(path, Buffer.from(data, 'base64'));
  console.log('Screenshot:', path);
}

ws.on('open', async () => {
  try {
    await send('Runtime.enable');

    // ── Navigate to Local Repos tab ────────────────────────────────────
    console.log('\n=== Navigating to Local Repos tab ===');
    await evaluate(`
      const tab = [...document.querySelectorAll('.tab-btn')].find(el => el.textContent.trim().includes('Local Repos'));
      if (tab) tab.click();
      tab ? 'clicked' : 'not found'
    `);
    await sleep(2000);
    await screenshot('/tmp/local_repos_tab.png');

    // ── Check pull badges ──────────────────────────────────────────────
    console.log('\n=== Checking pull badges ===');
    const badges = await evaluate(`
      const badges = [...document.querySelectorAll('.proj-pull-badge')];
      JSON.stringify(badges.map(b => ({
        id: b.id,
        text: b.textContent.trim(),
        cls: b.className,
        canPull: b.className.includes('can-pull')
      })))
    `);
    const badgeData = JSON.parse(badges || '[]');
    console.log('Pull badges found:', badgeData.length);
    badgeData.forEach(b => console.log(' -', b.id, '|', b.text, '|', b.cls));

    // ── Find a "can-pull" badge and click it ───────────────────────────
    const pullable = badgeData.filter(b => b.canPull);
    if (pullable.length > 0) {
      const target = pullable[0];
      console.log(`\n=== Clicking pull on: ${target.id} ===`);

      // Set up console listener to catch toast messages
      const logs = [];
      ws.on('message', raw => {
        const m = JSON.parse(raw);
        if (m.method === 'Runtime.consoleAPICalled') {
          logs.push(m.params.args.map(a => a.value || a.description).join(' '));
        }
      });
      await send('Runtime.enable');

      await evaluate(`document.getElementById('${target.id}').click()`);
      console.log('Clicked pull badge, waiting for result...');
      await sleep(4000);
      await screenshot('/tmp/after_pull_click.png');

      // Check toast
      const toast = await evaluate(`
        const t = document.querySelector('.toast-container .toast, .toast');
        t ? JSON.stringify({ text: t.textContent.trim(), cls: t.className }) : null
      `);
      console.log('Toast after pull:', toast);

      // Check if badge changed
      const badgeAfter = await evaluate(`
        const el = document.getElementById('${target.id}');
        el ? JSON.stringify({ text: el.textContent.trim(), cls: el.className }) : null
      `);
      console.log('Badge state after click:', badgeAfter);
    } else {
      console.log('No "can-pull" badges found — all repos up to date or not cloned');
      console.log('Checking for any badges in "checking" state...');
      const checking = badgeData.filter(b => b.cls.includes('checking'));
      console.log('Checking state badges:', checking.length);
    }

    // ── Navigate to JIRA tab ───────────────────────────────────────────
    console.log('\n=== Navigating to JIRA tab ===');
    await evaluate(`
      const tab = [...document.querySelectorAll('.tab-btn')].find(el => el.textContent.trim() === 'JIRA');
      if (tab) tab.click();
      tab ? 'clicked' : 'not found'
    `);
    await sleep(2000);
    await screenshot('/tmp/jira_tab.png');

    // ── Check JIRA pull chips ──────────────────────────────────────────
    console.log('\n=== Checking JIRA pull chips ===');
    const jiraChips = await evaluate(`
      const chips = [...document.querySelectorAll('.jt-wr-behind')];
      JSON.stringify(chips.map(c => ({ text: c.textContent.trim(), onclick: c.getAttribute('onclick') })))
    `);
    const chipData = JSON.parse(jiraChips || '[]');
    console.log('JIRA pull-behind chips:', chipData.length);
    chipData.slice(0, 3).forEach(c => console.log(' -', c.text, '|', c.onclick));

    const syncedChips = await evaluate(`
      const chips = [...document.querySelectorAll('.jt-wr-ok')];
      chips.length
    `);
    console.log('JIRA synced chips:', syncedChips);

    await screenshot('/tmp/jira_tab_final.png');
    console.log('\n=== Done ===');

  } catch (e) {
    console.error('Error:', e.message);
  } finally {
    ws.close();
  }
});
