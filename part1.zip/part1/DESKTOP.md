# i-Ready OASIS — Desktop App (Mac/Windows) & Auto-Update

OASIS ships as a native desktop app built with **Electron**:

- macOS → `.dmg` installer
- Windows → `.exe` (NSIS) installer
- **Auto-update** via `electron-updater` — installed apps check an internal feed, download new versions, and prompt the user to restart.

Execution stays **local**: the app boots the embedded Express/WebSocket server on a free localhost port inside the user's machine, so `git clone`, Maven/npm builds, and "Open in IntelliJ" all run on the user's own computer (same as the dev `npm start` flow).

---

## How it fits together

```
i-Ready OASIS.app / .exe
└─ Electron main (electron/main.js)
   ├─ starts server/index.js on 127.0.0.1:<free-port>
   ├─ opens a window → http://localhost:<port>   (the existing web UI)
   └─ electron-updater → checks feed, downloads, prompts "Restart to update"
```

- **Scripts** (`scripts/<repo>.sh`, `setup.sh`) are shipped as `extraResources` and
  seeded into a writable per-user folder on first launch:
  `~/Library/Application Support/i-Ready OASIS/scripts` (mac) /
  `%APPDATA%\i-Ready OASIS\scripts` (win). Users can add their own `<repo>.sh`
  there and it persists across updates.

---

## Build locally

```bash
npm install

# Run the desktop app in dev (no installer)
npm run electron

# Build the macOS installer into ./release
npm run dist:mac     # .dmg + .zip   (must run on macOS)

# (Windows is deferred — `npm run dist:win` exists but isn't part of the pipeline yet)
```

> A `.dmg` can only be built on macOS. The CI workflow builds it on a self-hosted
> macOS runner from a tag push.

---

## Publishing updates

Updates are distributed through an **internal feed** (configured in `package.json`
→ `build.publish`, currently the Nexus raw repo `https://nexus.cainc.com/repository/oasis/`).
electron-builder produces the installers plus the metadata files
`latest-mac.yml` / `latest.yml` (+ `.blockmap`) that the updater reads.

### Cut a release

1. Bump the version in `package.json` (e.g. `1.0.0` → `1.1.0`).
2. Commit and tag: `git tag v1.1.0 && git push origin v1.1.0`.
3. The **Release OASIS** GitHub Action builds mac + win and uploads the
   installers and `latest*.yml` to the feed.

### What users experience

- On launch (and every 4h while open) the app checks the feed.
- A newer version downloads in the background.
- The user gets a **"Update ready — Restart now / Later"** dialog.
  Choosing *Later* applies the update on next quit.
- There's also **Help → Check for Updates…** (App menu on mac) for a manual check.

To publish an update, you only ever **bump the version + push a tag**. No user
reinstall needed.

---

## ⚠️ Prerequisites that need IT / org sign-off

These are real blockers for a smooth rollout — coordinate via the CA IT Helpdesk
(cainc.service-now.com) before first release:

1. **macOS code signing + notarization (required for auto-update).**
   macOS auto-update only applies if the app is signed with an **Apple Developer ID**
   and **notarized**. Without it, updates silently fail and Gatekeeper blocks launch.
   The notarization hook is already scaffolded (see below) — IT just needs to provide
   the Developer ID cert and notary credentials as CI secrets.

2. **Windows code signing (strongly recommended).**
   Unsigned `.exe` triggers SmartScreen warnings. Needs a code-signing cert
   (`WIN_CSC_LINK`/`WIN_CSC_KEY_PASSWORD`). NSIS auto-update works either way.

3. **Update host.** Confirm the feed URL/credentials with IT. The config assumes a
   Nexus raw repo; an internal HTTPS/S3 bucket works too (electron-updater
   `generic`/`s3` providers). Avoid publishing this internal tool to public
   github.com releases.

4. **App icon.** Add a square icon at `build/icon.png` (≥512×512). electron-builder
   derives `.icns`/`.ico` from it. (The current i-Ready logo is a wide wordmark, not
   a square icon.)

---

## Internal-only (no external dependencies)

This is an **internal CA tool — not for outside use**. The app makes **no external
runtime calls**:

- Talks only to your **GitHub Enterprise** (`github.cainc.com`) and the **internal
  update feed** (`nexus.cainc.com`). No public github.com publishing.
- **Fonts are system fonts** (the Google Fonts CDN link was removed), so the UI
  works fully offline.

**Build pipeline is wired to Nexus** (no public sources):

- `.npmrc` (committed) points the **npm registry**, **`electron_mirror`**, and
  **`electron_builder_binaries_mirror`** at Nexus. Provide `NPM_TOKEN` via env for
  auth (never commit a token). Confirm the exact Nexus repo paths with IT.
- CI (`.github/workflows/release.yml`) runs on a **self-hosted macOS runner**
  (`[self-hosted, macOS]`) and also sets `ELECTRON_MIRROR` /
  `ELECTRON_BUILDER_BINARIES_MIRROR` for the build step.
- For full air-gap, mirror the marketplace actions (`actions/checkout`,
  `actions/setup-node`) into your internal Actions instance.

### Windows — deferred

Windows packaging is intentionally **not built yet**. The `win`/`nsis` config still
exists in `package.json` for later; to enable it, add a `build-win` job (on a
self-hosted Windows runner) mirroring the mac job, with a Windows code-signing cert.

## macOS signing & notarization (scaffolded)

The pieces are in place; only the credentials are missing.

- **Hardened runtime + entitlements** — enabled in `package.json` (`mac.hardenedRuntime`,
  `mac.entitlements` → `build/entitlements.mac.plist`). The entitlements allow Electron's
  JIT and let OASIS spawn toolchains (git/mvn/npm) — notarization requires this.
- **afterSign hook** — `build/notarize.js` runs after signing, submits the app via
  `notarytool`, and staples the ticket. It **skips cleanly when no credentials are set**,
  so local `npm run dist:mac` still works (produces an un-notarized app for testing).
- **Dependency** — `@electron/notarize` is in `devDependencies`; it's pulled by
  `npm ci` (from Nexus) in CI. Local skip-path doesn't require it.

### Credentials to supply (CI secrets)

First, the signing cert (already referenced by the workflow):
`MAC_CSC_LINK` (base64 of the Developer ID `.p12`) and `MAC_CSC_KEY_PASSWORD`.

Then **one** of these notary credential sets (the hook supports both):

| Option | Env vars |
|--------|----------|
| App Store Connect API key (recommended) | `APPLE_API_KEY` (path to `.p8`), `APPLE_API_KEY_ID`, `APPLE_API_ISSUER` |
| Apple ID + app-specific password | `APPLE_ID`, `APPLE_APP_SPECIFIC_PASSWORD`, `APPLE_TEAM_ID` |

The release workflow passes **both** sets (whichever is populated wins).

👉 **See [`SIGNING.md`](./SIGNING.md)** for the exact commands to produce these
credentials (export the `.p12`, base64-encode it, generate the App Store Connect API
key) and store them as CI secrets.

Test a signed+notarized build locally:

```bash
export CSC_LINK=... CSC_KEY_PASSWORD=...
export APPLE_ID=... APPLE_APP_SPECIFIC_PASSWORD=... APPLE_TEAM_ID=...
npm run dist:mac
# watch for "Notarizing … via notarytool" → "Notarization complete (ticket stapled)."
```

## Notes

- `node-pty` and `archiver` were removed (unused) so the app is pure-JS — no native
  module rebuilds needed for Electron.
- The auto-updater is disabled in `npm run electron` (dev) and only active in a
  packaged, installed build.
