// =============================================================================
// Settings — credentials/config modal, AI-powered setup-script generator
// =============================================================================
function openSettings() {
  const body = document.getElementById('settings-body');
  body.innerHTML = `
    <div class="wiz-section-label" style="margin-top:0">GitHub Connection</div>
    <div class="field">
      <label>GitHub Enterprise URL <span class="req">*</span></label>
      <input class="s-ghurl" type="text" value="${escHtml(cfg.githubUrl || '')}"/>
    </div>
    <div class="field">
      <label>Organization <span class="req">*</span></label>
      <input class="s-org" type="text" value="${escHtml(cfg.org || '')}"/>
    </div>
    <div class="field">
      <label>Personal Access Token</label>
      <input class="s-token" type="password" placeholder="Leave blank to keep existing token"/>
    </div>

    <div class="wiz-section-label">Clone Directory</div>
    <div class="field">
      <label>Base Directory <span class="req">*</span></label>
      <div class="input-with-btn">
        <input class="s-dir" id="s-dir-input" type="text" value="${escHtml(cfg.cloneDir || '~/dev/projects/iready')}"/>
        <button class="btn btn-ghost btn-sm" type="button" onclick="browseDirectory('s-dir-input')" style="flex-shrink:0">Browse…</button>
      </div>
      <div class="field-hint">Each repo is cloned into a subdirectory here</div>
    </div>

    <div class="wiz-section-label">
      Development Tools
      <button class="btn btn-ghost btn-sm" id="s-detect-btn" type="button"
        onclick="detectTools('s-ij-input','s-java-input')"
        style="margin-left:auto;font-size:11px;padding:2px 10px">⚡ Auto-detect</button>
    </div>
    <div class="field-row">
      <div class="field">
        <label>IntelliJ IDEA CLI <span class="opt">optional</span></label>
        <input class="s-ij" id="s-ij-input" type="text" value="${escHtml(cfg.intellijPath || '')}" placeholder="/usr/local/bin/idea"/>
        <div class="field-hint">Tools → Create Command-line Launcher in IDEA</div>
      </div>
      <div class="field">
        <label>Java Home <span class="opt">optional</span></label>
        <input class="s-java" id="s-java-input" type="text" value="${escHtml(cfg.javaHome || '')}" placeholder="auto-detected"/>
        <div class="field-hint"><code>/usr/libexec/java_home -V</code> lists installed JDKs</div>
      </div>
    </div>

    <div class="wiz-section-label">Build Config</div>
    <div class="field">
      <label>Maven Extra Arguments <span class="opt">optional</span></label>
      <input class="s-mvn" type="text" value="${escHtml(cfg.mavenArgs || '')}" placeholder="-DskipTests -Plocal-dev"/>
      <div class="field-hint">Appended to <code>mvn clean install</code> for Java projects</div>
    </div>
    <div class="field">
      <label>Extra Environment Variables <span class="opt">optional</span></label>
      <textarea class="s-env" rows="4">${escHtml(cfg.extraEnv || '')}</textarea>
      <div class="field-hint">KEY=VALUE one per line — written to <code>.env</code> in each project</div>
    </div>

    <div class="wiz-section-label">AWS</div>
    <div class="field">
      <label>AWS Profile <span class="opt">optional</span></label>
      <select class="s-aws" id="s-aws-select">
        <option value="${escHtml(cfg.awsProfile || '')}" selected>${escHtml(cfg.awsProfile || 'default')}</option>
      </select>
      <div class="field-hint">Profile used to load credentials when launching apps · <code>aws sso login</code> runs automatically if the session is expired</div>
    </div>

    <div class="wiz-section-label">Jenkins</div>
    <div class="field">
      <label>Jenkins API Token <span class="req">*</span></label>
      <input class="s-jenkins-token" type="password" placeholder="${loadJenkinsCredentials()?.token ? '●●●●●●●● (saved — leave blank to keep)' : 'Required — paste your Jenkins API token'}"/>
      <div class="field-hint">Saved on this device and reused · <a href="https://jenkins2.cainc.com/me/configure" target="_blank" style="color:var(--accent)">↗ Generate token</a></div>
    </div>

    <div class="wiz-section-label" id="settings-jira-section">JIRA</div>
    <div class="jira-settings-status" id="jira-settings-status">
      ${_jiraConfigured
        ? `<span class="jira-status-connected">✓ Connected${_jiraData?.jiraEmail ? ' as <strong>' + escHtml(_jiraData.jiraEmail) + '</strong>' : ''}</span>`
        : `<span class="jira-status-none">Not connected</span>`}
    </div>
    <div class="field">
      <label>JIRA URL</label>
      <input class="s-jira-url" id="s-jira-url-input" type="url" value="${escHtml(_jiraData?.jiraUrl || '')}" placeholder="https://jira.yourcompany.com"/>
    </div>
    <div class="field">
      <label>API Token</label>
      <input class="s-jira-token" id="s-jira-token-input" type="password" placeholder="${loadJiraCookie() ? '●●●●●●●● (saved — leave blank to keep)' : 'Paste Atlassian API token'}"/>
      <div class="field-hint"><span class="link-text" onclick="openJiraTokenPage()">Generate token at id.atlassian.com ↗</span></div>
    </div>
    <div class="field">
      <label>Story Points Field <span class="opt">optional</span></label>
      <input class="s-jira-pts" id="s-jira-pts-input" type="text" value="${escHtml(_jiraData?.jiraPointsField || '')}" placeholder="story_points or customfield_10016"/>
    </div>
    <div class="jira-settings-actions">
      <button class="btn btn-primary btn-sm" type="button" id="s-jira-connect-btn" onclick="settingsConnectJira()">Connect &amp; Verify</button>
      ${_jiraConfigured ? `<button class="btn btn-ghost btn-sm" type="button" onclick="disconnectJira()" style="color:var(--red)">Disconnect</button>` : ''}
    </div>
    <div id="s-jira-msg" class="field-hint" style="margin-top:6px;min-height:18px"></div>

    <div class="wiz-section-label">Mac Password</div>
    <div class="field">
      <label>Login Password <span class="opt">optional</span></label>
      <div class="input-with-btn">
        <input class="s-macpw" id="s-macpw-input" type="password" placeholder="${loadSudoPassword() ? '●●●●●●●● (saved)' : 'Enter to pre-authorize sudo for setup scripts'}"/>
        <button class="btn btn-ghost btn-sm" type="button" id="s-macpw-verify-btn" onclick="verifySudoPassword()" style="flex-shrink:0">Verify</button>
      </div>
      <label class="check-row" style="margin-top:8px;display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);cursor:pointer">
        <input type="checkbox" id="s-macpw-remember" ${loadSudoPassword() ? 'checked' : ''}/>
        Save password on this device
      </label>
      <div class="field-hint" id="s-macpw-hint" style="margin-top:6px">${loadSudoPassword() ? '✓ Password saved — will be applied automatically on next launch.' : 'Used locally for <code>sudo</code> during setup only.'}</div>
    </div>`;
  document.getElementById('settings-modal').classList.remove('hidden');
  populateAwsProfiles(cfg.awsProfile);
}

// Fill the AWS profile dropdown from the machine's configured profiles. Keeps
// the currently-selected value even if it isn't in the list, and falls back to
// just "default" when the AWS CLI isn't installed/configured.
async function populateAwsProfiles(selected) {
  const sel = document.getElementById('s-aws-select');
  if (!sel) return;
  const cur = (selected || 'default');
  try {
    const resp = await fetch(`${API}/api/aws-profiles`);
    const { profiles = [] } = await resp.json();
    const list = profiles.length ? profiles.slice() : [];
    if (!list.includes('default')) list.unshift('default');
    if (cur && !list.includes(cur)) list.unshift(cur);
    sel.innerHTML = list.map(p => `<option value="${escHtml(p)}" ${p === cur ? 'selected' : ''}>${escHtml(p)}</option>`).join('');
  } catch (_) { /* keep the single fallback option already rendered */ }
}

async function saveSettings() {
  const body = document.getElementById('settings-body');
  const get = cls => body.querySelector('.' + cls)?.value?.trim() || '';
  cfg.githubUrl    = get('s-ghurl')  || cfg.githubUrl;
  cfg.org          = get('s-org')    || cfg.org;
  const tok        = get('s-token');
  if (tok) {
    cfg.token = tok;
    // If the PAT is being remembered, keep the cookie in sync with the new value
    if (getCookie(TOKEN_COOKIE)) setCookie(TOKEN_COOKIE, tok, TOKEN_COOKIE_DAYS);
  }
  cfg.cloneDir       = get('s-dir')  || cfg.cloneDir;
  cfg.intellijPath   = get('s-ij')   || '';
  cfg.javaHome       = get('s-java') || '';
  cfg.mavenArgs      = get('s-mvn')  || '';
  cfg.extraEnv       = get('s-env')  || '';
  cfg.awsProfile     = get('s-aws')    || '';
  const jTok = get('s-jenkins-token');
  if (jTok) { cfg.jenkinsToken = jTok; saveJenkinsCredentials({ token: jTok }); }

  // Re-create session
  const resp = await fetch(`${API}/api/session`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cfg)
  });
  if (resp.ok) {
    const d = await resp.json();
    sessionId = d.sessionId;
    connectWebSocket();
  }

  saveCache();
  renderTopbar();
  closeModal('settings-modal');
  toast('Settings updated', 'success');
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

// ── Script Generator ────────────────────────────────────────────────────────
function openScriptGenerator() {
  // Reset to initial state
  document.getElementById('scriptgen-progress').style.display = 'none';
  document.getElementById('scriptgen-done').style.display = 'none';
  document.getElementById('scriptgen-log').innerHTML = '';
  document.getElementById('scriptgen-status').textContent = '';
  document.getElementById('scriptgen-summary').innerHTML = '';
  document.getElementById('scriptgen-generated-list').innerHTML = '';
  const btn = document.getElementById('scriptgen-run-btn');
  btn.disabled = false; btn.textContent = '⚡ Generate Scripts';
  document.getElementById('scriptgen-footer').style.display = '';
  document.getElementById('scriptgen-modal').classList.remove('hidden');
}

async function runScriptGenerator() {
  const btn = document.getElementById('scriptgen-run-btn');
  btn.disabled = true; btn.textContent = 'Running…';
  document.getElementById('scriptgen-progress').style.display = 'block';
  document.getElementById('scriptgen-status').textContent = 'Starting…';

  try {
    const resp = await fetch(`${API}/api/generate-scripts`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Failed to start');
  } catch (e) {
    document.getElementById('scriptgen-status').textContent = '✗ ' + e.message;
    btn.disabled = false; btn.textContent = '⚡ Generate Scripts';
  }
}

function _scriptgenLog(msg, cls = '') {
  const log = document.getElementById('scriptgen-log');
  if (!log) return;
  const line = document.createElement('div');
  if (cls) line.style.color = cls === 'ok' ? '#34d399' : cls === 'err' ? 'var(--red)' : 'var(--text3)';
  line.textContent = msg;
  log.appendChild(line);
  log.scrollTop = log.scrollHeight;
}

function onScriptGenProgress(msg) {
  const el = document.getElementById('scriptgen-status');
  if (el) el.textContent = msg.message || '';
  if (msg.total > 0) _scriptgenLog(msg.message);
}

function onScriptGenCreated(msg) {
  _scriptgenLog(`✓ ${msg.repo} — script generated`, 'ok');
}

function onScriptGenFailed(msg) {
  _scriptgenLog(`✗ ${msg.repo} — ${msg.error}`, 'err');
}

function onScriptGenDone(msg) {
  document.getElementById('scriptgen-progress').style.display = 'none';
  document.getElementById('scriptgen-done').style.display = 'block';
  document.getElementById('scriptgen-summary').textContent = msg.message;

  const list = document.getElementById('scriptgen-generated-list');
  if (msg.generated && msg.generated.length) {
    list.innerHTML = msg.generated.map(n => `<div style="color:#34d399">✓ scripts/${escHtml(n)}.sh</div>`).join('');
  } else {
    list.innerHTML = '<div style="color:var(--text3)">No scripts generated — all repos use the default setup.</div>';
  }

  const footer = document.getElementById('scriptgen-footer');
  footer.innerHTML = `<button class="btn btn-ghost" onclick="closeModal('scriptgen-modal')">Close</button>`;

  // Refresh repo list so new script badges appear
  if (msg.generated && msg.generated.length) filterRepos();
}

function onScriptGenError(msg) {
  const el = document.getElementById('scriptgen-status');
  if (el) { el.style.color = 'var(--red)'; el.textContent = '✗ ' + (msg.message || 'Generation failed'); }
  const btn = document.getElementById('scriptgen-run-btn');
  if (btn) { btn.disabled = false; btn.textContent = '⚡ Generate Scripts'; }
}

async function verifySudoPassword() {
  const input    = document.getElementById('s-macpw-input');
  const hint     = document.getElementById('s-macpw-hint');
  const btn      = document.getElementById('s-macpw-verify-btn');
  const remember = document.getElementById('s-macpw-remember')?.checked;
  const pw = input?.value || '';
  if (!pw) { if (hint) hint.textContent = 'Enter your Mac login password first.'; return; }

  if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }
  try {
    const resp = await fetch(`${API}/api/sudo-password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, password: pw }),
    });
    const data = await resp.json();
    if (data.ok) {
      if (remember) saveSudoPassword(pw); else clearSudoPassword();
      if (hint) { hint.style.color = 'var(--green, #34d399)'; hint.textContent = '✓ Password verified' + (remember ? ' and saved for future sessions.' : ' for this session.'); }
      if (input) input.value = '';
    } else {
      if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ ' + (data.error || 'Incorrect password — try again.'); }
    }
  } catch (e) {
    if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ Could not verify: ' + e.message; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Verify'; }
  }
}

// Called when the server signals that sudo failed mid-run (password expired).
const SUDO_PW_KEY = 'iready_oasis_sudopw';

function saveSudoPassword(pw) {
  try { localStorage.setItem(SUDO_PW_KEY, pw); } catch(e) {}
}
function loadSudoPassword() {
  try { return localStorage.getItem(SUDO_PW_KEY) || ''; } catch(e) { return ''; }
}
function clearSudoPassword() {
  try { localStorage.removeItem(SUDO_PW_KEY); } catch(e) {}
}

function showSudoPrompt(reason) {
  const existing = document.getElementById('sudo-prompt-modal');
  if (existing) existing.remove();

  const hasSaved = !!loadSudoPassword();
  const modal = document.createElement('div');
  modal.id = 'sudo-prompt-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal" style="max-width:400px">
      <div class="modal-header">
        <div class="modal-title">Mac Password Required</div>
        <button class="modal-close" onclick="document.getElementById('sudo-prompt-modal').remove()">✕</button>
      </div>
      <div class="modal-body">
        <p style="font-size:14px;color:var(--text2);margin:0 0 14px">${escHtml(reason || 'Enter your Mac login password to continue setup.')}</p>
        <div class="field">
          <label>Mac Login Password</label>
          <input id="sudo-prompt-pw" type="password" class="s-macpw" placeholder="Password" autofocus
            onkeydown="if(event.key==='Enter') submitSudoPrompt()"/>
        </div>
        <label class="check-row" style="margin-top:10px;display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);cursor:pointer">
          <input type="checkbox" id="sudo-prompt-remember" ${hasSaved ? 'checked' : ''}/>
          Save password on this device for future sessions
        </label>
        <div id="sudo-prompt-hint" style="font-size:12px;color:var(--text3);margin-top:8px">
          ${hasSaved ? 'A password is already saved — enter a new one to replace it.' : 'Used locally for sudo during setup only.'}
        </div>
      </div>
      <div class="modal-footer">
        ${hasSaved ? `<button class="btn btn-ghost" onclick="clearSudoPassword();document.getElementById('sudo-prompt-modal').remove();toast('Saved password cleared','info')">Clear saved</button>` : `<button class="btn btn-ghost" onclick="document.getElementById('sudo-prompt-modal').remove()">Cancel</button>`}
        <button class="btn btn-primary" onclick="submitSudoPrompt()">Save Password</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
  setTimeout(() => document.getElementById('sudo-prompt-pw')?.focus(), 50);
}

async function submitSudoPrompt() {
  const input    = document.getElementById('sudo-prompt-pw');
  const hint     = document.getElementById('sudo-prompt-hint');
  const remember = document.getElementById('sudo-prompt-remember')?.checked;
  const pw = input?.value || '';
  if (!pw) return;

  try {
    const resp = await fetch(`${API}/api/sudo-password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, password: pw }),
    });
    const data = await resp.json();
    if (data.ok) {
      if (remember) saveSudoPassword(pw);
      else clearSudoPassword();
      document.getElementById('sudo-prompt-modal')?.remove();
      toast('Password accepted — continuing setup…', 'success');
    } else {
      if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ ' + (data.error || 'Incorrect — try again.'); }
      if (input) input.value = '';
    }
  } catch (e) {
    if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ ' + e.message; }
  }
}
