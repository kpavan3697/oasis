// =============================================================================
// Repos — GitHub repo fetch/search, filtering, card rendering, topbar, options sync
// =============================================================================

function updateScheduledJobsBtn() {
  const btn = document.getElementById('sched-jobs-btn');
  if (!btn) return;
  const count = Object.keys(scheduledJobs).length;
  btn.style.display = count > 0 ? '' : 'none';
  const badge = document.getElementById('sched-jobs-badge');
  if (!badge) return;
  const failed = Object.values(scheduledJobs).filter(j => j.lastStatus === 'partial' || j.lastStatus === 'failed').length;
  badge.textContent = failed > 0 ? failed : '';
  badge.className   = `sched-jobs-badge ${failed > 0 ? 'has-failures' : ''}`;
}

function openScheduledJobsPanel() {
  document.getElementById('sched-jobs-panel')?.remove();

  const jobs = scheduledJobs;
  const entries = Object.entries(jobs);
  if (!entries.length) { toast('No scheduled jobs configured yet', 'info'); return; }

  const DAY_LBL = { mon:'Mon',tue:'Tue',wed:'Wed',thu:'Thu',fri:'Fri',sat:'Sat',sun:'Sun' };
  const schedLabel = s => {
    if (s.schedule === 'manual')  return 'Manual';
    if (s.schedule === 'hourly')  return 'Hourly';
    if (s.schedule === 'daily')   return `Daily (${(s.scheduleDays||[]).map(d=>DAY_LBL[d]||d).join(', ')}) ${s.scheduleTime||'09:00'}`;
    if (s.schedule === 'weekly')  return `Weekly (${DAY_LBL[s.scheduleDay]||'Mon'}) ${s.scheduleTime||'09:00'}`;
    return s.schedule;
  };
  const statusBadge = st => {
    const map = { success: ['#22c55e', '✅ Passed'], partial: ['#f59e0b', '⚠️ Partial'], failed: ['#ef4444', '❌ Failed'], running: ['#3b82f6', '⏳ Running'] };
    const [color, label] = map[st] || ['#6b7280', '— Not run'];
    return `<span style="color:${color};font-weight:500">${label}</span>`;
  };

  const rows = entries.map(([name, job]) => {
    const tasks = Object.entries(job.tasks || {}).filter(([,v]) => v).map(([k]) => ({ pull:'Pull', buildCheck:'Build', codeReview:'Review', securityScan:'Security', codeImprovements:'Improve' })[k]).join(', ');
    const when  = job.lastRun ? `<span title="${new Date(job.lastRun).toLocaleString()}">${timeAgo(job.lastRun)}</span>` : '<span style="color:var(--text3)">Never</span>';
    const report = job.lastReport
      ? `<div class="sjp-report">${escHtml(job.lastReport.slice(0, 300))}</div>`
      : '';
    return `
      <div class="sjp-row">
        <div class="sjp-row-head">
          <span class="sjp-name">${escHtml(name)}</span>
          <span class="sjp-freq">${schedLabel(job)}</span>
          <span class="sjp-when">${when}</span>
          ${statusBadge(job.lastStatus)}
          <button class="btn btn-ghost btn-sm" onclick="runScheduleNow('${escHtml(name)}');document.getElementById('sched-jobs-panel')?.remove()">▶ Run Now</button>
          <button class="btn btn-ghost btn-sm" onclick="openScheduleModal('${escHtml(name)}')">Edit</button>
        </div>
        <div class="sjp-tasks" style="color:var(--text3);font-size:12px;font-family:var(--mono)">${escHtml(tasks)}</div>
        ${report}
      </div>`;
  }).join('');

  const panel = document.createElement('div');
  panel.id = 'sched-jobs-panel';
  panel.className = 'modal-overlay';
  panel.innerHTML = `
    <div class="modal" style="max-width:680px">
      <div class="modal-header">
        <div class="modal-title">⏰ Scheduled Jobs</div>
        <button class="modal-close" onclick="document.getElementById('sched-jobs-panel').remove()">✕</button>
      </div>
      <div class="modal-body" style="max-height:65vh;overflow-y:auto;padding:0">
        <div class="sjp-list">${rows}</div>
      </div>
      <div class="modal-footer">
        <span style="font-size:12px;color:var(--text3)">Jobs run automatically when OASIS is open · desktop notification on completion</span>
        <button class="btn btn-ghost" onclick="document.getElementById('sched-jobs-panel').remove()">Close</button>
      </div>
    </div>`;
  document.body.appendChild(panel);

  const closeJobsPanel = () => { document.removeEventListener('keydown', onJobsPanelKey); panel.remove(); };
  const onJobsPanelKey = (e) => { if (e.key === 'Escape') closeJobsPanel(); };
  panel.addEventListener('click', (e) => { if (e.target === panel) closeJobsPanel(); });
  document.addEventListener('keydown', onJobsPanelKey);
}

// ── GitHub Repo Fetch ──────────────────────────────────────────────────────
async function fetchRepos(page = 1) {
  const resp = await fetch(`${API}/api/repos?session=${sessionId}&page=${page}&per_page=100`);
  if (!resp.ok) {
    const err = await resp.json();
    throw new Error(err.error || 'Failed to fetch repos');
  }
  const data = await resp.json();
  if (page === 1) allRepos = data.repos;
  else allRepos = [...allRepos, ...data.repos];

  currentPage = page;
  hasMorePages = data.hasNext;
  updateRepoCount();
  buildLangFilters();
  filterRepos();
  return data;
}

async function reloadRepos() {
  document.getElementById('repo-list').innerHTML = '<div class="loading-repos"><div class="spinner"></div><div>Refreshing…</div></div>';
  allRepos = []; selectedRepos.clear(); updateSelCount();
  await fetchAllRepos();
}

// Fetches every page sequentially. A generation counter cancels any in-flight
// run when a newer one starts, preventing interleaved appends and duplicates.
async function fetchAllRepos() {
  const gen = ++_fetchGeneration;
  try {
    await fetchRepos(1);
    while (hasMorePages && gen === _fetchGeneration) {
      await fetchRepos(currentPage + 1);
    }
  } catch (err) {
    if (gen === _fetchGeneration) toast('Failed to load repos: ' + err.message, 'error');
  }
}

function updateRepoCount() {
  const countEl = document.getElementById('sidebar-repo-count');
  if (countEl) countEl.textContent = allRepos.length;
}

async function loadMoreRepos() {
  await fetchRepos(currentPage + 1);
}

// ── Repo Filtering ─────────────────────────────────────────────────────────
function buildLangFilters() {
  // filter-tags removed from topbar — nothing to render
}

function setLangFilter(el, lang) {
  document.querySelectorAll('.ftag').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  langFilters = lang ? new Set([lang]) : new Set();
  filterRepos();
}

function debouncedSearch() {
  filterRepos();
}

function filterRepos() {
  const q = (document.getElementById('repo-search')?.value || '').toLowerCase();
  filteredRepos = allRepos.filter(r => {
    const matchSearch = !q || r.name.toLowerCase().includes(q) || (r.description || '').toLowerCase().includes(q);
    const matchLang   = langFilters.size === 0 || langFilters.has(r.language);
    return matchSearch && matchLang;
  });
  renderRepoList();
}

// ── Repo List Render ───────────────────────────────────────────────────────
function renderRepoList() {
  const list = document.getElementById('repo-list');
  if (!filteredRepos.length) {
    list.innerHTML = '<div style="padding:24px;text-align:center;color:var(--text3);font-size:13px">No repositories match your filter</div>';
    return;
  }

  list.innerHTML = '';
  const clonedNames = new Set(epRepos.map(r => r.name));
  filteredRepos.forEach(repo => {
    const el = document.createElement('div');
    const isSel = selectedRepos.has(repo.name);
    const isCloned = clonedNames.has(repo.name);
    const isDisabled = isCloned || (!isSel && selectedRepos.size >= 10);
    el.className = `repo-item${isSel ? ' selected' : ''}${isCloned ? ' cloned' : (isDisabled ? ' disabled' : '')}`;
    el.dataset.repo = repo.name;

    const langColor = LANG_COLORS[repo.language] || '#6b7280';
    const updated = repo.updated_at ? timeAgo(repo.updated_at) : '';

    el.innerHTML = `
      <div class="repo-check">${isCloned ? '✓' : ''}</div>
      <div class="repo-info">
        <div class="repo-name">${escHtml(repo.name)}</div>
        ${repo.description ? `<div class="repo-desc">${escHtml(repo.description)}</div>` : ''}
        <div class="repo-meta">
          <span class="lang-pill"><span class="lang-circle" style="background:${langColor}"></span>${escHtml(repo.language || 'Unknown')}</span>
          ${updated ? `<span class="repo-updated">last updated: ${updated}</span>` : ''}
        </div>
      </div>`;
    if (!isCloned) el.onclick = () => toggleRepo(repo);
    list.appendChild(el);
  });
}

function toggleRepo(repo) {
  const name = repo.name;
  if (selectedRepos.has(name)) {
    selectedRepos.delete(name);
  } else {
    if (selectedRepos.size >= 10) { toast('Maximum 10 repositories allowed', 'error'); return; }
    selectedRepos.add(name);
  }
  updateSelCount();
  renderRepoList();
  updateLaunchState();
}

function updateSelCount() {
  document.getElementById('sel-num').textContent = selectedRepos.size;
}

function updateLaunchState() {
  const btn = document.getElementById('launch-btn');
  btn.disabled = selectedRepos.size === 0;
  renderSelectedProjects();
}

// Shared SVG icons used on Existing Project cards
const IJ_SVG = `<svg width="15" height="15" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="ij-g0" x1="-0.717" y1="7.621" x2="24.146" y2="61.248" gradientUnits="userSpaceOnUse">
      <stop offset="0.1" stop-color="#FC801D"/><stop offset="0.59" stop-color="#FE2857"/>
    </linearGradient>
    <linearGradient id="ij-g1" x1="4.222" y1="60.019" x2="62.927" y2="1.313" gradientUnits="userSpaceOnUse">
      <stop offset="0.21" stop-color="#FE2857"/><stop offset="0.7" stop-color="#007EFF"/>
    </linearGradient>
    <clipPath id="ij-clip"><rect width="64" height="64" fill="white"/></clipPath>
  </defs>
  <g clip-path="url(#ij-clip)">
    <path d="M15.948 5.818L4.072 5.82C1.823 5.82 0 7.644 0 9.893V21.4c0 1.189.52 2.319 1.422 3.092l38.161 32.71c.738.632 1.678.98 2.651.98h11.875c2.249 0 4.073-1.824 4.073-4.073V42.6c0-1.189-.52-2.319-1.422-3.092L18.599 6.8a5.45 5.45 0 0 0-2.651-.982z" fill="#FF8100"/>
    <path d="M14.519 5.818H4.073C1.823 5.818 0 7.642 0 9.891v13.093c0 .192.014.385.041.576l5.277 36.944C5.605 62.51 7.323 64 9.35 64h15.673c2.25 0 4.073-1.824 4.073-4.074l-.005-18.538c0-.438-.07-.872-.209-1.287L18.383 8.603C17.828 6.94 16.272 5.818 14.519 5.818z" fill="url(#ij-g0)"/>
    <path d="M59.928 0H25.959c-1.629 0-3.102.971-3.744 2.468L6.148 39.959a5.46 5.46 0 0 0-.33 1.604V59.927C5.818 62.177 7.642 64 9.891 64h17.966c.805 0 1.591-.238 2.261-.685L62.187 41.911C63.319 41.156 64 39.885 64 38.524L64 4.073C64 1.823 62.177 0 59.928 0z" fill="url(#ij-g1)"/>
    <path d="M52 12H12v40h40V12z" fill="black"/>
    <path d="M17 29.386h2.979V19.614H17V17h8.839v2.614h-2.979v9.772h2.979V32H17v-2.614z" fill="white"/>
    <path d="M27.339 29.3h2.154c.435 0 .823-.093 1.162-.279.34-.185.602-.448.788-.787.186-.34.279-.727.279-1.163V17h2.925v10.275c0 .9-.207 1.71-.621 2.427-.415.718-.986 1.28-1.715 1.687-.729.407-1.546.611-2.453.611h-2.519V29.3z" fill="white"/>
    <path d="M33 44H17v3h16v-3z" fill="white"/>
  </g>
</svg>`;

const CHAT_SVG = `<svg viewBox="0 0 16 16" width="13" height="13" fill="none">
  <path d="M14 1H2C.9 1 0 1.9 0 3v9c0 1.1.9 2 2 2h3v2.5l4-2.5h5c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2z" fill="#087CFA"/>
  <path d="M4 6.5h8M4 9.5h5" stroke="white" stroke-width="1.3" stroke-linecap="round"/>
</svg>`;

const TRASH_SVG = `<svg viewBox="0 0 14 14" width="13" height="13" fill="none" stroke="#E53E3E" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
  <path d="M2 3.5h10M4.5 3.5V2h5v1.5M3 3.5l.7 8h6.6l.7-8"/>
  <path d="M5.5 6v4M8.5 6v4"/>
</svg>`;

const FOLDER_SVG = `<svg viewBox="0 0 16 16" width="14" height="14" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M1.5 3.5A1.5 1.5 0 0 1 3 2h3.379a1.5 1.5 0 0 1 1.06.44l.94.94A1.5 1.5 0 0 0 9.44 3.88L8.5 3H3a.5.5 0 0 0-.5.5V4H1.5V3.5z" fill="#F5A623"/>
  <path d="M1 5a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V5z" fill="#F5A623"/>
  <path d="M1 5a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V5z" fill="url(#folder-light)" opacity="0.3"/>
  <defs>
    <linearGradient id="folder-light" x1="8" y1="4" x2="8" y2="13" gradientUnits="userSpaceOnUse">
      <stop stop-color="white"/><stop offset="1" stop-color="white" stop-opacity="0"/>
    </linearGradient>
  </defs>
  <path d="M1.5 3A1.5 1.5 0 0 1 3 1.5h3.172a1.5 1.5 0 0 1 1.06.44l.94.94A.5.5 0 0 0 8.525 3H13A1.5 1.5 0 0 1 14.5 4.5v.086a1 1 0 0 0-.293-.293L13 4H3a1 1 0 0 0-1 1v7a1 1 0 0 1-1-1V3z" fill="#E8921A" opacity="0.6"/>
</svg>`;

// Render selected repos as simple cards — no action buttons (those live in Local Repos tab)
function renderSelectedProjects() {
  const list = document.getElementById('selected-list');
  if (!list) return;
  if (selectedRepos.size === 0) {
    list.innerHTML = '<div class="selected-empty">Select repositories from the list to begin</div>';
    return;
  }
  const repos = [...selectedRepos].map(name => allRepos.find(r => r.name === name)).filter(Boolean);
  list.innerHTML = repos.map(repo => {
    const lc = LANG_COLORS[repo.language] || '#6b7280';
    const n = escHtml(repo.name);
    return `
      <div class="col-xl-4 col-lg-6 col-12">
      <div class="project-card">
        <div class="opt-icon">📦</div>
        <div class="project-body">
          <div class="opt-label" title="${n}">${n}</div>
          <div class="opt-desc"><span class="lang-circle" style="background:${lc}"></span>${escHtml(repo.language || 'Unknown')}</div>
        </div>
        <button class="project-remove" title="Remove" onclick="removeSelected('${n}')">✕</button>
      </div>
      </div>`;
  }).join('');
}

function removeSelected(name) {
  selectedRepos.delete(name);
  updateSelCount();
  renderRepoList();
  updateLaunchState();
}

// ── Topbar ─────────────────────────────────────────────────────────────────
function renderTopbar() {
  document.getElementById('topbar-org').textContent = `${cfg.org} · ${cfg.githubUrl}`;
  const displayName = cfg.githubLogin || cfg.org || 'Dev';
  document.getElementById('topbar-user').textContent = displayName;
  document.getElementById('topbar-avatar').textContent = displayName[0].toUpperCase();
}

// ── Options ────────────────────────────────────────────────────────────────
function syncOpts() {
  // keep UI in sync — actual values read at launch time
}

function getOptions() {
  return {
    intellij:  document.getElementById('opt-intellij')?.checked ?? false, // only user toggle
    parallel:  true,  // always run in parallel
    useScript: true,  // always use setup scripts by default
    maven:     true,  // maven runs based on the setup script / auto-detect
  };
}
