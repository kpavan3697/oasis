// =============================================================================
// Init — auto-resume last session, dark/light theme toggle, DOMContentLoaded bootstrap
// =============================================================================
// If we have cached config AND a remembered token, recreate the session and go
// straight to the main screen — so a page refresh restores the dashboard
// instead of dumping the user back on the onboarding wizard.
async function autoResume() {
  const token = getCookie(TOKEN_COOKIE);
  const savedJenkinsToken = loadJenkinsCredentials()?.token || '';
  if (!token || !savedJenkinsToken || !cfg.githubUrl || !cfg.org || !cfg.cloneDir) return false;
  cfg.token = token;

  try {
    const resp = await fetch(`${API}/api/session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        githubUrl: cfg.githubUrl, org: cfg.org, token, cloneDir: cfg.cloneDir,
        intellijPath: cfg.intellijPath || '', mavenArgs: cfg.mavenArgs || '', extraEnv: cfg.extraEnv || '',
        awsProfile: cfg.awsProfile || '',
        jenkinsToken: savedJenkinsToken,
      })
    });
    if (!resp.ok) return false;
    const sd = await resp.json();
    sessionId = sd.sessionId;
    if (sd.githubLogin) cfg.githubLogin = sd.githubLogin;
  } catch (e) {
    return false;
  }

  // Validate the token by fetching page 1 before entering the app
  const data = await fetchRepos(1).catch(() => null);
  if (!data) {
    sessionId = null;
    return false;
  }
  enterApp();
  // Load remaining pages in the background (guard in fetchAllRepos prevents duplication)
  fetchAllRepos();
  return true;
}

// ── Init ───────────────────────────────────────────────────────────────────
// ── Theme (dark / light) ─────────────────────────────────────────────────────
const THEME_KEY = 'oasis_theme';

function currentTheme() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
}

// DOM-only: updates attribute + localStorage + button without saving to prefs.
// Used during init so startup never overwrites the user's saved preference.
function _applyThemeDom(theme) {
  const t = theme === 'light' ? 'light' : 'dark';
  if (t === 'light') document.documentElement.setAttribute('data-theme', 'light');
  else document.documentElement.removeAttribute('data-theme');
  try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
  const btn = document.getElementById('theme-toggle');
  if (btn) {
    btn.textContent = t === 'light' ? '☀️' : '🌙';
    btn.title = t === 'light' ? 'Switch to dark theme' : 'Switch to light theme';
  }
}

// Full apply: updates DOM and persists to ~/.oasis-prefs.json via the server.
// Persisting to the prefs file (not localStorage) survives Electron port changes.
function applyTheme(theme) {
  const t = theme === 'light' ? 'light' : 'dark';
  _applyThemeDom(t);
  fetch(`${API}/api/prefs`, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ theme: t }) }).catch(() => {});
}

function toggleTheme() {
  applyTheme(currentTheme() === 'light' ? 'dark' : 'light');
}

(async function init() {
  // Load the saved theme from prefs (survives port changes); don't re-save it.
  // The server also pre-injects data-theme on <html> to avoid a flash on load.
  try {
    const prefs = await fetch(`${API}/api/prefs`).then(r => r.json()).catch(() => ({}));
    _applyThemeDom(prefs.theme === 'light' || prefs.theme === 'dark' ? prefs.theme : currentTheme());
  } catch (_) {
    _applyThemeDom(currentTheme());
  }
  loadCache();
  await loadCacheFromFile(); // merge file-persisted prefs (survives Electron restarts)
  prefillWizard();
  autoResume();
})();


// ─────────────────────────────────────────────────────────────────────────────
// Docker Services Tab — flat card grid
// ─────────────────────────────────────────────────────────────────────────────

let _dockerServices   = [];        // catalog from /api/docker/services
let _dockerCategories = [];        // [{id,label}]
let _dockerContainers = {};        // container name → live status object
let _dockerFilter     = 'all';     // active category filter
let _dockerPollTimer  = null;
let _dockerBusy       = new Set();  // service names with an op in flight
let _dockerOpId       = 0;
let _dockerLoaded     = false;
let _dockerPrefetching = false;     // true while the background prefetch is in flight

// Route a streamed log line to the right place: docker op logs → drawer; else jobs.
function routeLog(jobId, level, message, ts) {
  if (typeof jobId === 'string' && jobId.startsWith('docker-op-')) {
    appendDockerLog(level, message);
  } else {
    appendLog(jobId, level, message, ts);
    // Mirror to ep-card console when a launch is actively running for this repo
    if (epLaunchState[jobId]?.running) appendEpConsoleLog(jobId, level, message, ts);
  }
}

async function initDockerTab(forceRefresh = false, bg = false) {
  // A background prefetch already fetched the catalog and rendered into the
  // (hidden) tab DOM — just resume live polling on a real tab open.
  if (_dockerLoaded && !forceRefresh) { if (!bg) startDockerPolling(); return; }
  // A prefetch is mid-flight and will render shortly. Don't fire a duplicate
  // fetch; just start polling so the cards go live the moment it lands.
  if (_dockerPrefetching && !bg && !forceRefresh) { startDockerPolling(); return; }
  const grid = document.getElementById('docker-cards-grid');
  if (grid && !_dockerServices.length) grid.innerHTML = '<div class="docker-empty">Loading services…</div>';

  try {
    const resp = await fetch(`${API}/api/docker/services?session=${sessionId}`);
    const data = await resp.json();
    _dockerCategories = data.categories || [];
    _dockerServices   = data.services   || [];
    _dockerLoaded = true;

    const notice = document.getElementById('docker-notice');
    if (!data.dockerOk) {
      notice.classList.remove('hidden');
      notice.innerHTML = '🐳 <strong>Docker isn\'t running.</strong> Start Docker Desktop (or the daemon), then click ↻ Refresh. ' +
        '<a href="https://www.docker.com/products/docker-desktop/" target="_blank" rel="noopener">Get Docker Desktop ↗</a>';
    } else if (!data.servicesDirExists) {
      notice.classList.remove('hidden');
      notice.innerHTML = '🐳 <strong>Bundled docker service definitions are missing from this install.</strong> ' +
        'Reinstall or update OASIS to restore the <code>docker/</code> folder.';
    } else {
      notice.classList.add('hidden');
    }

    renderDockerChips();
    await refreshDockerContainers();   // also calls renderDockerCards()
    if (!bg) startDockerPolling();     // polling is a tab-active concern, not a prefetch one
  } catch (e) {
    const notice = document.getElementById('docker-notice');
    if (notice) { notice.classList.remove('hidden'); notice.textContent = 'Could not reach the OASIS server.'; }
  }
}

function renderDockerChips() {
  const wrap = document.getElementById('docker-filter-chips');
  if (!wrap) return;
  // Nothing to filter → no chips at all (don't show a lone "All").
  if (!_dockerServices.length) { wrap.innerHTML = ''; return; }
  // Count services per category
  const counts = {};
  for (const s of _dockerServices) counts[s.categoryId] = (counts[s.categoryId] || 0) + 1;
  const cats = [{ id: 'all', label: 'All' }, ..._dockerCategories.filter(c => counts[c.id])];
  wrap.innerHTML = cats.map(c => {
    const n = c.id === 'all' ? _dockerServices.length : counts[c.id];
    return `<span class="dchip ${_dockerFilter === c.id ? 'active' : ''}" onclick="setDockerFilter('${c.id}')">${escHtml(c.label)}<span class="dchip-count">${n}</span></span>`;
  }).join('');
}

function setDockerFilter(id) {
  _dockerFilter = id;
  renderDockerChips();
  renderDockerCards();
}

// Map a container's live status into a state string.
function containerState(c) {
  if (!c) return 'absent';
  return /^up/i.test(c.Status || c.State || '') ? 'running' : 'stopped';
}

// Build the HTML for one service card.
function dockerCardHtml(s) {
  const catLabel = id => (_dockerCategories.find(c => c.id === id)?.label) || id;
  const c = _dockerContainers[s.container];
  const state = _dockerBusy.has(s.name) ? 'busy' : containerState(c);
  const stateText = { running: 'running', stopped: 'stopped', absent: 'not installed', busy: 'working…' }[state];
  const imgShort = (s.image || '—').replace(/^[^/]+\//, '').replace(/^[^/]+\//, '');
  const portStr = s.ports && s.ports.length ? s.ports.map(p => `:${p}`).join(' ') : '';
  const uptime = c && /^up/i.test(c.Status || '') ? (c.Status || '').replace(/^Up\s*/i, '') : '';

  let actions = '';
  if (state === 'busy') {
    actions = `<button class="dbtn" disabled>working…</button>`;
  } else if (state === 'running') {
    actions =
      `<button class="dbtn warn"   onclick="dockerCardOp('restart','${s.name}','${s.container}')">↻ Restart</button>` +
      `<button class="dbtn danger" onclick="dockerCardOp('stop','${s.name}','${s.container}')">■ Stop</button>` +
      `<button class="dbtn"        onclick="dockerCardLogs('${s.name}','${s.container}')">📄 Logs</button>` +
      `<button class="dbtn danger" onclick="dockerCardOp('delete','${s.name}','${s.container}')" title="Remove container">🗑 Delete</button>`;
  } else if (state === 'stopped') {
    actions =
      `<button class="dbtn primary" onclick="dockerCardOp('start','${s.name}','${s.container}')">▶ Start</button>` +
      `<button class="dbtn"         onclick="dockerCardLogs('${s.name}','${s.container}')">📄 Logs</button>` +
      `<button class="dbtn danger"  onclick="dockerCardOp('delete','${s.name}','${s.container}')" title="Remove container">🗑 Delete</button>`;
  } else { // absent
    actions =
      `<button class="dbtn primary" onclick="dockerCardOp('install','${s.name}','${s.container}')">⬇ Install</button>`;
  }

  return `
    <div class="dcard s-${state}" id="dcard-${s.name}">
      <div class="dcard-top">
        <span class="dcard-dot"></span>
        <span class="dcard-name" title="${escHtml(s.name)}">${escHtml(s.label)}</span>
        <span class="dcard-state">${stateText}</span>
      </div>
      <div class="dcard-cat">${escHtml(catLabel(s.categoryId))}${s.profile ? ' · profile: ' + escHtml(s.profile) : ''}</div>
      <div class="dcard-img" title="${escHtml(s.image || '')}">${escHtml(imgShort)}</div>
      <div class="dcard-meta">
        ${portStr ? `<span>ports <b>${escHtml(portStr)}</b></span>` : '<span style="color:var(--text3)">no published ports</span>'}
        ${uptime ? `<span class="dcard-uptime">up ${escHtml(uptime)}</span>` : ''}
      </div>
      <div class="dcard-actions">${actions}</div>
    </div>`;
}

function renderDockerCards() {
  const grid = document.getElementById('docker-cards-grid');
  if (!grid) return;
  const q = (document.getElementById('docker-search')?.value || '').toLowerCase().trim();

  let list = _dockerServices.slice();
  if (_dockerFilter !== 'all') list = list.filter(s => s.categoryId === _dockerFilter);
  if (q) list = list.filter(s =>
    s.name.toLowerCase().includes(q) || (s.image || '').toLowerCase().includes(q) || s.label.toLowerCase().includes(q));

  // Summary (always over the full catalog, not the filtered view)
  const runningAll   = _dockerServices.filter(s => containerState(_dockerContainers[s.container]) === 'running').length;
  const installedAll = _dockerServices.filter(s => _dockerContainers[s.container]).length;
  const sum = document.getElementById('docker-summary');
  if (sum) sum.textContent = _dockerServices.length
    ? `${runningAll} running · ${installedAll} installed · ${_dockerServices.length} total`
    : '—';

  if (!_dockerServices.length) {
    // Whole catalog empty (repo not cloned / unreadable) — the notice above explains it.
    grid.innerHTML = '<div class="docker-empty">No Docker services yet — clone the <b>services</b> repo (see the note above) and click ↻ Refresh.</div>';
    return;
  }
  if (!list.length) { grid.innerHTML = '<div class="docker-empty">No services match your filter.</div>'; return; }

  // Partition into Running / Stopped / Not installed (busy keeps its underlying state for grouping).
  const buckets = { running: [], stopped: [], absent: [] };
  for (const s of list) buckets[containerState(_dockerContainers[s.container])].push(s);
  for (const k of Object.keys(buckets)) buckets[k].sort((a, b) => a.name.localeCompare(b.name));

  const sections = [
    { key: 'running', label: 'Running',       cls: 'sec-running' },
    { key: 'stopped', label: 'Stopped',       cls: 'sec-stopped' },
    { key: 'absent',  label: 'Not Installed', cls: 'sec-absent'  },
  ];

  grid.innerHTML = sections.filter(sec => buckets[sec.key].length).map(sec => `
    <div class="docker-section">
      <div class="docker-section-head ${sec.cls}">
        <span class="docker-section-dot"></span>${sec.label}
        <span class="docker-section-count">${buckets[sec.key].length}</span>
      </div>
      <div class="row g-3 docker-section-grid">
        ${buckets[sec.key].map(s => `<div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6">${dockerCardHtml(s)}</div>`).join('')}
      </div>
    </div>`).join('');
}
