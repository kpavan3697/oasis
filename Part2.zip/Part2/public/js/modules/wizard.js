// =============================================================================
// Wizard — onboarding steps, GitHub/Jenkins validation, session creation, enterApp()
// =============================================================================
// Stored in a COOKIE (like the PAT), not localStorage. The Electron app serves
// on a random port each launch; cookies are keyed by host (port-agnostic) so
// they survive, whereas localStorage is per-origin (host+port) and gets wiped.
function saveJenkinsCredentials(data) {
  const token = data && data.token;
  if (token) setCookie(JENKINS_COOKIE, token, TOKEN_COOKIE_DAYS);
  try { localStorage.removeItem(JENKINS_KEY); } catch (_) {}   // drop stale legacy copy
}
function loadJenkinsCredentials() {
  const cookieTok = getCookie(JENKINS_COOKIE);
  if (cookieTok) return { token: cookieTok };
  // One-time migration from the old localStorage location.
  try {
    const legacy = JSON.parse(localStorage.getItem(JENKINS_KEY) || 'null');
    if (legacy?.token) { setCookie(JENKINS_COOKIE, legacy.token, TOKEN_COOKIE_DAYS); return legacy; }
  } catch (_) {}
  return null;
}
function clearJenkinsCredentials() {
  deleteCookie(JENKINS_COOKIE);
  try { localStorage.removeItem(JENKINS_KEY); } catch (_) {}
}

function prefillWizard() {
  if (cfg.githubUrl) document.getElementById('w-ghurl').value = cfg.githubUrl;
  if (cfg.org)       document.getElementById('w-org').value   = cfg.org;

  // Prefill both tokens if previously remembered.
  const savedToken = getCookie(TOKEN_COOKIE);
  if (savedToken) {
    const tokenInput = document.getElementById('w-token');
    if (tokenInput) tokenInput.value = savedToken;
  }
  const jk = loadJenkinsCredentials();
  if (jk?.token) {
    const tokenEl = document.getElementById('w-jenkins-token');
    if (tokenEl) tokenEl.value = jk.token;
  }
  // If tokens were saved before, keep the single "remember" box checked.
  // (First run: the HTML default is already checked.)
  const rememberBox = document.getElementById('w-remember-tokens');
  if (rememberBox && (savedToken || jk?.token)) rememberBox.checked = true;

  // Update Jenkins link — use cached GitHub login, or fall back to Mac username
  if (cfg.githubLogin) {
    updateJenkinsSecurityLink(cfg.githubLogin);
  } else {
    fetch(`${API}/api/whoami`).then(r => r.json()).then(d => {
      if (d.username) updateJenkinsSecurityLink(d.username);
    }).catch(() => {});
  }

  // Auto-trigger validation if fields are pre-filled AND the wizard is still visible.
  // Skip if autoResume already logged in (wizard will be hidden by then).
  setTimeout(() => {
    if (document.getElementById('wizard')?.style.display === 'none') return;
    if (document.getElementById('main-app')?.classList.contains('hidden') === false) return;
    const url   = document.getElementById('w-ghurl')?.value.trim();
    const org   = document.getElementById('w-org')?.value.trim();
    const token = document.getElementById('w-token')?.value.trim();
    // Kick off GitHub (PAT) and Jenkins checks in parallel — neither waits for
    // the other. Jenkins falls back to /api/whoami for the username when the
    // GitHub login isn't known yet, so it validates independently.
    if (url && org && token) scheduleGhValidation();
    if (document.getElementById('w-jenkins-token')?.value.trim()) scheduleJkValidation();
  }, 500);  // wait 500ms so autoResume has time to complete first
}

// ── Wizard auto-validation ──────────────────────────────────────────────────
let _ghValidated = false;
let _jkValidated = false;
let _ghTimer = null;
let _jkTimer = null;

function setWizStatus(elId, state, msg) {
  // state: 'ok' | 'error' | 'checking' | ''
  const el = document.getElementById(elId);
  if (!el) return;
  const colors = { ok: 'var(--green)', error: 'var(--red)', checking: 'var(--text3)', '': 'var(--text3)' };
  const icons  = { ok: '✓ ', error: '✗ ', checking: '⋯ ', '': '' };
  el.style.color   = colors[state] || 'var(--text3)';
  el.textContent   = (icons[state] || '') + msg;
}

function updateConnectBtn() {
  const btn = document.getElementById('wiz-connect-btn');
  if (!btn) return;
  // Both GitHub AND Jenkins must be verified before connecting
  const ready = _ghValidated && _jkValidated;
  btn.disabled = !ready;
}

function updateWizStatusRow() {
  const row = document.getElementById('wiz-status-row');
  if (!row) return;
  const chip = (label, ok) =>
    `<span style="font-size:11px;font-family:var(--mono);padding:2px 9px;border-radius:100px;border:1px solid;
      ${ok ? 'color:var(--green);border-color:rgba(34,197,94,.4);background:rgba(34,197,94,.08)'
           : 'color:var(--text3);border-color:var(--border)'}">${label} ${ok ? '✓' : '—'}</span>`;
  row.innerHTML = chip('GitHub', _ghValidated) + chip('Jenkins', _jkValidated);
}

// Debounced trigger — called on every input change
function scheduleGhValidation() {
  _ghValidated = false;
  updateConnectBtn();
  clearTimeout(_ghTimer);
  const url   = document.getElementById('w-ghurl')?.value.trim();
  const org   = document.getElementById('w-org')?.value.trim();
  const token = document.getElementById('w-token')?.value.trim();
  if (!url || !org || !token) { setWizStatus('w-gh-status', '', ''); updateWizStatusRow(); return; }
  setWizStatus('w-gh-status', 'checking', 'Checking…');
  _ghTimer = setTimeout(validateGitHub, 700);
}

function scheduleJkValidation() {
  _jkValidated = false;
  updateConnectBtn();
  clearTimeout(_jkTimer);
  const token = document.getElementById('w-jenkins-token')?.value.trim();
  if (!token) { setWizStatus('w-jenkins-status', '', ''); updateWizStatusRow(); return; }
  setWizStatus('w-jenkins-status', 'checking', 'Checking…');
  _jkTimer = setTimeout(validateJenkins, 700);
}

async function validateGitHub() {
  const url   = document.getElementById('w-ghurl')?.value.trim();
  const org   = document.getElementById('w-org')?.value.trim();
  const token = document.getElementById('w-token')?.value.trim();
  if (!url || !org || !token) return;
  try {
    const resp = await fetch(`${API}/api/validate-github`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ githubUrl: url, token }),
    });
    const data = await resp.json();
    if (!data.ok) throw new Error(data.error || 'Connection failed');
    cfg = { ...cfg, githubUrl: url, org, token, githubLogin: data.githubLogin || '' };
    updateJenkinsSecurityLink(cfg.githubLogin);
    _ghValidated = true;
    setWizStatus('w-gh-status', 'ok', `Connected as ${data.githubLogin || org}`);
    // Note: Jenkins validation runs independently (on prefill and on its own
    // input handler) — it is NOT chained off GitHub success, so the two checks
    // never wait for each other.
  } catch (e) {
    _ghValidated = false;
    setWizStatus('w-gh-status', 'error', e.message.replace(/^Invalid token — /, ''));
  }
  updateWizStatusRow();
  updateConnectBtn();
}

async function validateJenkins() {
  const token = document.getElementById('w-jenkins-token')?.value.trim();
  if (!token) return;
  // Use GitHub login if already known, else fall back to Mac username (same CA login)
  let user = cfg.githubLogin;
  if (!user) {
    try {
      const wd = await fetch(`${API}/api/whoami`).then(r => r.json());
      user = wd.username || '';
    } catch (_) {}
  }
  if (!user) {
    setWizStatus('w-jenkins-status', 'error', 'Could not determine username');
    return;
  }
  try {
    const resp = await fetch(`${API}/api/validate-jenkins`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, user }),
    });
    const data = await resp.json();
    if (!data.ok) throw new Error(data.error || 'Invalid token');
    _jkValidated = true;
    setWizStatus('w-jenkins-status', 'ok', 'Jenkins connected');
  } catch (e) {
    _jkValidated = false;
    setWizStatus('w-jenkins-status', 'error', e.message);
  }
  updateWizStatusRow();
  updateConnectBtn();
}

// ── Wizard helpers — local config step ────────────────────────────────────

async function browseDirectory(inputId) {
  try {
    const resp = await fetch(`${API}/api/pick-directory`);
    const result = await resp.json();
    if (!result.canceled && result.filePaths && result.filePaths[0]) {
      document.getElementById(inputId).value = result.filePaths[0];
    } else if (result.canceled) {
      toast('Type the path manually — native picker only works in the desktop app', 'info');
    }
  } catch (e) {
    toast('Could not open directory picker', 'info');
  }
}

async function detectTools(ijId = 's-ij-input', javaId = 's-java-input') {
  const btn = document.getElementById('s-detect-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Detecting…'; }

  try {
    const resp = await fetch(`${API}/api/detect-tools`);
    if (!resp.ok) throw new Error('Detection failed');
    const tools = await resp.json();

    let found = [];
    const ijEl = document.getElementById(ijId);
    const javaEl = document.getElementById(javaId);
    if (tools.intellijPath && ijEl) { ijEl.value = tools.intellijPath; found.push('IntelliJ CLI'); }
    if (tools.javaHome && javaEl)   { javaEl.value = tools.javaHome;   found.push('Java Home'); }

    if (found.length) toast(`Auto-detected: ${found.join(', ')}`, 'success');
    else              toast('No tools auto-detected — enter paths manually', 'info');
  } catch (e) {
    toast('Auto-detect failed: ' + e.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '⚡ Auto-detect'; }
  }
}

// ── Wizard ─────────────────────────────────────────────────────────────────
let wizStep = 1;

async function wizNext(step) {
  if (step === 1) {
    const url   = document.getElementById('w-ghurl').value.trim();
    const org   = document.getElementById('w-org').value.trim();
    const token = document.getElementById('w-token').value.trim();
    if (!url || !org || !token) { toast('All fields are required', 'error'); return; }
    if (!_ghValidated) { toast('GitHub PAT verification must succeed before connecting', 'error'); return; }
    if (!_jkValidated) { toast('Jenkins token verification must succeed before connecting', 'error'); return; }

    const btn = document.querySelector('#wpage-1 .btn-primary');
    btn.textContent = 'Connecting…'; btn.disabled = true;

    try {
      const cloneDir    = cfg.cloneDir    || '~/dev/projects/iready';
      const intellijPath = cfg.intellijPath || '';
      const javaHome    = cfg.javaHome    || '';
      const mavenArgs   = cfg.mavenArgs   || '';
      const extraEnv    = cfg.extraEnv    || '';
      const jenkinsToken    = document.getElementById('w-jenkins-token')?.value.trim() || '';

      // Always create a fresh session on Connect so it has the latest Jenkins token.
      {
        const resp = await fetch(`${API}/api/session`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ githubUrl: url, org, token, cloneDir, intellijPath, mavenArgs, extraEnv, awsProfile: cfg.awsProfile || '', servicesDir: cfg.servicesDir || '', jenkinsToken })
        });
        if (!resp.ok) throw new Error((await resp.json()).error);
        const data = await resp.json();
        sessionId = data.sessionId;
        cfg = { ...cfg, githubUrl: url, org, token, cloneDir, intellijPath, javaHome, mavenArgs, extraEnv,
          jenkinsToken, githubLogin: data.githubLogin || cfg.githubLogin || '' };
      }

      // Update Jenkins security page link with the real username now that we know it
      updateJenkinsSecurityLink(cfg.githubLogin);

      // Single toggle controls BOTH tokens: remember & reuse, or clear both so
      // the user must re-enter them next launch.
      const rememberTokens = document.getElementById('w-remember-tokens')?.checked;
      if (rememberTokens) {
        setCookie(TOKEN_COOKIE, token, TOKEN_COOKIE_DAYS);
        if (jenkinsToken) saveJenkinsCredentials({ token: jenkinsToken });
      } else {
        deleteCookie(TOKEN_COOKIE);
        clearJenkinsCredentials();
      }
      saveCache();

      // Skip local config step — go straight to Ready
      wizGoTo(2);
      document.getElementById('ready-org-label').textContent = `${org} on ${url}`;

      fetchAllRepos().then(() => {
        document.getElementById('ready-spinner').style.display = 'none';
        document.getElementById('ready-btn').style.display = 'inline-flex';
      });
    } catch(err) {
      toast('Connection failed: ' + err.message, 'error');
    } finally {
      btn.textContent = 'Connect →'; btn.disabled = false;
    }
  }
}

function wizBack(step) {
  wizGoTo(1);
}

function wizGoTo(n) {
  wizStep = n;
  document.querySelectorAll('.wiz-page').forEach((p, i) => {
    p.classList.toggle('active', i + 1 === n);
  });
  document.querySelectorAll('.wiz-step').forEach((s, i) => {
    s.classList.remove('active', 'done');
    if (i + 1 === n) s.classList.add('active');
    if (i + 1 < n)  s.classList.add('done');
  });
}

// Re-creates the server session using cached credentials. Returns true on success.
async function reconnectSession() {
  const jenkinsToken = cfg.jenkinsToken || loadJenkinsCredentials()?.token || '';
  if (!cfg.githubUrl || !cfg.org || !cfg.token || !cfg.cloneDir || !jenkinsToken) return false;
  try {
    const resp = await fetch(`${API}/api/session`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        githubUrl: cfg.githubUrl, org: cfg.org, token: cfg.token,
        cloneDir: cfg.cloneDir, intellijPath: cfg.intellijPath || '',
        mavenArgs: cfg.mavenArgs || '', extraEnv: cfg.extraEnv || '',
        awsProfile: cfg.awsProfile || '', servicesDir: cfg.servicesDir || '',
        jenkinsToken,
      }),
    });
    if (!resp.ok) return false;
    sessionId = (await resp.json()).sessionId;
    connectWebSocket();
    applySavedSudoPassword();
    return true;
  } catch { return false; }
}

function showSessionExpired() {
  toast('Session expired — reconnecting…', 'info');
  // Fall back to the wizard so the user can re-authenticate
  document.getElementById('main-app').classList.add('hidden');
  document.getElementById('wizard').style.display = '';
  wizGoTo(1);
}

function enterApp() {
  document.getElementById('wizard').style.display = 'none';
  document.getElementById('main-app').classList.remove('hidden');
  renderTopbar();
  connectWebSocket();
  applySavedSudoPassword();
  silentLoadEpRepos();
  autoConnectJira();          // also warms the JIRA history cache in the background
  prefetchDependencyGraph();  // warm the deps-tab cache in the background
  prefetchDockerServices();   // warm the docker-tab cache in the background
}

async function silentLoadEpRepos() {
  if (!sessionId) return;
  try {
    const resp = await fetch(`${API}/api/existing-repos?session=${sessionId}`);
    if (!resp.ok) return;
    const data = await resp.json();
    epRepos = data.repos || [];
    if (filteredRepos.length) renderRepoList();
  } catch (e) { /* silent */ }
}

// Silently apply the saved Mac password to the session so setup scripts
// never need to prompt. If the saved password is wrong (changed since saved),
// clear it so the user is prompted fresh next time.
async function applySavedSudoPassword() {
  const pw = loadSudoPassword();
  if (!pw || !sessionId) return;
  try {
    const resp = await fetch(`${API}/api/sudo-password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, password: pw }),
    });
    const data = await resp.json();
    if (!data.ok) {
      clearSudoPassword();
    }
  } catch (e) { /* silent — non-critical */ }
}
