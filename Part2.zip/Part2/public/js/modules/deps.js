// =============================================================================
// Dependency Graph — repo-level and module-level graph visualization (Maven + npm)
// =============================================================================

let dgNodes    = [];   // [{name, language}] cloned repos (for lang lookup)
let dgEdges    = [];   // [{from, to}]  "from depends on to"
let dgDepMap   = {};   // { repoName: ["groupId:artifactId", ...] } — all com.cain* deps
let dgSubmods  = {};   // { repoName: [{module, path, deps:[{group,artifact,repo,internal,scope}]}] }
let dgSelected = null;
let dgView     = 'repo'; // 'repo' (used-by/depends-on tree) | 'modules' (submodule graph)
let dgAnimId   = null; // kept so stopDgSim() still works from showTab
let _dgPrefetched  = false; // background prefetch has populated the graph
let _dgPrefetching = false; // a background prefetch is in flight

// Node geometry constants
const DG_NW = 200;  // node width
const DG_NH = 36;   // node height
const DG_CW = 350;  // column spacing (center-to-center) — doubled for extra gap between columns
const DG_RH = 54;   // row spacing

async function loadDependencyGraph(refresh = false, bg = false) {
  const listEl = document.getElementById('dg-list');
  const badge  = document.getElementById('dg-count-badge');
  if (!sessionId) return;
  // Background prefetch (warming the cache after login) skips the spinner so it
  // doesn't disturb whatever the user is currently looking at.
  if (!bg) {
    if (!listEl) return;
    if (badge) badge.textContent = '…';
    listEl.innerHTML = `<div class="dg-list-loading"><div class="spinner"></div></div>`;
  }

  try {
    // Pass the already-loaded repo list so the server skips the paginated GitHub fetch
    const resp = await fetch(`${API}/api/dependency-graph?session=${sessionId}${refresh ? '&refresh=1' : ''}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repos: allRepos.map(r => ({ name: r.name, language: r.language })) }),
    });
    if (!resp.ok) {
      let msg = `Server error ${resp.status}`;
      try { msg = (await resp.json()).error || msg; } catch (_) {}
      throw new Error(msg);
    }
    const data = await resp.json();
    dgNodes  = data.nodes;
    dgEdges  = data.edges;
    dgDepMap = data.depMap || {};
    dgSubmods = data.submodules || {};
    if (badge) badge.textContent = `${dgEdges.length} link${dgEdges.length !== 1 ? 's' : ''}`;
    _dgPrefetched = true;
    dgRenderRepoList();
    if (dgSelected) dgRenderTree();
  } catch (err) {
    // A background prefetch must stay invisible — leave the tab untouched so the
    // user's first real click can render the error (or retry) normally.
    if (!bg && listEl) {
      listEl.innerHTML = `<div style="padding:16px;color:var(--red);font-size:12px;font-family:var(--mono)">✗ ${escHtml(err.message)}</div>`;
    }
  }
}

// Warm the dependency-graph cache in the background after login so the "deps"
// tab opens instantly. Waits for the repo list to finish loading first so the
// server can skip its own paginated GitHub fetch (the slowest part).
async function prefetchDependencyGraph() {
  if (_dgPrefetching || _dgPrefetched || !sessionId) return;
  _dgPrefetching = true;
  try {
    // Give fetchAllRepos() up to ~30s to populate allRepos; proceed regardless.
    for (let i = 0; i < 60 && !allRepos.length; i++) {
      await new Promise(r => setTimeout(r, 500));
    }
    await loadDependencyGraph(false, true);
  } finally {
    _dgPrefetching = false;
  }
}

// Warm the Docker-tab cache in the background after login so the "docker" tab
// opens instantly. Fetches the service catalog + container statuses and renders
// into the (hidden) tab DOM, but does NOT start live polling — that begins only
// when the user actually opens the tab.
async function prefetchDockerServices() {
  if (_dockerPrefetching || _dockerLoaded || !sessionId) return;
  _dockerPrefetching = true;
  try {
    await initDockerTab(false, true);
  } finally {
    _dockerPrefetching = false;
  }
}

function dgFilterRepos() { dgRenderRepoList(); }

function dgGetLang(name) {
  return (allRepos.find(r => r.name === name) || dgNodes.find(n => n.name === name))?.language || null;
}

function dgRenderRepoList() {
  const listEl = document.getElementById('dg-list');
  if (!listEl) return;
  const term  = (document.getElementById('dg-search')?.value || '').toLowerCase().trim();
  const repos = allRepos.filter(r => !term || r.name.toLowerCase().includes(term));

  if (!repos.length) {
    listEl.innerHTML = `<div class="dg-list-empty">No repos match</div>`;
    return;
  }

  listEl.innerHTML = repos.map(r => {
    const lc  = LANG_COLORS[r.language] || '#6b7280';
    const act = r.name === dgSelected;
    const has = dgEdges.some(e => e.from === r.name || e.to === r.name);
    return `<div class="dg-list-item${act ? ' active' : ''}" data-repo="${escHtml(r.name)}">
      <span class="dg-list-dot" style="background:${lc}"></span>
      <span class="dg-list-name" title="${escHtml(r.name)}">${escHtml(r.name)}</span>
      ${has ? `<span class="dg-list-has" title="Has dependency data">⬡</span>` : ''}
    </div>`;
  }).join('');

  listEl.onclick = (e) => {
    const item = e.target.closest('[data-repo]');
    if (item) dgSelectRepo(item.dataset.repo);
  };
}

function dgSelectRepo(name) {
  dgSelected = name;
  document.querySelectorAll('#dg-list .dg-list-item').forEach(el => {
    el.classList.toggle('active', el.dataset.repo === name);
  });
  // Show the Repo/Modules toggle only for multi-module repos; reset to repo view
  // when the newly selected repo has no submodules.
  const hasMods = !!(dgSubmods[name] && dgSubmods[name].length);
  const toggle  = document.getElementById('dg-view-toggle');
  if (toggle) toggle.classList.toggle('hidden', !hasMods);
  if (!hasMods) dgView = 'repo';
  dgUpdateViewToggle();
  dgRenderTree();
  dgRenderInfoPanel();
}

function dgUpdateViewToggle() {
  document.querySelectorAll('#dg-view-toggle .dg-vt-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.view === dgView);
  });
}

function dgSetView(v) {
  if (dgView === v) return;
  dgView = v;
  dgUpdateViewToggle();
  dgRenderTree();
}

// Build 2-level tree around rootName from dgEdges
function dgBuildTree(rootName) {
  // Direct deps from edges (cloned + non-cloned repos) PLUS any in depMap that
  // match a known node but weren't captured as an edge (lookup miss).
  const allNodeNames = new Set(dgNodes.map(n => n.name));
  const depsFromEdges = new Set(dgEdges.filter(e => e.from === rootName).map(e => e.to));
  // Supplement from depMap: artifactId matching a known org repo
  for (const d of (dgDepMap[rootName] || [])) {
    const aid = d.split(':')[1] || '';
    if (allNodeNames.has(aid) && aid !== rootName) depsFromEdges.add(aid);
  }
  const deps1  = [...depsFromEdges];
  const users1 = [...new Set(dgEdges.filter(e => e.to === rootName).map(e => e.from))];

  const exclD = new Set([rootName, ...deps1]);
  const deps2 = [];
  for (const d of deps1) {
    for (const e of dgEdges) {
      if (e.from === d && !exclD.has(e.to)) { exclD.add(e.to); deps2.push(e.to); }
    }
  }

  const exclU = new Set([rootName, ...users1]);
  const users2 = [];
  for (const u of users1) {
    for (const e of dgEdges) {
      if (e.to === u && !exclU.has(e.from)) { exclU.add(e.from); users2.push(e.from); }
    }
  }

  return { rootName, deps1, deps2, users1, users2 };
}

function dgRenderTree() {
  const panel   = document.getElementById('dg-tree-panel');
  const emptyEl = document.getElementById('dg-tree-empty');
  if (!panel) return;

  if (!dgSelected) {
    if (emptyEl) emptyEl.style.display = 'flex';
    const old = panel.querySelector('svg');
    if (old) old.remove();
    return;
  }
  if (emptyEl) emptyEl.style.display = 'none';

  // Submodule graph view (multi-module repos only)
  if (dgView === 'modules' && dgSubmods[dgSelected] && dgSubmods[dgSelected].length) {
    dgRenderModuleGraph(panel);
    return;
  }

  const tree = dgBuildTree(dgSelected);

  // ── Position nodes (root at origin) ───────────────────────────────────────
  const pos = {};
  pos[tree.rootName] = { x: 0, y: 0, type: 'root' };

  const placeCol = (names, colX, type) => {
    const n = names.length;
    names.forEach((name, i) => {
      pos[name] = { x: colX, y: (i - (n - 1) / 2) * DG_RH, type };
    });
  };
  placeCol(tree.deps1,  +DG_CW, 'dep1');
  placeCol(tree.users1, -DG_CW, 'user1');

  // ── Translate to positive pixel space ────────────────────────────────────
  const PAD = 32, HDR = 26;
  const pts  = Object.values(pos);
  const x0   = Math.min(...pts.map(p => p.x)) - DG_NW / 2;
  const y0   = Math.min(...pts.map(p => p.y)) - DG_NH / 2;
  const x1   = Math.max(...pts.map(p => p.x)) + DG_NW / 2;
  const y1   = Math.max(...pts.map(p => p.y)) + DG_NH / 2;
  const svgW = (x1 - x0) + PAD * 2;
  const svgH = (y1 - y0) + PAD * 2 + HDR;
  const offX = -x0 + PAD, offY = -y0 + PAD + HDR;
  for (const p of pts) { p.px = p.x + offX; p.py = p.y + offY; }

  // ── SVG helpers ───────────────────────────────────────────────────────────
  const f  = v => v.toFixed(1);
  const bz = (sx, sy, tx, ty) => {
    const mx = (sx + tx) / 2;
    return `M${f(sx)} ${f(sy)} C${f(mx)} ${f(sy)},${f(mx)} ${f(ty)},${f(tx)} ${f(ty)}`;
  };

  const drawEdge = (fromName, toName, isDep, opacity) => {
    const s = pos[fromName], t = pos[toName];
    if (!s || !t) return '';
    const sx = s.px + DG_NW / 2, tx_ = t.px - DG_NW / 2;
    const color  = isDep ? `rgba(59,130,246,${opacity})` : `rgba(34,197,94,${opacity})`;
    const marker = isDep ? 'url(#dg-ab)' : 'url(#dg-ag)';
    return `<path d="${bz(sx,s.py,tx_,t.py)}" fill="none" stroke="${color}" stroke-width="1.5" marker-end="${marker}"/>`;
  };

  // ── Edges ─────────────────────────────────────────────────────────────────
  let eHtml = '';
  for (const u of tree.users1) eHtml += drawEdge(u, tree.rootName, false, 0.65);
  for (const d of tree.deps1)  eHtml += drawEdge(tree.rootName, d, true,  0.65);

  // ── Nodes ─────────────────────────────────────────────────────────────────
  let nHtml = '';
  const drawNode = (name) => {
    const p = pos[name];
    if (!p) return;
    const lang  = dgGetLang(name);
    const lc    = LANG_COLORS[lang] || '#6b7280';
    const nx = p.px - DG_NW / 2, ny = p.py - DG_NH / 2;
    const isR  = p.type === 'root';
    const isD1 = p.type === 'dep1';  const isD2 = p.type === 'dep2';
    const isU1 = p.type === 'user1'; const isU2 = p.type === 'user2';
    const dim  = isD2 || isU2;

    // Fill/text resolve from theme-aware CSS vars (via inline style — presentation
    // attributes can't use var()), so nodes recolor on light/dark switch.
    const fillVar = isR ? '--dg-root-fill' : dim ? '--dg-fill-dim' : '--dg-fill';
    const stroke = isR  ? '#3b82f6'
                 : isD1 ? 'rgba(59,130,246,.65)'
                 : isD2 ? 'rgba(59,130,246,.32)'
                 : isU1 ? 'rgba(34,197,94,.65)'
                 :        'rgba(34,197,94,.32)';
    const sw = isR ? 2 : 1.5;
    const tcVar = dim ? '--dg-text-dim' : isR ? '--dg-text-strong' : '--dg-text';
    const short = name.length > 25 ? name.slice(0, 25) + '…' : name;

    nHtml += `<g class="dg-node" data-name="${escHtml(name)}" style="cursor:pointer" opacity="${dim ? .72 : 1}">
      <rect x="${f(nx)}" y="${f(ny)}" width="${DG_NW}" height="${DG_NH}" rx="7"
        style="fill:var(${fillVar})" stroke="${stroke}" stroke-width="${sw}"/>
      <circle cx="${f(nx + 13)}" cy="${f(p.py)}" r="4.5" fill="${lc}"/>
      <text x="${f(nx + 24)}" y="${f(p.py)}" font-size="11" style="fill:var(${tcVar})"
        font-family="ui-monospace,Menlo,monospace" dominant-baseline="middle">${escHtml(short)}</text>
    </g>`;
  };

  // Z-order: dim nodes behind, root on top
  [...tree.users2, ...tree.deps2].forEach(drawNode);
  [...tree.users1, ...tree.deps1].forEach(drawNode);
  drawNode(tree.rootName);

  // ── Column headers ────────────────────────────────────────────────────────
  const rootPx = pos[tree.rootName].px;
  const hdrs = [
    ...(tree.users1.length ? [{ x: rootPx - DG_CW, label: 'USED BY',    clr: 'rgba(34,197,94,.7)'  }] : []),
    { x: rootPx,                                    label: 'SELECTED',   clr: 'rgb(3,86,255)' },
    ...(tree.deps1.length  ? [{ x: rootPx + DG_CW, label: 'DEPENDS ON', clr: 'rgba(59,130,246,.7)' }] : []),
  ];
  const hdrHtml = hdrs.map(h =>
    `<text x="${f(h.x)}" y="16" text-anchor="middle" font-size="9" font-weight="700"
      letter-spacing="0.07em" fill="${h.clr}"
      font-family="-apple-system,BlinkMacSystemFont,sans-serif">${escHtml(h.label)}</text>`
  ).join('');

  // ── Build SVG ─────────────────────────────────────────────────────────────
  const svgEl = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svgEl.setAttribute('width',  svgW);
  svgEl.setAttribute('height', svgH);
  svgEl.style.display = 'block';
  svgEl.innerHTML = `<defs>
    <marker id="dg-ab" markerWidth="7" markerHeight="6" refX="6.5" refY="3" orient="auto">
      <path d="M0,0.5 L0,5.5 L6.5,3 z" fill="#3b82f6"/>
    </marker>
    <marker id="dg-ag" markerWidth="7" markerHeight="6" refX="6.5" refY="3" orient="auto">
      <path d="M0,0.5 L0,5.5 L6.5,3 z" fill="#22c55e"/>
    </marker>
  </defs>
  <g id="dg-hdr">${hdrHtml}</g>
  <g id="dg-edges">${eHtml}</g>
  <g id="dg-nodes">${nHtml}</g>`;

  const old = panel.querySelector('svg');
  if (old) old.remove();
  panel.appendChild(svgEl);

  // Event delegation — one listener on the SVG
  svgEl.addEventListener('click', (e) => {
    const g = e.target.closest('.dg-node');
    if (g?.dataset.name) dgSelectRepo(g.dataset.name);
  });
}

// ── Submodule (module-level) dependency graph ─────────────────────────────────
// Renders the selected multi-module repo as a layered left→right DAG:
//   • module nodes laid out by dependency depth (consumers left, leaves right)
//   • internal module→module edges (transitive-reduced to cut clutter)
//   • external dependency nodes (deduped) — resolved repos are clickable (blue),
//     unresolved artifacts shown dashed/amber
// A Sugiyama-style layout inserts dummy nodes for multi-column edges so long
// edges route through the gaps between columns: boxes never overlap and an
// edge never passes through a box. Barycenter sweeps minimise crossings.
function dgRenderModuleGraph(panel) {
  const mods = dgSubmods[dgSelected] || [];

  // ── Build node + edge model ──────────────────────────────────────────────
  const node = {};   // id -> { id, type:'module'|'ext', label, group?, repo? }
  const ensureModule = (name) => {
    const id = 'm:' + name;
    if (!node[id]) node[id] = { id, type: 'module', label: name };
    return id;
  };
  const ensureExt = (d) => {
    const id = 'x:' + d.group + ':' + d.artifact;
    if (!node[id]) node[id] = { id, type: 'ext', label: d.artifact, group: d.group, repo: d.repo || null };
    return id;
  };

  const seen  = new Set();
  const edges = [];   // { from, to, kind:'int'|'ext' }
  const addEdge = (from, to, kind) => {
    const k = from + '→' + to;
    if (from === to || seen.has(k)) return;
    seen.add(k); edges.push({ from, to, kind });
  };
  for (const m of mods) {
    const fromId = ensureModule(m.module);
    for (const d of (m.deps || [])) {
      if (d.internal) addEdge(fromId, ensureModule(d.artifact), 'int');
      else            addEdge(fromId, ensureExt(d),             'ext');
    }
  }
  const ids = Object.keys(node);

  // ── Transitive reduction of internal edges (keeps external edges intact) ──
  const succ = {}; ids.forEach(i => succ[i] = new Set());
  for (const e of edges) if (e.kind === 'int') succ[e.from].add(e.to);
  const reach = {};
  const computeReach = (n) => {
    if (reach[n]) return reach[n];
    const s = new Set(); reach[n] = s;              // memo first → cycle-safe
    for (const w of succ[n]) { s.add(w); for (const x of computeReach(w)) s.add(x); }
    return s;
  };
  ids.forEach(computeReach);
  const layoutEdges = edges.filter(e => {
    if (e.kind !== 'int') return true;
    for (const w of succ[e.from]) if (w !== e.to && reach[w].has(e.to)) return false;
    return true;
  });

  // ── Longest-path layering: layer(to) > layer(from) for every edge ─────────
  const layer = {}; ids.forEach(i => layer[i] = 0);
  const outAdj = {}; ids.forEach(i => outAdj[i] = []);
  const indegC = {}; ids.forEach(i => indegC[i] = 0);
  for (const e of layoutEdges) { outAdj[e.from].push(e.to); indegC[e.to]++; }
  const q = ids.filter(i => indegC[i] === 0);
  while (q.length) {
    const n = q.shift();
    for (const m of outAdj[n]) {
      if (layer[n] + 1 > layer[m]) layer[m] = layer[n] + 1;
      if (--indegC[m] === 0) q.push(m);
    }
  }
  const maxLayer = Math.max(0, ...ids.map(i => layer[i]));

  // ── Build layers, inserting dummy waypoints for multi-column edges ────────
  const NW = 190, NH = 32, COL = 282, ROW = 46;
  const lanes = []; for (let i = 0; i <= maxLayer; i++) lanes.push([]);
  for (const id of ids) lanes[layer[id]].push(id);

  let dummyN = 0;
  const chains = [];                       // { edge, points:[id...] }
  const up = {}, down = {};
  const reg = (id) => { if (!up[id]) up[id] = []; if (!down[id]) down[id] = []; };
  ids.forEach(reg);
  for (const e of layoutEdges) {
    const l1 = layer[e.from], l2 = layer[e.to];
    const chain = [e.from];
    for (let l = l1 + 1; l < l2; l++) {     // only fires when l2 > l1 + 1
      const did = '_d' + (dummyN++);
      reg(did); lanes[l].push(did); chain.push(did);
    }
    chain.push(e.to);
    for (let i = 0; i + 1 < chain.length; i++) { down[chain[i]].push(chain[i + 1]); up[chain[i + 1]].push(chain[i]); }
    chains.push({ edge: e, points: chain });
  }

  // ── Barycenter ordering within each layer to reduce edge crossings ────────
  const rowOf = {};
  lanes.forEach(L => L.forEach((id, i) => rowOf[id] = i));
  const bary = (id, nbr) => {
    const ns = nbr[id]; if (!ns || !ns.length) return rowOf[id];
    return ns.reduce((s, x) => s + rowOf[x], 0) / ns.length;
  };
  for (let it = 0; it < 6; it++) {
    for (let li = 1; li <= maxLayer; li++) { lanes[li].sort((a, b) => bary(a, up)   - bary(b, up));   lanes[li].forEach((id, i) => rowOf[id] = i); }
    for (let li = maxLayer - 1; li >= 0; li--) { lanes[li].sort((a, b) => bary(a, down) - bary(b, down)); lanes[li].forEach((id, i) => rowOf[id] = i); }
  }

  // ── Pixel positions ───────────────────────────────────────────────────────
  const PAD = 28, HDR = 24;
  const maxRows = Math.max(1, ...lanes.map(L => L.length));
  const pos = {};
  lanes.forEach((L, li) => {
    const offset = (maxRows - L.length) / 2;
    L.forEach((id, idx) => {
      pos[id] = { cx: PAD + li * COL + NW / 2, cy: HDR + PAD + (idx + offset) * ROW + NH / 2 };
    });
  });
  const svgW = PAD * 2 + maxLayer * COL + NW;
  const svgH = HDR + PAD * 2 + maxRows * ROW;

  // ── Edges (routed point-to-point through dummy waypoints) ─────────────────
  const f = v => v.toFixed(1);
  const pathThrough = (pts) => {
    let d = `M${f(pts[0].x)} ${f(pts[0].y)}`;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i], mx = (a.x + b.x) / 2;
      d += ` C${f(mx)} ${f(a.y)},${f(mx)} ${f(b.y)},${f(b.x)} ${f(b.y)}`;
    }
    return d;
  };
  let eHtml = '';
  for (const { edge, points } of chains) {
    const pts = points.map((id, i) => {
      const p = pos[id];
      if (i === 0)                  return { x: p.cx + NW / 2, y: p.cy };  // right edge of source
      if (i === points.length - 1)  return { x: p.cx - NW / 2, y: p.cy };  // left edge of target
      return { x: p.cx, y: p.cy };                                         // dummy waypoint
    });
    const isInt = edge.kind === 'int';
    eHtml += `<path d="${pathThrough(pts)}" fill="none" stroke="${isInt ? 'rgba(139,92,246,.55)' : 'rgba(96,140,200,.4)'}" stroke-width="1.5" marker-end="${isInt ? 'url(#mg-ai)' : 'url(#mg-ae)'}"/>`;
  }

  // ── Nodes ───────────────────────────────────────────────────────────────
  let nHtml = '';
  for (const id of ids) {
    const p = pos[id]; if (!p) continue;
    const n = node[id];
    const nx = p.cx - NW / 2, ny = p.cy - NH / 2;
    const isMod     = n.type === 'module';
    const repoKnown = !isMod && n.repo;
    const dotc   = isMod ? '#8b5cf6' : repoKnown ? (LANG_COLORS[dgGetLang(n.repo)] || '#6b7280') : '#c08a3e';
    // Theme-aware fill via inline style:var() (presentation attrs can't use var()).
    const fillVar = isMod ? '--dg-mod-fill' : repoKnown ? '--dg-fill' : '--dg-ext-fill';
    const stroke = isMod ? '#8b5cf6' : repoKnown ? 'rgba(96,140,200,.55)' : 'rgba(192,138,62,.6)';
    const dash   = (!isMod && !repoKnown) ? ' stroke-dasharray="4 3"' : '';
    const max    = 24; const short = n.label.length > max ? n.label.slice(0, max - 1) + '…' : n.label;
    const click  = repoKnown ? ` style="cursor:pointer" data-repo="${escHtml(n.repo)}"` : '';
    const title  = isMod ? n.label : `${n.group}:${n.label}${repoKnown ? ` → ${n.repo}` : ' (not cloned)'}`;
    nHtml += `<g class="mg-node"${click}>
      <title>${escHtml(title)}</title>
      <rect x="${f(nx)}" y="${f(ny)}" width="${NW}" height="${NH}" rx="7" style="fill:var(${fillVar})" stroke="${stroke}" stroke-width="1.5"${dash}/>
      <circle cx="${f(nx + 13)}" cy="${f(p.cy)}" r="4.5" fill="${dotc}"/>
      <text x="${f(nx + 24)}" y="${f(p.cy)}" font-size="11" style="fill:var(--dg-text)" font-family="ui-monospace,Menlo,monospace" dominant-baseline="middle">${escHtml(short)}</text>
    </g>`;
  }

  const hdrHtml = `<text x="${f(PAD)}" y="15" font-size="10" font-weight="700" letter-spacing="0.06em" fill="rgba(139,92,246,.85)" font-family="-apple-system,BlinkMacSystemFont,sans-serif">${escHtml(dgSelected.toUpperCase())} · MODULE DEPENDENCIES</text>`;

  const svgEl = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svgEl.setAttribute('width', svgW);
  svgEl.setAttribute('height', svgH);
  svgEl.style.display = 'block';
  svgEl.innerHTML = `<defs>
    <marker id="mg-ai" markerWidth="7" markerHeight="6" refX="6.5" refY="3" orient="auto"><path d="M0,0.5 L0,5.5 L6.5,3 z" fill="#8b5cf6"/></marker>
    <marker id="mg-ae" markerWidth="7" markerHeight="6" refX="6.5" refY="3" orient="auto"><path d="M0,0.5 L0,5.5 L6.5,3 z" fill="rgba(96,140,200,.7)"/></marker>
  </defs>
  <g>${hdrHtml}</g>
  <g>${eHtml}</g>
  <g>${nHtml}</g>`;

  const old = panel.querySelector('svg');
  if (old) old.remove();
  panel.appendChild(svgEl);

  svgEl.addEventListener('click', (e) => {
    const g = e.target.closest('.mg-node');
    if (g?.dataset.repo) dgSelectRepo(g.dataset.repo);
  });
}

function dgRenderInfoPanel() {
  const el = document.getElementById('dg-info-panel');
  if (!el) return;

  if (!dgSelected) {
    el.innerHTML = `<div class="dg-hint">Select a repo to see its relationships</div>`;
    return;
  }

  const deps  = dgEdges.filter(e => e.from === dgSelected).map(e => e.to);
  const users = dgEdges.filter(e => e.to   === dgSelected).map(e => e.from);
  const lang  = dgGetLang(dgSelected);
  const lc    = LANG_COLORS[lang] || '#6b7280';

  const makeList = (names, cls) => {
    if (!names.length) return `<div class="dg-empty-deps">— none</div>`;
    return names.map(name => {
      const nlc = LANG_COLORS[dgGetLang(name)] || '#6b7280';
      return `<div class="dg-dep-item ${cls}" data-repo="${escHtml(name)}">
        <span class="dg-dep-dot" style="background:${nlc}"></span>
        <span class="dg-dep-name" title="${escHtml(name)}">${escHtml(name)}</span>
      </div>`;
    }).join('');
  };

  // Submodule breakdown (multi-module repos only) — lists EVERY com.cain* dep
  // per module: internal sibling modules, resolved external repos, and external
  // artifacts that aren't cloned locally (shown by group:artifact).
  const subs = dgSubmods[dgSelected] || [];
  const subHtml = subs.length ? `
    <div class="dg-info-section">
      <div class="dg-section-label" style="color:var(--text2)">▸ Submodules (${subs.length})</div>
      ${subs.map(m => {
        const body = (m.deps && m.deps.length) ? m.deps.map(d => {
          const nlc  = d.internal ? '#6b7280'
                     : d.repo     ? (LANG_COLORS[dgGetLang(d.repo)] || '#6b7280')
                     :              '#a3702b';  // unresolved external artifact
          const attr = d.repo ? ` data-repo="${escHtml(d.repo)}"` : '';
          const cls  = d.internal ? ' internal' : d.repo ? ' linked' : '';
          const tag  = d.internal ? `<span class="dg-int-tag">internal</span>`
                     : d.scope === 'test' ? `<span class="dg-int-tag">test</span>` : '';
          return `<div class="dg-submod-dep${cls}"${attr} title="${escHtml(d.group + ':' + d.artifact)}">
            <span class="dg-dep-dot" style="background:${nlc}"></span>
            <span class="dg-dep-name">${escHtml(d.artifact)}</span>
            ${tag}
          </div>`;
        }).join('') : `<div class="dg-empty-deps" style="padding-left:8px">— no org deps</div>`;
        return `<div class="dg-submod">
          <div class="dg-submod-name" title="${escHtml(m.path || m.module)}">${escHtml(m.module)}</div>
          ${body}
        </div>`;
      }).join('')}
    </div>` : '';

  el.innerHTML = `
    <div class="dg-info-name">
      ${lang ? `<div class="dg-info-lang"><span style="width:7px;height:7px;border-radius:50%;background:${lc};display:inline-block"></span>${escHtml(lang)}</div>` : ''}
      ${escHtml(dgSelected)}
    </div>
    <div class="dg-info-section">
      <div class="dg-section-label" style="color:var(--green)">← Used by (${users.length})</div>
      ${makeList(users, 'user')}
    </div>
    <div class="dg-info-section">
      <div class="dg-section-label" style="color:var(--accent)">Depends on → (${deps.length})</div>
      ${makeList(deps, 'dep')}
    </div>
    ${subHtml}
    <div class="dg-info-stats">
      <div class="dg-stat">
        <div class="dg-stat-num">${users.length}</div>
        <div class="dg-stat-label">consumers</div>
      </div>
      <div class="dg-stat">
        <div class="dg-stat-num">${deps.length}</div>
        <div class="dg-stat-label">deps</div>
      </div>
    </div>
    ${users.length === 0 && deps.length === 0 ? `<div style="font-size:11px;color:var(--text3);text-align:center;font-family:var(--mono);margin-top:4px">Click ↻ Refresh to build the full graph</div>` : ''}`;

  // Allow clicking items in the info panel to navigate
  el.querySelectorAll('[data-repo]').forEach(item => {
    item.addEventListener('click', () => dgSelectRepo(item.dataset.repo));
  });
}

function stopDgSim() {
  if (dgAnimId) { cancelAnimationFrame(dgAnimId); dgAnimId = null; }
}
