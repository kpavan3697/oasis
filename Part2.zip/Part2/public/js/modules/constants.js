// =============================================================================
// Constants, cookie helpers, language color map
// =============================================================================
/**
 * i-Ready OASIS — Frontend
 * Handles: wizard onboarding, localStorage cache, GitHub repo fetch,
 * repo selection, WebSocket log streaming, parallel job UI
 */

'use strict';

// ── Constants ──────────────────────────────────────────────────────────────
const API    = window.location.origin;
const WS_URL = window.location.origin.replace(/^http/, 'ws');
const CACHE_KEY = 'iready_oasis_v2';
const TOKEN_COOKIE = 'iready_oasis_pat';
const TOKEN_COOKIE_DAYS = 30;
const JENKINS_KEY = 'iready_oasis_jenkins';     // legacy localStorage key (migrated → cookie)
const JENKINS_COOKIE = 'iready_oasis_jenkins_token';

// ── Cookie helpers (used to optionally persist the PAT) ─────────────────────
function setCookie(name, value, days) {
  const exp = new Date(Date.now() + days * 864e5).toUTCString();
  // SameSite=Strict; not HttpOnly (set from JS) — local-tool tradeoff.
  const secure = location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${name}=${encodeURIComponent(value)}; Expires=${exp}; Path=/; SameSite=Strict${secure}`;
}
function getCookie(name) {
  const match = document.cookie.split('; ').find(c => c.startsWith(name + '='));
  return match ? decodeURIComponent(match.slice(name.length + 1)) : null;
}
function deleteCookie(name) {
  document.cookie = `${name}=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/; SameSite=Strict`;
}

// Language color map
const LANG_COLORS = {
  Java:'#b07219', JavaScript:'#f1e05a', TypeScript:'#3178c6',
  Python:'#3572A5', Ruby:'#701516', Go:'#00ADD8',
  Kotlin:'#A97BFF', Scala:'#c22d40', Shell:'#89e051',
  HTML:'#e34c26', CSS:'#563d7c', 'C#':'#178600',
};
