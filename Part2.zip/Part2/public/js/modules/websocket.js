// =============================================================================
// WebSocket — connection management and all WS message handlers
// =============================================================================
function connectWebSocket() {
  if (!sessionId) return;
  ws = new WebSocket(`${WS_URL}?session=${sessionId}`);
  ws.onmessage = (e) => handleWsMessage(JSON.parse(e.data));
  ws.onclose   = () => setTimeout(connectWebSocket, 2000); // auto-reconnect
}

function handleWsMessage(msg) {
  switch(msg.type) {
    case 'job_start':
      if (msg.stepCount && jobs[msg.jobId]) jobs[msg.jobId].stepCount = msg.stepCount;
      setJobStatus(msg.jobId, 'running');
      updateJobStep(msg.jobId, 'Starting…');
      break;
    case 'step_start':
      updateJobStep(msg.jobId, msg.label);
      startProgressCrawl(msg.jobId);
      break;
    case 'step_label':
      updateJobStep(msg.jobId, msg.label);
      break;
    case 'step_done':
      advanceJobProgress(msg.jobId);
      break;
    case 'log':
      routeLog(msg.jobId, msg.level, msg.message, msg.ts);
      break;
    case 'logs':   // batched log lines (see server flushLogs)
      if (Array.isArray(msg.entries)) {
        for (const e of msg.entries) routeLog(e.jobId, e.level, e.message, e.ts);
      }
      break;
    case 'launch_start':
      onLaunchStart(msg.repo);
      break;
    case 'launch_app_error':
      onLaunchAppError(msg.repo);
      break;
    case 'launch_stopped':
      onLaunchStopped(msg.repo, msg.code);
      break;
    case 'job_done':
      finishJob(msg.jobId, msg.success, msg.error);
      break;
    case 'sudo_required':
      showSudoPrompt(msg.reason);
      break;
    case 'script_gen_start':
    case 'script_gen_progress':
      onScriptGenProgress(msg);
      break;
    case 'script_gen_created':
      onScriptGenCreated(msg);
      break;
    case 'script_gen_failed':
      onScriptGenFailed(msg);
      break;
    case 'script_gen_done':
      onScriptGenDone(msg);
      break;
    case 'script_gen_error':
      onScriptGenError(msg);
      break;
    case 'fix_start':
      onFixStart(msg.jobId);
      break;
    case 'fix_done':
      onFixDone(msg.jobId, msg.success, msg.error, msg.cmdIndex, msg.followups);
      break;
    case 'docker_op_done':
      onDockerOpDone(msg.opId, msg.success, msg.error);
      break;
    case 'pull_start':
      toast(`Pulling ${msg.repo}…`, 'info');
      break;
    case 'pull_done':
      if (msg.success) {
        const note = msg.note ? ` (${msg.note})` : '';
        toast(`${msg.repo} — pulled successfully${note}`, 'success');
        setTimeout(() => { checkPullStatus([msg.repo]); checkEpPullStatus([msg.repo]); }, 600);
      } else {
        toast(`Pull failed for ${msg.repo}: ${msg.error || 'unknown error'}`, 'error');
      }
      break;
    case 'scheduled_job_done':
      try { showScheduledJobNotification(msg.repo, msg.results || []); } catch (e) { console.warn('[sched-notify]', e); }
      loadSchedules().then(() => updateSchedButton(msg.repo));
      break;
    case 'aws_sso_login':
      if (msg.status === 'started') {
        toast(`🔑 AWS credentials expired — opening browser for SSO login (profile: ${msg.profile || 'default'})…`, 'info');
      } else if (msg.status === 'url') {
        // Backup in case the browser didn't auto-open: a persistent, clickable link.
        showSsoLoginLink(msg.url, msg.code);
      } else if (msg.status === 'done') {
        dismissSsoLoginLink();
        toast('✅ AWS SSO login complete — retrying…', 'success');
      } else if (msg.status === 'error') {
        dismissSsoLoginLink();
        toast(`⚠️ ${msg.message || 'AWS SSO login failed'}`, 'error');
      }
      break;
  }
}

function showScheduledJobNotification(repoName, results) {
  const anyFail  = results.some(r => !r.ok && !r.funny);
  const funnyRow = results.find(r => r.funny);
  const taskRows = results.filter(r => !r.funny);

  updateScheduledJobsBtn();

  // Show a popup with all task results
  const existing = document.getElementById('sched-result-popup');
  if (existing) existing.remove();

  const popup = document.createElement('div');
  popup.id = 'sched-result-popup';
  popup.className = `sched-result-popup${anyFail ? ' sched-rp-fail' : ''}`;

  const rows = taskRows.map(r => {
    const msgShort = r.message.replace(/```[\s\S]*?```/g, '[code]').replace(/\n+/g, ' ').slice(0, 180);
    return `<div class="sched-rp-row${r.ok ? '' : ' sched-rp-row-fail'}">
      <span class="sched-rp-icon">${r.ok ? '✓' : '✗'}</span>
      <span class="sched-rp-task">${escHtml(r.task)}</span>
      <span class="sched-rp-msg">${escHtml(msgShort)}</span>
    </div>`;
  }).join('');

  const funnyHtml = funnyRow
    ? `<div class="sched-rp-funny">${escHtml(funnyRow.message)}</div>` : '';

  popup.innerHTML = `
    <div class="sched-rp-header">
      <span class="sched-rp-status-icon">${anyFail ? '⚠️' : '✅'}</span>
      <span class="sched-rp-repo">${escHtml(repoName)}</span>
      <button class="sched-rp-close" onclick="document.getElementById('sched-result-popup').remove()">✕</button>
    </div>
    <div class="sched-rp-rows">${rows}</div>
    ${funnyHtml}
  `;

  document.body.appendChild(popup);
  setTimeout(() => {
    if (popup.parentNode) {
      popup.style.opacity = '0';
      popup.style.transition = 'opacity .4s';
      setTimeout(() => popup.remove(), 400);
    }
  }, 20000);
}

function showFunnyCommentBanner(repoName, message) {
  const existing = document.getElementById('funny-comment-banner');
  if (existing) existing.remove();

  const banner = document.createElement('div');
  banner.id = 'funny-comment-banner';
  banner.className = 'funny-comment-banner';
  banner.innerHTML = `
    <div class="fcb-inner">
      <span class="fcb-icon">🎉</span>
      <div class="fcb-content">
        <div class="fcb-repo">${escHtml(repoName)} — all checks passed!</div>
        <div class="fcb-msg">${escHtml(message)}</div>
      </div>
      <button class="fcb-close" onclick="this.closest('#funny-comment-banner').remove()">✕</button>
    </div>
  `;
  document.body.appendChild(banner);
  // Auto-dismiss after 12 seconds
  setTimeout(() => { if (banner.parentNode) { banner.style.opacity = '0'; banner.style.transition = 'opacity .4s'; setTimeout(() => banner.remove(), 400); } }, 12000);
}
