// =============================================================================
// Chat — per-repo AI chat powered by Bedrock (Claude)
// =============================================================================

// Collect the most recent setup + launch console output for a repo so the chat
// can answer "why did the build fail?". Returns a trimmed string (newest lines).
function gatherChatLogs(name) {
  const lines = [];
  const setup = jobs[name]?.logs || [];
  for (const e of setup) lines.push(`[setup ${e.level}] ${e.message}`);
  const launch = epLaunchState[name]?.logs || [];
  for (const e of launch) lines.push(`[run ${e.level}] ${e.message}`);
  if (!lines.length) return '';
  // Keep the tail (failures show up at the end) within ~6000 chars.
  let text = lines.join('\n');
  if (text.length > 6000) text = text.slice(-6000);
  return text;
}

function openProjectChat(name) {
  chatRepo = name;
  chatMessages = [];
  chatLogs = gatherChatLogs(name);

  document.getElementById('chat-modal-title').textContent = name;
  document.getElementById('chat-modal-subtitle').textContent = 'Ask about this project — or why the build failed';
  document.getElementById('chat-input').value = '';

  const msgs = document.getElementById('chat-messages');
  msgs.innerHTML = '';
  appendChatBubble('assistant',
    `Hi! I can answer questions about **${escHtml(name)}** — its architecture, ` +
    `how the code works, the development flow, setup steps, or **why the latest build failed** ` +
    `(local setup or Jenkins CI). What would you like to know?`
  );

  document.getElementById('chat-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('chat-input').focus(), 100);
}

function closeProjectChat() {
  document.getElementById('chat-modal').classList.add('hidden');
  chatRepo = null;
  chatMessages = [];
}

function chatKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
}

async function callChatApi() {
  // Re-gather logs at send time so a build that ran while the chat was open is included.
  chatLogs = gatherChatLogs(chatRepo) || chatLogs;
  const resp = await fetch(`${API}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session: sessionId, repo: chatRepo, messages: chatMessages, logs: chatLogs })
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error || 'Chat failed');
  return data;
}

async function sendChatMessage() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text || !chatRepo) return;

  input.value = '';
  chatMessages.push({ role: 'user', content: text });
  appendChatBubble('user', text);

  const btn = document.getElementById('chat-send-btn');
  btn.disabled = true;
  const thinkingEl = appendChatBubble('assistant', null, true);

  try {
    let data = await callChatApi();

    // If credentials are expired, auto-refresh then retry once
    if (data.reason === 'no-access') {
      thinkingEl.innerHTML = `<span class="chat-thinking">AWS credentials expired — refreshing automatically…</span>`;
      try {
        const refreshResp = await fetch(`${API}/api/refresh-credentials`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session: sessionId }),
        });
        if (refreshResp.ok) {
          const rd = await refreshResp.json();
          if (rd.ok) {
            thinkingEl.innerHTML = `<span class="chat-thinking">Credentials refreshed — retrying…</span>`;
            data = await callChatApi();
          }
        }
      } catch (e) { /* fall through to show the refresh button */ }
    }

    const badge = data.source === 'bedrock'
      ? `<div><span class="chat-src-badge chat-src-claude">Claude · Bedrock</span></div>`
      : `<div><span class="chat-src-badge chat-src-generic">offline</span></div>`;

    const hint = data.reason === 'no-access'
      ? `<div style="margin-top:10px">
           <button class="btn btn-ghost btn-sm" onclick="refreshCredentialsAndRetryChat()">↻ Refresh AWS Credentials</button>
         </div>`
      : data.reason === 'denied'
      ? `<div style="margin-top:10px;font-size:12px;color:var(--text3)">Your AWS role doesn't have Bedrock access to <code>${escHtml(data.modelId || 'the configured model')}</code>. Ask the platform team for <code>bedrock:InvokeModel</code> on that model ID.</div>`
      : '';

    thinkingEl.innerHTML = renderMarkdown(data.reply) + badge + hint;
    chatMessages.push({ role: 'assistant', content: data.reply });
  } catch (err) {
    thinkingEl.innerHTML = `<span style="color:var(--red)">Error: ${escHtml(err.message)}</span>`;
  } finally {
    btn.disabled = false;
    document.getElementById('chat-messages').scrollTop = 9999;
  }
}

function appendChatBubble(role, text, isThinking = false) {
  const msgs = document.getElementById('chat-messages');
  // User side = the logged-in user themselves (their initial, like the topbar
  // avatar) — not a generic icon and not the org. Assistant side = Claude mark.
  const avatarContent = role === 'user'
    ? escHtml((cfg.githubLogin || cfg.org || 'U')[0].toUpperCase())
    : `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><g>
        <line x1="14.4" y1="12" x2="21.2" y2="12"/><line x1="14.1" y1="13.2" x2="20.0" y2="16.6"/>
        <line x1="13.2" y1="14.1" x2="16.6" y2="20.0"/><line x1="12" y1="14.4" x2="12" y2="21.2"/>
        <line x1="10.8" y1="14.1" x2="7.4" y2="20.0"/><line x1="9.9" y1="13.2" x2="4.0" y2="16.6"/>
        <line x1="9.6" y1="12" x2="2.8" y2="12"/><line x1="9.9" y1="10.8" x2="4.0" y2="7.4"/>
        <line x1="10.8" y1="9.9" x2="7.4" y2="4.0"/><line x1="12" y1="9.6" x2="12" y2="2.8"/>
        <line x1="13.2" y1="9.9" x2="16.6" y2="4.0"/><line x1="14.1" y1="10.8" x2="20.0" y2="7.4"/>
      </g></svg>`;
  const bubbleContent = isThinking
    ? `<span class="chat-thinking">Thinking…</span>`
    : renderMarkdown(text || '');

  const div = document.createElement('div');
  div.className = `chat-msg ${role}`;
  div.innerHTML = `
    <div class="chat-avatar">${avatarContent}</div>
    <div class="chat-bubble">${bubbleContent}</div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  return div.querySelector('.chat-bubble');
}
