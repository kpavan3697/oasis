// =============================================================================
// Utils — toast(), confirmDialog(), sleep(), escHtml(), formatSeconds()
// =============================================================================
function toast(msg, type = 'info') {
  const wrap = document.getElementById('toasts');
  const t = document.createElement('div');
  const icons = { success: '✓', error: '✗', info: 'ℹ' };
  t.className = `toast ${type}`;
  t.innerHTML = `<span>${icons[type]}</span><span>${escHtml(msg)}</span>`;
  wrap.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 4000);
}

// Persistent (non-auto-dismissing) SSO login prompt — a manual fallback shown
// when the AWS CLI prints a verification URL, in case the browser didn't auto-open.
function showSsoLoginLink(url, code) {
  dismissSsoLoginLink();
  if (!url) return;
  const wrap = document.getElementById('toasts');
  if (!wrap) return;
  const t = document.createElement('div');
  t.className = 'toast info';
  t.id = 'sso-login-link';
  t.style.flexDirection = 'column';
  t.style.alignItems = 'flex-start';
  t.style.gap = '6px';
  t.innerHTML =
    `<div style="display:flex;align-items:center;gap:8px"><span>🔑</span><span>Complete AWS SSO login in your browser</span></div>`
    + `<a href="${escHtml(url)}" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:underline;word-break:break-all;font-family:var(--mono);font-size:12px">${escHtml(url)}</a>`
    + (code ? `<div style="font-family:var(--mono);font-size:12px;color:var(--text2)">Verification code: <strong style="color:var(--text)">${escHtml(code)}</strong></div>` : '')
    + `<button onclick="dismissSsoLoginLink()" style="align-self:flex-end;background:none;border:none;color:var(--text3);cursor:pointer;font-size:12px">Dismiss</button>`;
  wrap.appendChild(t);
}
function dismissSsoLoginLink() {
  document.getElementById('sso-login-link')?.remove();
}

// ── Styled confirm dialog (replaces native confirm) ─────────────────────────
// Returns a Promise<boolean>. Matches the app's modal styling.
function uiConfirm({ title = 'Are you sure?', message = '', confirmText = 'Confirm', cancelText = 'Cancel', danger = false } = {}) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal" style="max-width:440px">
        <div class="modal-header">
          <div class="mh-icon">${danger ? '🗑️' : '❓'}</div>
          <div><div class="mh-title">${escHtml(title)}</div></div>
        </div>
        <div class="modal-body">
          <div style="font-size:14px;line-height:1.65;color:var(--text2);white-space:pre-line">${escHtml(message)}</div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost btn-sm" data-act="cancel">${escHtml(cancelText)}</button>
          <button class="btn btn-sm ${danger ? 'btn-danger' : 'btn-primary'}" data-act="ok">${escHtml(confirmText)}</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const close = (val) => { document.removeEventListener('keydown', onKey); overlay.remove(); resolve(val); };
    const onKey = (e) => { if (e.key === 'Escape') close(false); else if (e.key === 'Enter') close(true); };
    overlay.querySelector('[data-act=cancel]').onclick = () => close(false);
    overlay.querySelector('[data-act=ok]').onclick = () => close(true);
    overlay.onclick = (e) => { if (e.target === overlay) close(false); };
    document.addEventListener('keydown', onKey);
    setTimeout(() => overlay.querySelector('[data-act=ok]')?.focus(), 40);
  });
}

// ── Utilities ──────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Escape HTML then wrap any http/https URL in a clickable <a> tag.
function linkifyUrls(s) {
  return escHtml(s).replace(/(https?:\/\/[^\s<>"]+)/g,
    '<a href="$1" target="_blank" rel="noopener" class="log-link">$1</a>');
}

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}
