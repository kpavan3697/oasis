// =============================================================================
// Scheduler — create/edit/delete/run scheduled repo-setup jobs, history panel
// =============================================================================

async function loadSchedules() {
  if (!sessionId) return;
  try {
    const resp = await fetch(`${API}/api/schedule?session=${sessionId}`);
    if (resp.ok) scheduledJobs = await resp.json();
    updateScheduledJobsBtn();
  } catch (_) {}
}

function openScheduleModal(repoName) {
  document.getElementById('schedule-modal')?.remove();

  const job         = scheduledJobs[repoName] || {};
  const tasks       = job.tasks || {};
  const hasSchedule = !!scheduledJobs[repoName];
  const curFreq     = job.schedule     || 'daily';
  const curTime     = job.scheduleTime || '09:00';
  const curDays     = job.scheduleDays || ['mon','tue','wed','thu','fri'];
  const curDay      = job.scheduleDay  || 'mon';

  const DAYS = [['mon','Mon'],['tue','Tue'],['wed','Wed'],['thu','Thu'],['fri','Fri'],['sat','Sat'],['sun','Sun']];

  const multiDayPills = DAYS.map(([id, lbl]) =>
    `<button class="sm-day-pill${curDays.includes(id) ? ' active' : ''}" data-day="${id}" onclick="smToggleDay(this)">${lbl}</button>`
  ).join('');

  const singleDayPills = DAYS.map(([id, lbl]) =>
    `<button class="sm-day-pill${curDay === id ? ' active' : ''}" data-day="${id}" onclick="smPickDay(this)">${lbl}</button>`
  ).join('');

  // Time picker — a free-text "H:MM" field (12-hour) + an AM/PM toggle, instead of a
  // native <input type=time> (its picker popup renders off-screen in Electron). The
  // stored value stays "HH:MM" 24h in a hidden #sched-time field, synced by smUpdateTime().
  const [ch, cm] = String(curTime || '09:00').split(':');
  let cur24 = parseInt(ch, 10); if (isNaN(cur24)) cur24 = 9;
  const curMinNum = parseInt(cm, 10);
  const curMin   = String(isNaN(curMinNum) ? 0 : curMinNum).padStart(2, '0');
  const curAmpm  = cur24 < 12 ? 'AM' : 'PM';
  const curHour  = (cur24 % 12) === 0 ? 12 : cur24 % 12;
  const curTimeText = `${curHour}:${curMin}`;

  const taskDefs = [
    ['pull',             '⬇️', 'Pull latest code',       'Fetch & merge latest commits from remote'],
    ['buildCheck',       '🏗️', 'Build check',             'Check Jenkins CI status for current branch'],
    ['codeReview',       '🔍', 'AI code review',          'Claude reviews recent commits and surfaces issues'],
    ['securityScan',     '🔒', 'Security scan',           'npm audit / pip-audit — scan for CVEs'],
    ['codeImprovements', '✨', 'AI improvements',         'Claude reviews recent files and suggests refactors'],
  ];

  const lastRunHtml = hasSchedule && job.lastRun ? (() => {
    const statusMap = { success: ['✅', 'Success', 'sm-status-ok'], partial: ['⚠️', 'Partial', 'sm-status-warn'], failed: ['❌', 'Failed', 'sm-status-err'], running: ['⏳', 'Running', 'sm-status-run'] };
    const [icon, label, cls] = statusMap[job.lastStatus] || ['—', '', ''];
    return `<div class="sm-last-run">
      <div class="sm-last-head">
        <span class="sm-last-title">Last run</span>
        <span class="sm-status-badge ${cls}">${icon} ${label}</span>
        <span class="sm-last-when">${timeAgo(job.lastRun)}</span>
      </div>
      ${job.lastReport ? `<div class="sm-last-report">${escHtml(job.lastReport.slice(0, 400))}</div>` : ''}
    </div>`;
  })() : '';

  const showConfig = ['daily','weekly'].includes(curFreq);

  const modal = document.createElement('div');
  modal.id = 'schedule-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal sm-modal">
      <div class="modal-header sm-header">
        <div class="modal-title sm-modal-title">${SCHED_SVG} <span class="sm-title-repo" title="${escHtml(repoName)}">${escHtml(repoName)}</span></div>
        <input type="hidden" id="sched-freq" value="${curFreq}"/>
        <div class="sm-pills">
          <button class="sm-pill ${curFreq==='manual'  ? 'active':''}" onclick="smSetFreq(this,'manual')">Manual</button>
          <button class="sm-pill ${curFreq==='hourly'  ? 'active':''}" onclick="smSetFreq(this,'hourly')">Every hour</button>
          <button class="sm-pill ${curFreq==='daily'   ? 'active':''}" onclick="smSetFreq(this,'daily')">Daily</button>
          <button class="sm-pill ${curFreq==='weekly'  ? 'active':''}" onclick="smSetFreq(this,'weekly')">Weekly</button>
        </div>
        <button class="modal-close" onclick="document.getElementById('schedule-modal').remove()">✕</button>
      </div>
      <div class="modal-body sm-body">

        <div class="sm-sched-config" id="sched-config" style="display:${showConfig ? 'flex' : 'none'}">
          <div class="sm-config-row" id="sched-days-wrap" style="display:${curFreq==='daily' ? 'flex' : 'none'}">
            <span class="sm-row-label">Days</span>
            <div class="sm-day-pills" id="sched-days-multi">${multiDayPills}</div>
          </div>
          <div class="sm-config-row" id="sched-day-wrap" style="display:${curFreq==='weekly' ? 'flex' : 'none'}">
            <span class="sm-row-label">Day</span>
            <div class="sm-day-pills" id="sched-day-single">${singleDayPills}</div>
          </div>
          <div class="sm-config-row">
            <span class="sm-row-label">Time</span>
            <div class="sm-time-group">
              <div class="sm-stepper" onwheel="smWheelHour(event)">
                <button class="sm-step-btn" onclick="smSpinHour(-1)" title="Decrease hour">−</button>
                <div class="sm-step-val" id="sched-hour-disp">${curHour}</div>
                <button class="sm-step-btn" onclick="smSpinHour(1)"  title="Increase hour">+</button>
              </div>
              <span class="sm-time-sep">:</span>
              <div class="sm-stepper" onwheel="smWheelMin(event)">
                <button class="sm-step-btn" onclick="smSpinMin(-5)" title="Decrease minute">−</button>
                <div class="sm-step-val" id="sched-min-disp">${curMin}</div>
                <button class="sm-step-btn" onclick="smSpinMin(5)"  title="Increase minute">+</button>
              </div>
              <div class="sm-ampm-toggle">
                <button type="button" class="sm-ampm-btn ${curAmpm==='AM'?'active':''}" data-ampm="AM" onclick="smSetAmpm(this)">AM</button>
                <button type="button" class="sm-ampm-btn ${curAmpm==='PM'?'active':''}" data-ampm="PM" onclick="smSetAmpm(this)">PM</button>
              </div>
            </div>
            <input type="hidden" id="sched-time" value="${curTime}"/>
          </div>
        </div>

        <div class="sm-tasks-wrap">
          <div class="sm-section-label">Tasks</div>
          <div class="sm-tasks">
            ${taskDefs.map(([id, icon, name, desc]) => `
              <label class="sm-task${tasks[id] ? ' checked' : ''}" id="sm-task-lbl-${id}" onclick="smToggleTask(this,'${id}')">
                <div class="sm-task-row">
                  <div class="sm-task-tick">${tasks[id] ? '✓' : ''}</div>
                  <span class="sm-task-icon">${icon}</span>
                  <span class="sm-task-name">${name}</span>
                </div>
                <div class="sm-task-desc">${desc}</div>
                <input type="checkbox" id="stask-${id}" ${tasks[id] ? 'checked' : ''} style="display:none"/>
              </label>`).join('')}
          </div>
        </div>

        ${lastRunHtml}

        <div class="sm-notify-note">🔔 Desktop notification on completion</div>
      </div>
      <div class="modal-footer">
        ${hasSchedule ? `<button class="btn btn-danger-ghost" onclick="deleteSchedule('${escHtml(repoName)}')">Remove</button>` : '<span></span>'}
        <div style="flex:1"></div>
        <button class="btn btn-ghost" onclick="runScheduleNow('${escHtml(repoName)}')">▶ Run Now</button>
        <button class="btn btn-ghost" onclick="document.getElementById('schedule-modal').remove()">Cancel</button>
        <button class="btn btn-primary" onclick="saveSchedule('${escHtml(repoName)}')">Save</button>
      </div>
    </div>`;

  document.body.appendChild(modal);

  const closeScheduleModal = () => { document.removeEventListener('keydown', onScheduleKey); modal.remove(); };
  const onScheduleKey = (e) => { if (e.key === 'Escape') closeScheduleModal(); };
  modal.addEventListener('click', (e) => { if (e.target === modal) closeScheduleModal(); });
  document.addEventListener('keydown', onScheduleKey);
}

function smSetFreq(btn, freq) {
  document.getElementById('sched-freq').value = freq;
  document.querySelectorAll('.sm-pill').forEach(b => b.classList.toggle('active', b === btn));
  const config   = document.getElementById('sched-config');
  const daysWrap = document.getElementById('sched-days-wrap');
  const dayWrap  = document.getElementById('sched-day-wrap');
  if (config)   config.style.display   = ['daily','weekly'].includes(freq) ? 'flex' : 'none';
  if (daysWrap) daysWrap.style.display = freq === 'daily'  ? 'flex' : 'none';
  if (dayWrap)  dayWrap.style.display  = freq === 'weekly' ? 'flex' : 'none';
}

function smToggleDay(btn) {
  btn.classList.toggle('active');
}

function smPickDay(btn) {
  document.querySelectorAll('#sched-day-single .sm-day-pill').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function smSyncTime() {
  const h  = parseInt(document.getElementById('sched-hour-disp')?.textContent || '9', 10);
  const m  = parseInt(document.getElementById('sched-min-disp')?.textContent  || '0', 10);
  const ap = document.querySelector('.sm-ampm-btn.active')?.dataset.ampm || 'AM';
  let H = h % 12;
  if (ap === 'PM') H += 12;
  const hidden = document.getElementById('sched-time');
  if (hidden) hidden.value = `${String(H).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function smFlip(el, text) {
  el.classList.remove('sm-flip');
  void el.offsetWidth; // reflow to restart animation
  el.textContent = text;
  el.classList.add('sm-flip');
}

function smSpinHour(dir) {
  const el = document.getElementById('sched-hour-disp');
  if (!el) return;
  let h = parseInt(el.textContent, 10) + dir;
  if (h > 12) h = 1;
  if (h < 1)  h = 12;
  smFlip(el, String(h));
  smSyncTime();
}

function smSpinMin(dir) {
  const el = document.getElementById('sched-min-disp');
  if (!el) return;
  let m = parseInt(el.textContent, 10) + dir;
  if (m >= 60) m = m - 60;
  if (m < 0)   m = 60 + m;
  smFlip(el, String(m).padStart(2, '0'));
  smSyncTime();
}

function smWheelHour(e) { e.preventDefault(); smSpinHour(e.deltaY < 0 ? 1 : -1); }
function smWheelMin(e)  { e.preventDefault(); smSpinMin(e.deltaY < 0 ? 5 : -5); }

function smSetAmpm(btn) {
  document.querySelectorAll('.sm-ampm-btn').forEach(b => b.classList.toggle('active', b === btn));
  smSyncTime();
}

function smUpdateTime()    { smSyncTime(); }
function smNormalizeTime() { smSyncTime(); }

function smToggleTask(lbl, id) {
  const cb = document.getElementById('stask-' + id);
  if (!cb) return;
  cb.checked = !cb.checked;
  lbl.classList.toggle('checked', cb.checked);
  lbl.querySelector('.sm-task-tick').textContent = cb.checked ? '✓' : '';
}

async function saveSchedule(repoName) {
  const freq = document.getElementById('sched-freq')?.value || 'manual';
  const time = document.getElementById('sched-time')?.value || '09:00';

  const scheduleDays = freq === 'daily'
    ? [...document.querySelectorAll('#sched-days-multi .sm-day-pill.active')].map(b => b.dataset.day)
    : [];
  const scheduleDay = freq === 'weekly'
    ? (document.querySelector('#sched-day-single .sm-day-pill.active')?.dataset.day || 'mon')
    : '';

  if (freq === 'daily' && scheduleDays.length === 0) {
    toast('Select at least one day', 'error'); return;
  }

  const tasks = {};
  ['pull','buildCheck','codeReview','securityScan','codeImprovements'].forEach(id => {
    tasks[id] = document.getElementById(`stask-${id}`)?.checked || false;
  });

  const activeTasks = Object.values(tasks).filter(Boolean).length;
  if (activeTasks === 0) { toast('Select at least one task to schedule', 'error'); return; }

  try {
    const resp = await fetch(`${API}/api/schedule/${encodeURIComponent(repoName)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, schedule: freq, scheduleTime: time, scheduleDays, scheduleDay, tasks, slack: {} }),
    });
    if (!resp.ok) throw new Error((await resp.json()).error || 'Save failed');

    scheduledJobs[repoName] = { schedule: freq, scheduleTime: time, scheduleDays, scheduleDay, tasks, slack: {}, lastStatus: scheduledJobs[repoName]?.lastStatus || null, lastRun: scheduledJobs[repoName]?.lastRun || null };
    document.getElementById('schedule-modal')?.remove();
    updateSchedButton(repoName);
    const DAY_LABELS = { mon:'Mon',tue:'Tue',wed:'Wed',thu:'Thu',fri:'Fri',sat:'Sat',sun:'Sun' };
    const schedLabel = freq === 'manual' ? 'manual only'
      : freq === 'hourly' ? 'hourly'
      : freq === 'daily'  ? `daily (${scheduleDays.map(d => DAY_LABELS[d]).join(', ')}) at ${time}`
      : `weekly (${DAY_LABELS[scheduleDay]}) at ${time}`;
    toast(`Schedule saved for ${repoName} — ${schedLabel}`, 'success');
  } catch (e) {
    toast('Failed to save: ' + e.message, 'error');
  }
}

async function deleteSchedule(repoName) {
  try {
    await fetch(`${API}/api/schedule/${encodeURIComponent(repoName)}?session=${sessionId}`, { method: 'DELETE' });
    delete scheduledJobs[repoName];
    document.getElementById('schedule-modal')?.remove();
    updateSchedButton(repoName);
    toast(`Schedule removed for ${repoName}`, 'info');
  } catch (e) {
    toast('Failed to remove: ' + e.message, 'error');
  }
}

async function runScheduleNow(repoName) {
  // Read current modal state so Run Now works even before saving
  const freq = document.getElementById('sched-freq')?.value || 'manual';
  const time = document.getElementById('sched-time')?.value || '09:00';
  const scheduleDays = freq === 'daily'
    ? [...document.querySelectorAll('#sched-days-multi .sm-day-pill.active')].map(b => b.dataset.day)
    : [];
  const scheduleDay = freq === 'weekly'
    ? (document.querySelector('#sched-day-single .sm-day-pill.active')?.dataset.day || 'mon')
    : '';
  const tasks = {};
  ['pull','buildCheck','codeReview','securityScan','codeImprovements'].forEach(id => {
    tasks[id] = document.getElementById(`stask-${id}`)?.checked || false;
  });

  if (!Object.values(tasks).some(Boolean)) { toast('Select at least one task first', 'error'); return; }

  // Persist current settings so the server has a job config to run
  try {
    await fetch(`${API}/api/schedule/${encodeURIComponent(repoName)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, schedule: freq, scheduleTime: time, scheduleDays, scheduleDay, tasks, slack: {} }),
    });
    scheduledJobs[repoName] = { schedule: freq, scheduleTime: time, scheduleDays, scheduleDay, tasks, slack: {},
      lastStatus: scheduledJobs[repoName]?.lastStatus || null, lastRun: scheduledJobs[repoName]?.lastRun || null };
  } catch (_) {}

  document.getElementById('schedule-modal')?.remove();
  toast(`Running scheduled jobs for ${repoName}…`, 'info');
  try {
    const resp = await fetch(`${API}/api/schedule/${encodeURIComponent(repoName)}/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId }),
    });
    if (!resp.ok) throw new Error((await resp.json()).error || 'Run failed');
    updateSchedButton(repoName);
    setTimeout(async () => { await loadSchedules(); updateSchedButton(repoName); }, 8000);
    toast(`Jobs started — results will appear when done`, 'success');
  } catch (e) {
    toast('Failed to run: ' + e.message, 'error');
  }
}

function updateSchedButton(repoName) {
  const n = escHtml(repoName);
  const btn = document.getElementById(`ep-sched-${n}`);
  if (!btn) return;
  const job = scheduledJobs[repoName];
  btn.className = `proj-act-btn proj-sched-btn ${job ? 'active' : ''}`;
  btn.title = job ? 'Edit scheduled jobs' : 'Schedule automated jobs';
  btn.innerHTML = SCHED_SVG + (job ? `<span class="sched-status-dot sched-dot-${job.lastStatus || 'none'}"></span>` : '');
}
