// =============================================================================
// Existing Repos — local clone listing, watch stars, branch create/view, pull-status badges, IntelliJ launch
// =============================================================================

let epRepos = [];   // [{name, branch, lastCommit, language, ...}]
let _epLoaded = false;  // true after first successful fetch — skip re-fetch on tab switch
let _epConsoleRepo = null;  // name of repo whose logs are in the bottom drawer (null = closed)
const epLaunchState = {};  // { [repoName]: { running, userStopped, logs: [] } }

const WATCHED_KEY = 'iready_oasis_watched';
function loadWatched()  { try { return new Set(JSON.parse(localStorage.getItem(WATCHED_KEY) || '[]')); } catch { return new Set(); } }
function saveWatched(s) {
  try { localStorage.setItem(WATCHED_KEY, JSON.stringify([...s])); } catch {}
  saveCacheToFile();
}
let watchedRepos = loadWatched();

async function loadExistingProjects(force) {
  if (_epLoaded && !force) {
    // Already have data — re-render from cache but still refresh pull status
    renderExistingProjects();
    if (epRepos.length) {
      setTimeout(() => checkEpPullStatus(epRepos.map(r => r.name)), 50);
      setTimeout(() => checkRepoBadges(epRepos), 200);
      setTimeout(() => loadContributors(epRepos.map(r => r.name)), 250);
    }
    return;
  }
  const grid = document.getElementById('ep-grid');
  if (!grid || !sessionId) return;

  grid.innerHTML = `<div class="ep-loading"><div class="spinner"></div>Loading cloned repositories…</div>`;

  try {
    const resp = await fetch(`${API}/api/existing-repos?session=${sessionId}`);
    if (!resp.ok) throw new Error((await resp.json()).error || 'Failed');
    const data = await resp.json();

    // Enrich with allRepos metadata where available
    epRepos = (data.repos || []).map(r => {
      const meta = allRepos.find(ar => ar.name === r.name) || {};
      return { ...r, language: meta.language || null, description: meta.description || '' };
    });

    _epLoaded = true;

    const countEl = document.getElementById('ep-count-badge');
    if (countEl) countEl.textContent = `${epRepos.length} cloned`;

    // Refresh home-tab sidebar so already-cloned repos appear disabled.
    renderRepoList();

    // Load schedules in parallel with the render so buttons reflect saved state
    loadSchedules().then(() => renderExistingProjects()).catch(() => renderExistingProjects());

    // Kick off pull-status + PR/Jenkins badge checks in background
    if (epRepos.length) {
      setTimeout(() => checkEpPullStatus(epRepos.map(r => r.name)), 100);
      setTimeout(() => checkRepoBadges(epRepos), 300);
      setTimeout(() => loadContributors(epRepos.map(r => r.name)), 350);
    }
  } catch (err) {
    grid.innerHTML = `<div class="ep-empty" style="color:var(--red)">✗ ${escHtml(err.message)}</div>`;
  }
}

function refreshExistingProjects() {
  loadExistingProjects(true);
}

function filterExistingProjects() {
  renderExistingProjects();
  // Re-render wipes card DOM — replay cached badge data onto the new nodes.
  // Only visible cards have elements in the DOM; applyPullBadge/applyRepoBadges
  // already guard against null, so iterating all epRepos is safe.
  const missingPull = [], missingBadges = [];
  epRepos.forEach(r => {
    if (_pullStatusCache[r.name] !== undefined) {
      applyPullBadge(document.getElementById(`eppull-${escHtml(r.name)}`), _pullStatusCache[r.name], r.name);
    } else {
      missingPull.push(r.name);
    }
    if (_badgeCache[r.name] !== undefined) {
      applyRepoBadges(r.name, _badgeCache[r.name]);
    } else {
      missingBadges.push(r);
    }
    if (r.name in _contribCache) renderContribs(r.name, _contribCache[r.name]);
  });
  if (missingPull.length)   setTimeout(() => checkEpPullStatus(missingPull), 50);
  if (missingBadges.length) setTimeout(() => checkRepoBadges(missingBadges), 100);
  const missingContribs = epRepos.map(r => r.name).filter(n => !(n in _contribCache));
  if (missingContribs.length) setTimeout(() => loadContributors(missingContribs), 150);
}

// ── Watch toggle ────────────────────────────────────────────────────────────
// Shared pull-status badge renderer — used by all three render paths
// (initial load, watch-toggle cache replay, and checkPullStatus).
function applyPullBadge(el, info, repoName) {
  if (!el) return;
  const TICK = `<svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="2,6 5,9 10,3"/></svg>`;
  const ARROW = `<svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="1" x2="6" y2="9"/><polyline points="3,6.5 6,9.5 9,6.5"/></svg>`;

  if (!info.cloned) {
    el.innerHTML = 'not cloned';
    el.className = 'proj-pull-badge';
    el.title = 'Clone this repo first via Setup Workspace';
    el.onclick = null;
  } else if (info.behind > 0) {
    el.innerHTML = `${ARROW} ${info.behind} · pull`;
    el.className = 'proj-pull-badge can-pull';
    el.title = `${info.behind} commit${info.behind > 1 ? 's' : ''} behind — click to pull`;
    el.onclick = () => pullRepo(repoName);
  } else {
    el.innerHTML = `${TICK} up to date`;
    el.className = 'proj-pull-badge up-to-date';
    el.title = 'Up to date with remote';
    el.onclick = null;
  }
}

function toggleWatch(name) {
  if (watchedRepos.has(name)) watchedRepos.delete(name);
  else watchedRepos.add(name);
  saveWatched(watchedRepos);
  renderExistingProjects();
  // Re-render wipes the card DOM — replay cached data immediately, no network
  // calls. The cache was populated by the initial load; only re-fetch if a
  // repo has no cached data yet (e.g. watch was toggled before first load).
  const missing = { pull: [], badges: [] };
  epRepos.forEach(r => {
    if (_pullStatusCache[r.name] !== undefined) {
      applyPullBadge(document.getElementById(`eppull-${escHtml(r.name)}`), _pullStatusCache[r.name], r.name);
    } else {
      missing.pull.push(r.name);
    }
    if (_badgeCache[r.name] !== undefined) {
      applyRepoBadges(r.name, _badgeCache[r.name]);
    } else {
      missing.badges.push(r);
    }
  });
  // Only fetch for repos that haven't been loaded yet
  if (missing.pull.length)   setTimeout(() => checkEpPullStatus(missing.pull), 50);
  if (missing.badges.length) setTimeout(() => checkRepoBadges(missing.badges), 100);
}

// ── Branch modal ────────────────────────────────────────────────────────────
async function openBranchModal(name) {
  const existing = document.getElementById('branch-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'branch-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal branch-modal">
      <div class="modal-header">
        <div class="modal-title">⎇ Branches — ${escHtml(name)}</div>
        <button class="modal-close" onclick="document.getElementById('branch-modal').remove()">✕</button>
      </div>
      <div class="modal-body">
        <div id="branch-list-inner" class="branch-list"><div class="sug-loading" style="padding:12px">Loading branches…</div></div>
      </div>
    </div>`;
  document.body.appendChild(modal);

  try {
    const resp = await fetch(`${API}/api/branches?session=${sessionId}&repo=${encodeURIComponent(name)}`);
    const data = await resp.json();
    const list = document.getElementById('branch-list-inner');
    if (!list) return;

    const sectionLabel = txt =>
      `<div style="font-size:11px;color:var(--text3);font-family:var(--mono);padding:6px 10px 3px;text-transform:uppercase;letter-spacing:.06em">${txt}</div>`;

    const localRows = (data.branches || []).map(b => `
      <div class="branch-item${b.current ? ' current' : ''}" onclick="${b.current ? '' : `switchBranch('${name}','${escHtml(b.name)}')`}">
        <span class="branch-item-name">${escHtml(b.name)}${b.current ? ' ✓' : ''}</span>
        ${!b.current ? `<button class="branch-item-del" title="Delete branch" onclick="event.stopPropagation();deleteBranch('${name}','${escHtml(b.name)}')">✕</button>` : ''}
      </div>`).join('');

    const remoteRows = (data.remoteBranches || []).map(b => `
      <div class="branch-item" title="Create local branch tracking ${escHtml(b.remoteFull)}"
           onclick="switchBranch('${name}','${escHtml(b.name)}','${escHtml(b.remoteFull)}')">
        <span class="branch-item-name">${escHtml(b.name)}</span>
        <span style="font-size:10px;color:var(--text3);flex-shrink:0;font-family:var(--mono);background:var(--panel2);padding:1px 5px;border-radius:3px">remote</span>
      </div>`).join('');

    list.innerHTML =
      (localRows  ? sectionLabel('Local')  + localRows  : '') +
      (remoteRows ? `<div style="border-top:1px solid var(--border);margin-top:4px"></div>` + sectionLabel('Remote — click to create local') + remoteRows : '');
  } catch (e) {
    const list = document.getElementById('branch-list-inner');
    if (list) list.innerHTML = `<div style="color:var(--red);padding:12px">✗ ${escHtml(e.message)}</div>`;
  }
}

async function switchBranch(repo, branch, remoteFull) {
  document.getElementById('branch-modal')?.remove();
  try {
    const resp = await fetch(`${API}/api/switch-branch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo, branch, remoteFull }),
    });
    const d = await resp.json();
    if (!d.ok) throw new Error(d.error || 'Switch failed');
    const r = epRepos.find(x => x.name === repo);
    if (r) r.branch = branch;
    renderExistingProjects();
    // Re-render resets all cards to default (Jenkins disabled, badges blank).
    // Replay both caches so every repo's status is immediately restored.
    epRepos.forEach(r => {
      applyPullBadge(document.getElementById(`eppull-${escHtml(r.name)}`), _pullStatusCache[r.name] || {}, r.name);
      if (_badgeCache[r.name]) applyRepoBadges(r.name, _badgeCache[r.name]);
    });
    toast(remoteFull ? `Created local branch "${branch}" tracking ${remoteFull}` : `Switched ${repo} to ${branch}`, 'success');
  } catch (e) {
    toast(`Branch switch failed: ${e.message}`, 'error');
  }
}

function promptCreateBranch(repo) {
  const existing = document.getElementById('create-branch-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'create-branch-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal" style="max-width:380px">
      <div class="modal-header">
        <div class="modal-title">${BRANCH_SVG} New Branch — ${escHtml(repo)}</div>
        <button class="modal-close" onclick="document.getElementById('create-branch-modal').remove()">✕</button>
      </div>
      <div class="modal-body">
        <div class="field">
          <label>Branch name</label>
          <input id="new-branch-input" type="text" placeholder="feature/my-feature"
            onkeydown="if(event.key==='Enter') submitCreateBranch('${repo}')"/>
          <div class="field-hint">Created from current HEAD and checked out immediately.</div>
        </div>
        <div id="new-branch-error" style="color:var(--red);font-size:13px;margin-top:6px;display:none"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="document.getElementById('create-branch-modal').remove()">Cancel</button>
        <button class="btn btn-primary" onclick="submitCreateBranch('${repo}')">Create &amp; Switch</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
  setTimeout(() => document.getElementById('new-branch-input')?.focus(), 50);
}

async function submitCreateBranch(repo) {
  const input = document.getElementById('new-branch-input');
  const errEl = document.getElementById('new-branch-error');
  const branch = input?.value.trim();
  if (!branch) { if (errEl) { errEl.style.display = ''; errEl.textContent = 'Branch name is required.'; } return; }

  const btn = document.querySelector('#create-branch-modal .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }
  if (errEl) errEl.style.display = 'none';

  try {
    const resp = await fetch(`${API}/api/create-branch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo, branch }),
    });
    const d = await resp.json();
    if (!d.ok) throw new Error(d.error || 'Create failed');
    document.getElementById('create-branch-modal')?.remove();
    const r = epRepos.find(x => x.name === repo);
    if (r) r.branch = branch;
    renderExistingProjects();
    toast(`Created and switched to ${branch}`, 'success');
  } catch (e) {
    if (errEl) { errEl.style.display = ''; errEl.textContent = '✗ ' + e.message; }
    if (btn) { btn.disabled = false; btn.textContent = 'Create & Switch'; }
  }
}

async function deleteBranch(repo, branch) {
  if (!confirm(`Delete local branch "${branch}" from ${repo}?`)) return;
  try {
    const resp = await fetch(`${API}/api/delete-branch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo, branch }),
    });
    const d = await resp.json();
    if (!d.ok) throw new Error(d.error || 'Delete failed');
    toast(`Deleted branch ${branch}`, 'success');
    openBranchModal(repo); // refresh the modal
  } catch (e) {
    // Try force delete
    if (confirm(`Branch "${branch}" may not be fully merged. Force delete?`)) {
      const r2 = await fetch(`${API}/api/delete-branch`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session: sessionId, repo, branch, force: true }),
      }).then(r => r.json()).catch(() => ({}));
      if (r2.ok) { toast(`Force-deleted ${branch}`, 'success'); openBranchModal(repo); }
      else toast(`Delete failed: ${r2.error || e.message}`, 'error');
    }
  }
}

// Cache so re-renders (e.g. watch toggle) can replay badges without re-fetching.
let _badgeCache = {};

function applyRepoBadges(repoName, badge) {
  const card    = document.getElementById(`ep-card-${escHtml(repoName)}`);
  const badgeEl = document.getElementById(`ep-badges-${escHtml(repoName)}`);
  if (!badgeEl) return;

  const parts = [];
  if (badge.pr) {
    parts.push(
      `<a class="ep-badge ep-badge-pr" href="${escHtml(badge.pr.url)}" target="_blank" title="${escHtml(badge.pr.title)}">` +
      `<svg viewBox="0 0 16 16" width="11" height="11" fill="currentColor"><path d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"/></svg>` +
      ` PR #${badge.pr.number}</a>`
    );
    // Collapse description to 1 line when PR is present to make room
    const descEl = card && card.querySelector('.ep-desc');
    if (descEl) { descEl.style.webkitLineClamp = '1'; descEl.style.height = '18px'; }
  } else {
    const descEl = card && card.querySelector('.ep-desc');
    if (descEl) { descEl.style.webkitLineClamp = ''; descEl.style.height = ''; }
  }

  const jBtn = document.getElementById(`ep-jenkins-${escHtml(repoName)}`);
  if (jBtn && badge.jenkins) {
    const { result, url, building, number, error } = badge.jenkins;
    if (error === 'no-token') {
      jBtn.title = 'Jenkins: configure token in Settings';
      jBtn.style.opacity = '0.35';
    } else if (error) {
      // Non-auth errors (e.g. 404 job not found) — still enable so user can navigate to Jenkins
      jBtn.title = `Jenkins: ${error}`;
      jBtn.style.opacity = '0.55';
      if (url) {
        jBtn.disabled = false;
        jBtn.onclick = () => window.open(url, '_blank');
      }
    } else {
      const failed  = result === 'FAILURE' || result === 'UNSTABLE';
      const running = building || result === null;
      jBtn.disabled = false;
      jBtn.style.opacity = '1';
      jBtn.title = failed ? `Build #${number} FAILED — click to open`
        : running ? `Build #${number} in progress — click to open`
        : `Build #${number} passed — click to open`;
      if (url) jBtn.onclick = () => window.open(url, '_blank');
      if (card && failed) card.classList.add('ep-card-build-fail');
      if (card && !failed) card.classList.remove('ep-card-build-fail');
      if (jBtn && failed) jBtn.classList.add('jenkins-build-fail');
      if (jBtn && !failed) jBtn.classList.remove('jenkins-build-fail');
    }
  }

  badgeEl.innerHTML = parts.join('');
}

async function checkRepoBadges(repos) {
  if (!repos.length || !sessionId) return;
  try {
    const names    = repos.map(r => encodeURIComponent(r.name)).join(',');
    const branches = repos.map(r => encodeURIComponent(r.branch || '')).join(',');
    const resp = await fetch(`${API}/api/repo-badges?session=${sessionId}&repos=${names}&branches=${branches}`);
    if (!resp.ok) return;
    const data = await resp.json();
    Object.assign(_badgeCache, data);
    // Re-render sections so failed-build repos move into the right section,
    // then replay all caches onto the freshly-built DOM.
    renderExistingProjects();
    epRepos.forEach(r => {
      if (_pullStatusCache[r.name] !== undefined)
        applyPullBadge(document.getElementById(`eppull-${escHtml(r.name)}`), _pullStatusCache[r.name], r.name);
      if (_badgeCache[r.name]) applyRepoBadges(r.name, _badgeCache[r.name]);
    });
  } catch (_) {}
}

// Eye orange — default (not watching)
const EYE_SVG = `<svg viewBox="0 0 16 16" width="16" height="16" fill="#f97316">
  <path d="M8 3C4.5 3 1.5 5.5 0 8c1.5 2.5 4.5 5 8 5s6.5-2.5 8-5c-1.5-2.5-4.5-5-8-5zm0 8a3 3 0 110-6 3 3 0 010 6zm0-1.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"/>
</svg>`;
// Eye green — watching
const EYE_WATCH_SVG = `<svg viewBox="0 0 16 16" width="16" height="16" fill="#22c55e">
  <path d="M8 3C4.5 3 1.5 5.5 0 8c1.5 2.5 4.5 5 8 5s6.5-2.5 8-5c-1.5-2.5-4.5-5-8-5zm0 8a3 3 0 110-6 3 3 0 010 6zm0-1.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"/>
</svg>`;

const JENKINS_SVG = `<img src="img/jenkins.png" width="18" height="18" style="object-fit:contain;display:block" alt="Jenkins"/>`;

const SCHED_SVG = `<svg viewBox="0 0 16 16" width="15" height="15" fill="currentColor">
  <path d="M8 0a8 8 0 100 16A8 8 0 008 0zm0 1.5a6.5 6.5 0 110 13 6.5 6.5 0 010-13zM7.25 4a.75.75 0 011.5 0v4.25l2.5 1.44a.75.75 0 01-.75 1.3l-2.875-1.66A.75.75 0 017.25 8.5V4z"/>
</svg>`;

const BRANCH_SVG = `<svg viewBox="0 0 16 16" width="11" height="11" fill="currentColor">
  <path d="M11.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zM10 3.25a1.75 1.75 0 113.5 0 1.75 1.75 0 01-3.5 0zM4.25 7a.75.75 0 100 1.5.75.75 0 000-1.5zM2.5 7.75a1.75 1.75 0 113.5 0 1.75 1.75 0 01-3.5 0zm-1.25 5.75a.75.75 0 100 1.5.75.75 0 000-1.5zM0 12.75a1.75 1.75 0 113.5 0 1.75 1.75 0 01-3.5 0z"/>
  <path d="M4.25 8.5A.75.75 0 015 9v3.25a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zM4.25 5.25A.75.75 0 015 6v.25a3.5 3.5 0 003.5 3.5H10a.75.75 0 000-1.5H8.5A2 2 0 016.5 6.25V6a.75.75 0 00-.75-.75H5A.75.75 0 004.25 5.25z"/>
</svg>`;

function buildEpCard(repo) {
  const lc = LANG_COLORS[repo.language] || '#6b7280';
  const n  = escHtml(repo.name);
  const branch = escHtml(repo.branch || 'unknown');
  const commit = repo.lastCommit ? timeAgo(repo.lastCommit) : '—';
  const watching = watchedRepos.has(repo.name);
  const langPill = repo.language
    ? `<span class="lang-pill"><span class="lang-circle" style="background:${lc}"></span>${escHtml(repo.language)}</span>`
    : '';
  const epState = epLaunchState[repo.name];
  const launchBtn = repo._hasLaunch
    ? `<button class="ep-card-launch-btn${epState?.running ? ' s-running' : ''}" id="ep-card-launch-${n}" title="${epState?.running ? 'Stop' : 'Launch'}" onclick="toggleEpLaunch('${n}')">${epState?.running ? EP_STOP_SVG : EP_PLAY_SVG}</button>`
    : '';
  const consoleBtn = repo._hasLaunch
    ? `<button class="ep-console-btn" id="ep-console-btn-${n}" title="View console logs" onclick="toggleEpConsole('${n}')">${EP_CONSOLE_SVG}</button>`
    : '';
  return `
    <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6">
    <div class="ep-card" id="ep-card-${n}">
      <div class="ep-card-head">
        <div class="ep-icon">📦</div>
        <div class="ep-info">
          <div class="ep-name" title="${n}">${n}</div>
          <div class="ep-meta">
            ${langPill}
            <span class="ep-branch">⎇ ${branch}</span>
            <span class="ep-commit">${commit}</span>
          </div>
          <div class="ep-contribs" id="ep-contribs-${n}"></div>
        </div>
        <div class="ep-card-head-actions">${consoleBtn}${launchBtn}</div>
      </div>
      <div class="ep-branch-badges-row">
        <div class="ep-branch-bar">
          <button class="ep-branch-select" title="Switch branch" onclick="openBranchModal('${n}')">${BRANCH_SVG} ${branch}</button>
          <button class="ep-branch-btn"        title="Create branch" onclick="promptCreateBranch('${n}')">+ branch</button>
        </div>
        <div class="ep-badges" id="ep-badges-${n}"></div>
      </div>
      <div class="ep-card-foot">
        <span class="proj-pull-badge checking" id="eppull-${n}" title="Fetching pull status…"></span>
        <div class="proj-actions">
          <button class="proj-act-btn proj-watch-btn ${watching ? 'watching' : ''}" title="${watching ? 'Unwatch' : 'Watch this repo'}" onclick="toggleWatch('${n}')">${watching ? EYE_WATCH_SVG : EYE_SVG}</button>
          <button class="proj-act-btn proj-ij-btn"   title="Open in IntelliJ IDEA" onclick="openIntelliJ('${n}')">${IJ_SVG}</button>
          <button class="proj-act-btn proj-chat-btn" title="Chat about this project" onclick="openProjectChat('${n}')">${CHAT_SVG}</button>
          <button class="proj-act-btn proj-jenkins-btn" id="ep-jenkins-${n}" title="Jenkins build" disabled style="opacity:.35">${JENKINS_SVG}</button>
          <button class="proj-act-btn proj-sched-btn ${scheduledJobs[repo.name] ? 'active' : ''}" id="ep-sched-${n}" title="${scheduledJobs[repo.name] ? 'Edit scheduled jobs' : 'Schedule automated jobs'}" onclick="openScheduleModal('${n}')">${SCHED_SVG}${scheduledJobs[repo.name] ? `<span class="sched-status-dot sched-dot-${scheduledJobs[repo.name].lastStatus || 'none'}"></span>` : ''}</button>
          <button class="proj-act-btn proj-del-btn"  title="Delete local clone" onclick="deleteLocalRepo('${n}')">${TRASH_SVG}</button>
        </div>
      </div>
    </div>
    </div>`;
}

// ── Top contributors (per cloned repo) ───────────────────────────────────────
let _contribCache = {};   // repo -> [{ name, email, count }]

// The server attaches a per-contributor `slackUrl`: a direct 1:1 DM deep link
// when their git email resolves to a Slack account (slack.token configured),
// otherwise a people-search link. This client fallback only fires if the server
// didn't supply one. Workspace overridable via cfg.slackWorkspace.
function slackMessageUrl(name) {
  let ws = (cfg.slackWorkspace || 'cainc.enterprise.slack.com').replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!/\.slack\.com$/i.test(ws)) ws = ws.replace(/\.slack\.com.*$/i, '') + '.slack.com';
  return `https://${ws}/search/${encodeURIComponent(name)}`;
}

function renderContribs(repoName, list) {
  const el = document.getElementById(`ep-contribs-${escHtml(repoName)}`);
  if (!el) return;
  if (!list || !list.length) { el.innerHTML = ''; return; }
  const chips = list.map(c => {
    const initials = (c.name || '?').split(/\s+/).filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase() || '?';
    const tip = `Message ${c.name} on Slack · ${c.count} commit${c.count !== 1 ? 's' : ''}`;
    const handle = c.email ? c.email.split('@')[0] : c.name;
    return `<a class="ep-contrib" href="${escHtml(c.slackUrl || slackMessageUrl(handle))}" target="_blank" title="${escHtml(tip)}">
      <span class="ep-contrib-ava">${escHtml(initials)}</span><span class="ep-contrib-name">${escHtml(c.name)}</span></a>`;
  }).join('');
  el.innerHTML = `<div class="ep-contrib-title">Top Contributors</div><div class="ep-contrib-list">${chips}</div>`;
}

async function loadContributors(names) {
  if (!names || !names.length || !sessionId) return;
  // Replay cached entries onto freshly-rendered cards, fetch only the rest.
  names.forEach(n => { if (n in _contribCache) renderContribs(n, _contribCache[n]); });
  const need = names.filter(n => !(n in _contribCache));
  if (!need.length) return;
  const CHUNK = 25;
  for (let i = 0; i < need.length; i += CHUNK) {
    const chunk = need.slice(i, i + CHUNK);
    try {
      const resp = await fetch(`${API}/api/repo-contributors?session=${sessionId}&repos=${chunk.map(encodeURIComponent).join(',')}`);
      if (!resp.ok) continue;
      const data = await resp.json();
      for (const n of chunk) { _contribCache[n] = data[n] || []; renderContribs(n, _contribCache[n]); }
    } catch (_) {}
  }
}

function renderSection(container, repos, label) {
  if (!repos.length) return;
  const sec = document.createElement('div');
  sec.className = 'ep-section';
  sec.innerHTML = `<div class="ep-section-label">${label} <span class="ep-section-count">${repos.length}</span></div>
    <div class="row g-3 ep-grid">${repos.map(buildEpCard).join('')}</div>`;
  container.appendChild(sec);
}

function renderExistingProjects() {
  const container = document.getElementById('ep-grid');
  if (!container) return;

  const q = (document.getElementById('ep-search')?.value || '').toLowerCase();
  const visible = q
    ? epRepos.filter(r => r.name.toLowerCase().includes(q) || (r.description || '').toLowerCase().includes(q))
    : epRepos;

  if (!epRepos.length) {
    container.innerHTML = `<div class="ep-empty">No locally cloned repositories found.<br>Use <strong>Home → Setup Workspace</strong> to clone repos.</div>`;
    return;
  }
  if (!visible.length) {
    container.innerHTML = `<div class="ep-empty">No projects match "<strong>${escHtml(q)}</strong>"</div>`;
    return;
  }

  container.innerHTML = '';
  const watched    = visible.filter(r => watchedRepos.has(r.name));
  const nonWatched = visible.filter(r => !watchedRepos.has(r.name));
  const failedBuild = nonWatched.filter(r => {
    const j = _badgeCache[r.name]?.jenkins;
    return j && !j.error && (j.result === 'FAILURE' || j.result === 'UNSTABLE');
  });
  const remaining = nonWatched.filter(r => {
    const j = _badgeCache[r.name]?.jenkins;
    return !j || j.error || (j.result !== 'FAILURE' && j.result !== 'UNSTABLE');
  });

  const WATCH_ICON = `<svg viewBox="0 0 16 16" width="15" height="15" fill="#22c55e" style="vertical-align:-2px"><path d="M8 3C4.5 3 1.5 5.5 0 8c1.5 2.5 4.5 5 8 5s6.5-2.5 8-5c-1.5-2.5-4.5-5-8-5zm0 8a3 3 0 110-6 3 3 0 010 6zm0-1.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"/></svg>`;
  const FAIL_ICON  = `<svg viewBox="0 0 16 16" width="14" height="14" fill="#ef4444" style="vertical-align:-2px"><circle cx="8" cy="8" r="7"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/></svg>`;

  if (watched.length)     renderSection(container, watched,     `${WATCH_ICON} Watching`);
  if (failedBuild.length) renderSection(container, failedBuild, `${FAIL_ICON} Failed Builds`);
  if (remaining.length)   renderSection(container, remaining,   (watched.length || failedBuild.length) ? 'All Projects' : 'Cloned Repositories');

  // Re-render rebuilds card DOM with empty contributor slots. Replay the cache
  // synchronously here so contributors never blank out on ANY re-render path
  // (tab re-entry, watch/schedule/delete, returning from an opened Slack link).
  // loadContributors still fetches any repos not yet cached.
  epRepos.forEach(r => { if (r.name in _contribCache) renderContribs(r.name, _contribCache[r.name]); });
}

async function checkEpPullStatus(names) {
  if (!names.length || !sessionId) return;
  // Show spinner on every badge while fetching
  names.forEach(name => {
    const el = document.getElementById(`eppull-${escHtml(name)}`);
    if (el) { el.textContent = ''; el.className = 'proj-pull-badge checking'; el.title = 'Fetching pull status…'; el.onclick = null; }
  });
  // Process in chunks of 15 — each fetch triggers a git-fetch per repo,
  // so we avoid flooding GitHub Enterprise with too many parallel connections.
  const CHUNK = 15;
  for (let i = 0; i < names.length; i += CHUNK) {
    const chunk = names.slice(i, i + CHUNK);
    try {
      const resp = await fetch(`${API}/api/pull-status?session=${sessionId}&repos=${chunk.map(encodeURIComponent).join(',')}`);
      if (!resp.ok) {
        // Show error state on the remaining badges
        chunk.forEach(name => {
          const el = document.getElementById(`eppull-${escHtml(name)}`);
          if (el) { el.textContent = '—'; el.className = 'proj-pull-badge'; el.title = 'Could not fetch status'; }
        });
        continue;
      }
      const data = await resp.json();
      Object.assign(_pullStatusCache, data);

      chunk.forEach(name => {
        applyPullBadge(document.getElementById(`eppull-${escHtml(name)}`), data[name] || { cloned: true, behind: 0 }, name);
      });
    } catch (e) {
      chunk.forEach(name => {
        const el = document.getElementById(`eppull-${escHtml(name)}`);
        if (el) { el.textContent = '—'; el.className = 'proj-pull-badge'; el.title = 'Could not fetch status'; }
      });
    }
  }
}

async function deleteLocalRepo(name) {
  const ok = await uiConfirm({
    title: `Delete local clone of "${name}"?`,
    message: 'This removes the directory from your machine.\nThe repo on GitHub remains intact.',
    confirmText: '🗑️ Delete', danger: true,
  });
  if (!ok) return;

  try {
    const resp = await fetch(`${API}/api/delete-repo`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Delete failed');

    document.getElementById(`ep-card-${escHtml(name)}`)?.remove();
    epRepos = epRepos.filter(r => r.name !== name);
    const countEl = document.getElementById('ep-count-badge');
    if (countEl) countEl.textContent = `${epRepos.length} cloned`;
    if (!epRepos.length) {
      const grid = document.getElementById('ep-grid');
      if (grid) grid.innerHTML = `<div class="ep-empty">No locally cloned repositories. Use <strong>Home → Setup Workspace</strong> to clone repos.</div>`;
    }
    toast(`${name} — local clone deleted`, 'success');
  } catch (err) {
    toast('Delete failed: ' + err.message, 'error');
  }
}

// ── Pull status (GitHub Desktop–style) ────────────────────────────────────

// Cache keyed by repo name so repeated renders don't re-fetch immediately.
let _pullStatusCache = {};
let _pullCheckTimeout = null;

async function checkPullStatus(names) {
  if (!names.length || !sessionId) return;

  // Show "checking" on each badge
  names.forEach(name => {
    const el = document.getElementById(`ppull-${escHtml(name)}`);
    if (el) { el.textContent = '…'; el.className = 'proj-pull-badge'; el.title = 'Fetching pull status…'; el.onclick = null; }
  });

  try {
    const resp = await fetch(`${API}/api/pull-status?session=${sessionId}&repos=${names.map(encodeURIComponent).join(',')}`);
    if (!resp.ok) return;
    const data = await resp.json();
    Object.assign(_pullStatusCache, data);

    let totalBehind = 0;
    const behindRepos = [];

    names.forEach(name => {
      const info = data[name] || {};
      const el = document.getElementById(`ppull-${escHtml(name)}`);
      if (!el) return;

      applyPullBadge(el, info, name);
      if (info.behind > 0) {
        totalBehind += info.behind;
        behindRepos.push(name);
      }
    });

    updatePullBar(totalBehind, behindRepos);
  } catch (e) {
    // Silently fail — pull status is non-critical
  }
}

function updatePullBar(totalBehind, behindRepos) {
  const section = document.getElementById('pull-section');
  if (!section) return;
  if (totalBehind > 0) {
    section.style.display = 'flex';
    document.getElementById('pull-total-count').textContent = totalBehind;
    section.dataset.repos = JSON.stringify(behindRepos);
  } else {
    section.style.display = 'none';
    section.dataset.repos = '[]';
  }
}

async function pullAllSelected() {
  const section = document.getElementById('pull-section');
  const reposStr = section?.dataset?.repos || '[]';
  const names = JSON.parse(reposStr);
  if (!names.length) return;

  const repoObjects = names.map(name => allRepos.find(r => r.name === name)).filter(Boolean);
  if (!repoObjects.length) return;

  section.style.display = 'none';
  try {
    const resp = await fetch(`${API}/api/pull`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repos: repoObjects })
    });
    if (!resp.ok) throw new Error((await resp.json()).error);
  } catch (err) {
    toast('Pull failed: ' + err.message, 'error');
  }
}

async function pullRepo(name) {
  const repo = allRepos.find(r => r.name === name) || epRepos.find(r => r.name === name);
  if (!repo) return;
  try {
    const resp = await fetch(`${API}/api/pull`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repos: [repo] })
    });
    if (!resp.ok) throw new Error((await resp.json()).error);
  } catch (err) {
    toast('Pull failed: ' + err.message, 'error');
  }
}

// ── IntelliJ open ──────────────────────────────────────────────────────────

async function openIntelliJ(name) {
  try {
    const resp = await fetch(`${API}/api/open-intellij`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Failed to open IntelliJ');
    toast(`Opening ${name} in IntelliJ IDEA…`, 'info');
  } catch (err) {
    toast('Could not open IntelliJ: ' + err.message, 'error');
  }
}
