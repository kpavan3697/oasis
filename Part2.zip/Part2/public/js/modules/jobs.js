// =============================================================================
// Jobs — repo setup launch, job cards, progress bar, retry, AI suggestions, summary bar
// =============================================================================
async function launchSetup() {
  if (selectedRepos.size === 0) return;

  const repoObjects = [...selectedRepos].map(name => allRepos.find(r => r.name === name)).filter(Boolean);
  const options     = getOptions();

  // Show jobs panel
  document.getElementById('options-panel').classList.add('hidden');
  const jp = document.getElementById('jobs-panel');
  jp.classList.remove('hidden');

  // Init job cards
  jobs = {};
  document.getElementById('jobs-grid').innerHTML = '';
  repoObjects.forEach(r => {
    jobs[r.name] = { status: 'waiting', progress: 0, logs: [], elapsed: 0, stepCount: 5, stepsDone: 0, startTs: null, timer: null };
    renderJobCard(r);
  });
  updateSummaryBar();

  // Ensure the WebSocket is OPEN before telling the server to start.
  // job_start fires the instant runSetup begins — if the WS is mid-reconnect
  // (the 2-second window after any hiccup) that event is silently dropped and
  // the card hangs at "Waiting" forever. Waiting here costs at most ~2 seconds
  // and eliminates the race entirely. The server also buffers events when no
  // client is connected (second line of defence).
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    connectWebSocket();
    let waited = 0;
    while ((!ws || ws.readyState !== WebSocket.OPEN) && waited < 3000) {
      await new Promise(r => setTimeout(r, 100));
      waited += 100;
    }
  }

  // Tell server to kick off
  const doSetup = async () => fetch(`${API}/api/setup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session: sessionId, repos: repoObjects, options }),
  });

  try {
    let resp = await doSetup();
    // Session expired (server restart) — re-create it transparently and retry once
    if (resp.status === 401) {
      const ok = await reconnectSession();
      if (!ok) { showSessionExpired(); return; }
      resp = await doSetup();
    }
    if (!resp.ok) throw new Error((await resp.json()).error);
  } catch(err) {
    toast('Failed to start setup: ' + err.message, 'error');
    // Reset cards so they don't show a permanent "Waiting…" with no explanation
    repoObjects.forEach(r => setJobStatus(r.name, 'error'));
  }
}

// ── Log export ───────────────────────────────────────────────────────────────
function formatJobLog(name, j) {
  const lines = [];
  lines.push('═'.repeat(60));
  lines.push(`Repo: ${name}    status: ${j.status}    elapsed: ${j.elapsed || 0}s`);
  lines.push('═'.repeat(60));
  (j.logs || []).forEach(l => {
    const t = l.ts ? new Date(l.ts).toLocaleTimeString('en', { hour12: false }) : '';
    lines.push(`[${t}] ${String(l.level || '').toUpperCase().padEnd(4)} ${l.message}`);
  });
  return lines.join('\n');
}

function downloadText(text, filename) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  a.remove(); URL.revokeObjectURL(url);
}

function logFileStamp() {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

// Export logs for all jobs into a single file
function exportLogs() {
  const entries = Object.entries(jobs);
  if (!entries.length) { toast('No logs to export yet', 'info'); return; }
  const header = [
    'i-Ready OASIS — setup logs',
    `Exported: ${new Date().toLocaleString()}`,
    `Org: ${cfg.org || ''}  (${cfg.githubUrl || ''})`,
    '',
  ];
  const body = entries.map(([name, j]) => formatJobLog(name, j)).join('\n\n');
  downloadText(header.join('\n') + body + '\n', `oasis-logs-${logFileStamp()}.log`);
  toast(`Exported logs for ${entries.length} repo${entries.length > 1 ? 's' : ''}`, 'success');
}

// Export logs for a single job/repo
function exportJobLog(name) {
  const j = jobs[name];
  if (!j || !j.logs || !j.logs.length) { toast('No logs to export yet', 'info'); return; }
  downloadText(formatJobLog(name, j) + '\n', `oasis-${name}-${logFileStamp()}.log`);
  toast(`Exported logs for ${name}`, 'success');
}

function resetJobs() {
  document.getElementById('jobs-panel').classList.add('hidden');
  document.getElementById('options-panel').classList.remove('hidden');
  Object.values(jobs).forEach(j => { clearInterval(j.timer); clearTimeout(j._waitingTimer); });
  jobs = {};
}

// ── Job Cards ──────────────────────────────────────────────────────────────
function renderJobCard(repo) {
  const grid = document.getElementById('jobs-grid');
  const card = document.createElement('div');
  card.className = 'job-card s-waiting';
  card.id = `jcard-${repo.name}`;
  const lc = LANG_COLORS[repo.language] || '#6b7280';

  card.innerHTML = `
    <div class="job-card-header" onclick="toggleJobExpand('${repo.name}')">
      <div class="job-status" id="jstat-${repo.name}">○</div>
      <div class="job-meta">
        <div class="job-repo-name">${escHtml(repo.name)}</div>
        <div class="job-step-label" id="jstep-${repo.name}">Waiting…</div>
      </div>
      <div class="job-progress-group">
        <div class="job-bar"><div class="job-bar-fill" id="jbar-${repo.name}"></div></div>
        <div class="job-pct" id="jpct-${repo.name}">0%</div>
      </div>
      <div class="job-time" id="jtime-${repo.name}">0s</div>
      <button class="job-act job-suggest" title="Get a fix suggestion" onclick="event.stopPropagation(); suggestJob('${repo.name}')">💡</button>
      <button class="job-act job-retry" title="Retry setup" onclick="event.stopPropagation(); retryJob('${repo.name}')">↻ Retry</button>
      <div class="job-chevron">▾</div>
    </div>
    <div class="job-body">
      <div class="job-suggestion" id="jsug-${repo.name}" hidden></div>
      <div class="terminal" id="jlog-${repo.name}"></div>
      <div class="job-foot">
        <div class="job-tags">
          ${repo.language ? `<span class="jtag" style="color:${lc};border-color:${lc}44">${repo.language}</span>` : ''}
          <span class="jtag" style="color:var(--text3)">${escHtml(repo.default_branch || 'main')}</span>
        </div>
        <div class="job-foot-actions">
          <button class="btn btn-ghost btn-sm" onclick="exportJobLog('${repo.name}')">⬇ Export</button>
          <button class="btn btn-ghost btn-sm" id="jlogbtn-${repo.name}" onclick="toggleJobLogs('${repo.name}')">Logs ▾</button>
        </div>
      </div>
      <div class="job-suggestion" id="jlaunchsug-${repo.name}" hidden></div>
    </div>`;
  grid.appendChild(card);
}

function toggleJobExpand(name) {
  const card = document.getElementById(`jcard-${name}`);
  card.classList.toggle('expanded');
  if (card.classList.contains('expanded')) {
    const log = document.getElementById(`jlog-${name}`);
    log.scrollTop = log.scrollHeight;
  }
}

// Show/hide just the log terminal within an already-expanded card. After a
// successful build the card is in "notes-only" mode (notes shown, log hidden);
// this lets the user reveal the log without collapsing the notes.
function toggleJobLogs(name) {
  const card = document.getElementById(`jcard-${name}`);
  if (!card) return;
  card.classList.add('expanded');                    // keep the body open
  const logsHidden = card.classList.toggle('notes-only');
  const btn = document.getElementById(`jlogbtn-${name}`);
  if (btn) btn.textContent = logsHidden ? 'Logs ▾' : 'Logs ▲';
  if (!logsHidden) {
    const log = document.getElementById(`jlog-${name}`);
    if (log) log.scrollTop = log.scrollHeight;
  }
}

// ── Job State Updates ──────────────────────────────────────────────────────
function setJobStatus(name, status) {
  const j = jobs[name]; if (!j) return;

  // Cancel any existing stuck-waiting watchdog before changing state
  if (j._waitingTimer) { clearTimeout(j._waitingTimer); j._waitingTimer = null; }

  j.status = status;
  const card = document.getElementById(`jcard-${name}`);
  if (!card) return;
  card.className = `job-card s-${status}`;
  const icons = { waiting:'○', running:'↻', done:'✓', error:'✗' };
  document.getElementById(`jstat-${name}`).textContent = icons[status] || '?';

  if (status === 'running' && !j.startTs) {
    j.startTs = Date.now();
    j.timer = setInterval(() => {
      j.elapsed = Math.floor((Date.now() - j.startTs) / 1000);
      const el = document.getElementById(`jtime-${name}`);
      if (el) el.textContent = j.elapsed + 's';
    }, 1000);
  }

  // If still waiting after 30 s the server never sent job_start — surface an
  // error so the user isn't left staring at a silent grey card indefinitely.
  if (status === 'waiting') {
    j._waitingTimer = setTimeout(() => {
      if (jobs[name]?.status === 'waiting') {
        appendLog(name, 'err', '✗ No response from server after 30 s — check the connection and retry.');
        setJobStatus(name, 'error');
      }
    }, 30000);
  }

  updateSummaryBar();
}

function updateJobStep(name, label) {
  const el = document.getElementById(`jstep-${name}`);
  if (el) el.textContent = label;
}

// ── Smooth progress crawl ─────────────────────────────────────────────────
// Long steps (Maven builds, toolchain bootstraps) emit no intermediate
// progress events, so the bar would sit frozen at the previous step's value
// for the entire duration. Instead, when a step starts we launch a slow crawl
// timer that inches toward the *next* milestone; when step_done fires we snap
// to the exact value and stop. The bar never reaches 100% on its own — only
// finishJob() does that.
//
// Speed: uses an exponential-approach formula so the bar moves quickly at
// the start of a step and naturally slows as it nears the cap, which feels
// realistic for a build whose remaining time shrinks faster early on.

function _setProgress(name, pct) {
  const j = jobs[name]; if (!j) return;
  j.progress = pct;
  const bar = document.getElementById(`jbar-${name}`);
  const pctEl = document.getElementById(`jpct-${name}`);
  if (bar) bar.style.width = pct + '%';
  if (pctEl) pctEl.textContent = pct + '%';
  updateSummaryBar();
}

function startProgressCrawl(name) {
  const j = jobs[name]; if (!j) return;
  stopProgressCrawl(name);   // clear any prior crawl for this job

  // Crawl toward (nextStepTarget - 3%), capped at 95%, so there's always
  // a visible jump when the step actually completes.
  const nextStepTarget = Math.min(Math.round(((j.stepsDone + 1) / j.stepCount) * 90), 90);
  const crawlCap = Math.min(nextStepTarget - 3, 95);

  j._crawlTimer = setInterval(() => {
    const current = j.progress;
    if (current >= crawlCap) { stopProgressCrawl(name); return; }
    // Exponential approach: moves ~1.5% per tick initially, slows near the cap.
    const delta = Math.max((crawlCap - current) * 0.018, 0.05);
    _setProgress(name, Math.min(parseFloat((current + delta).toFixed(1)), crawlCap));
  }, 800);
}

function stopProgressCrawl(name) {
  const j = jobs[name]; if (!j) return;
  if (j._crawlTimer) { clearInterval(j._crawlTimer); j._crawlTimer = null; }
}

function advanceJobProgress(name) {
  const j = jobs[name]; if (!j) return;
  stopProgressCrawl(name);    // stop the crawl; snap to the real value
  j.stepsDone++;
  const pct = Math.min(Math.round((j.stepsDone / j.stepCount) * 90), 90);
  _setProgress(name, pct);
}

function finishJob(name, success, errorMsg) {
  const j = jobs[name]; if (!j) return;
  clearInterval(j.timer);
  stopProgressCrawl(name);
  j.status = success ? 'done' : 'error';
  setJobStatus(name, j.status);

  const card = document.getElementById(`jcard-${name}`);
  if (success) {
    _setProgress(name, 100);
    appendLog(name, 'ok', '✓ Setup complete');
    showSetupNotes(name, j);
    // Expand to reveal the notes, but keep the log terminal collapsed — on a
    // clean build there's nothing in the logs the user needs to see.
    if (card) card.classList.add('expanded', 'notes-only');
  } else {
    appendLog(name, 'err', '✗ ' + (errorMsg || 'Setup failed'));
    // Auto-expand with both the suggestion panel AND the logs visible so the
    // failure can be triaged.
    if (card) { card.classList.remove('notes-only'); card.classList.add('expanded'); }
    const logBtn = document.getElementById(`jlogbtn-${name}`);
    if (logBtn) logBtn.textContent = 'Logs ▲';
    suggestJob(name);
  }
  updateSummaryBar();
  checkAllDone();
}

// ── Post-setup notes panel ────────────────────────────────────────────────────
function showSetupNotes(name, j) {
  const panel = document.getElementById(`jsug-${name}`);
  if (!panel) return;

  const repo       = allRepos.find(r => r.name === name) || {};
  const cloneDir   = `${(cfg.cloneDir || '~/dev/projects/iready').replace(/\/$/, '')}/${name}`;
  const elapsed    = j.elapsed ? `${j.elapsed}s` : '—';
  const branch     = repo.default_branch || 'main';
  const lang       = repo.language || '—';
  const desc       = repo.description ? `<div style="color:var(--text3);font-size:12px;margin-top:2px">${escHtml(repo.description)}</div>` : '';
  const lc         = LANG_COLORS[lang] || '#6b7280';

  panel.hidden = false;
  panel.innerHTML = `
    <div class="sug-head" style="color:var(--green)">
      ✓ Ready
      <span class="sug-src" style="color:var(--green);border-color:rgba(34,197,94,.4);background:rgba(34,197,94,.08)">in ${elapsed}</span>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;font-size:12px;font-family:var(--mono)">
      <div>
        <div style="color:var(--text3);font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px">Repo</div>
        <div style="color:var(--text)">${escHtml(name)}</div>
        ${desc}
      </div>
      <div>
        <div style="color:var(--text3);font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px">Language</div>
        <div><span style="width:7px;height:7px;border-radius:50%;background:${lc};display:inline-block;margin-right:5px"></span>${escHtml(lang)}</div>
      </div>
      <div>
        <div style="color:var(--text3);font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px">Branch</div>
        <div style="color:var(--text)">⎇ ${escHtml(branch)}</div>
      </div>
      <div>
        <div style="color:var(--text3);font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px">Clone location</div>
        <div style="color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escHtml(cloneDir)}">${escHtml(cloneDir)}</div>
      </div>
    </div>
    <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
      ${repo._hasLaunch ? `<button class="btn btn-sm job-launch" id="jlaunch-${name}" data-label="${escHtml(repo._launchLabel || 'Launch')}" onclick="toggleLaunch('${name}')">▶ ${escHtml(repo._launchLabel || 'Launch')}</button>` : ''}
      <button class="btn btn-ghost btn-sm" onclick="openIntelliJ('${name}')">Open in IntelliJ</button>
      <button class="btn btn-ghost btn-sm" onclick="openProjectChat('${name}')">Ask Claude</button>
    </div>`;

  // Restore the running/stopped visual if a launch is already in flight.
  if (j.launchRunning) setLaunchBtn(name, true);
}

// ── Launch / stop a built app ──────────────────────────────────────────────────
async function toggleLaunch(name) {
  const j = jobs[name];
  if (j && j.launchRunning) { stopLaunch(name); return; }

  // Fresh attempt: clear any prior launch-failure suggestion (but keep the
  // post-setup notes section with the Launch button) and reset the user-stop flag.
  if (j) j.launchUserStopped = false;
  hideLaunchSuggestion(name);

  // Show the terminal so the user sees boot output immediately (a successful
  // setup leaves the card in notes-only mode with the log hidden).
  const card = document.getElementById(`jcard-${name}`);
  if (card) { card.classList.remove('notes-only'); card.classList.add('expanded'); }

  try {
    const resp = await fetch(`${API}/api/launch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Launch failed');
    // The launch_start WS event flips the button to "Stop".
  } catch (err) {
    toast('Launch failed: ' + err.message, 'error');
  }
}

async function stopLaunch(name) {
  // Mark this as a deliberate stop so the launch_stopped event isn't treated as
  // a failure (no Claude suggestion for an intentional shutdown).
  const j = jobs[name]; if (j) j.launchUserStopped = true;
  try {
    await fetch(`${API}/api/stop-launch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name }),
    });
    // launch_stopped WS event resets the button.
  } catch (err) {
    if (j) j.launchUserStopped = false;   // didn't actually stop
    toast('Could not stop: ' + err.message, 'error');
  }
}

function setLaunchBtn(name, running) {
  const btn = document.getElementById(`jlaunch-${name}`);
  if (!btn) return;
  btn.classList.toggle('s-running', running);
  btn.innerHTML = running ? '■ Stop' : ('▶ ' + escHtml(btn.dataset.label || 'Launch'));
}

const EP_PLAY_SVG    = `<svg viewBox="0 0 16 16" width="13" height="13" fill="currentColor"><path d="M4 2.5l9 5.5-9 5.5V2.5z"/></svg>`;
const EP_STOP_SVG    = `<svg viewBox="0 0 16 16" width="12" height="12" fill="currentColor"><rect x="3" y="3" width="10" height="10" rx="1.5"/></svg>`;
const EP_CONSOLE_SVG = `<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><rect x="1.5" y="2" width="13" height="12" rx="2"/><path d="M4.5 7l2 2-2 2"/><line x1="8.5" y1="11" x2="11.5" y2="11"/></svg>`;

function setEpLaunchBtn(name, running) {
  const s = epLaunchState[name] || (epLaunchState[name] = {});
  s.running = running;
  const btn = document.getElementById(`ep-card-launch-${name}`);
  if (!btn) return;
  btn.classList.toggle('s-running', running);
  btn.title = running ? 'Stop' : 'Launch';
  btn.innerHTML = running ? EP_STOP_SVG : EP_PLAY_SVG;
}

async function toggleEpLaunch(name) {
  const s = epLaunchState[name] || (epLaunchState[name] = {});
  if (s.running) {
    s.userStopped = true;
    try {
      await fetch(`${API}/api/stop-launch`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session: sessionId, repo: name }),
      });
    } catch (err) { s.userStopped = false; toast('Could not stop: ' + err.message, 'error'); }
    return;
  }
  s.userStopped = false;
  try {
    const resp = await fetch(`${API}/api/launch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Launch failed');
  } catch (err) { toast('Launch failed: ' + err.message, 'error'); }
}

function toggleEpConsole(name) {
  const wrap = document.getElementById('ep-log-wrap');
  if (!wrap) return;

  const isOpen = !wrap.classList.contains('hidden');
  const isSame = _epConsoleRepo === name;

  // Deactivate previous console button
  if (_epConsoleRepo) {
    const prev = document.getElementById(`ep-console-btn-${_epConsoleRepo}`);
    if (prev) prev.classList.remove('active');
  }

  if (isOpen && isSame) {
    // Clicking same repo's button again — close the drawer
    closeEpConsole();
    return;
  }

  _epConsoleRepo = name;
  wrap.classList.remove('hidden');

  const btn = document.getElementById(`ep-console-btn-${name}`);
  if (btn) btn.classList.add('active');

  const label = document.getElementById('ep-log-repo-label');
  if (label) label.textContent = name;

  // Replay stored logs
  const el = document.getElementById('ep-log');
  if (el) {
    el.innerHTML = '';
    const s = epLaunchState[name];
    if (s?.logs?.length) {
      const frag = document.createDocumentFragment();
      for (const e of s.logs) frag.appendChild(_makeConsoleLine(e.level, e.message, e.ts));
      el.appendChild(frag);
    }
    el.scrollTop = el.scrollHeight;
  }
}

function closeEpConsole() {
  const wrap = document.getElementById('ep-log-wrap');
  if (wrap) wrap.classList.add('hidden');
  if (_epConsoleRepo) {
    const btn = document.getElementById(`ep-console-btn-${_epConsoleRepo}`);
    if (btn) btn.classList.remove('active');
    _epConsoleRepo = null;
  }
}

function _makeConsoleLine(level, message, ts) {
  const time = new Date(ts || Date.now()).toLocaleTimeString('en', { hour12: false });
  const div = document.createElement('div');
  div.className = 'log-line';
  div.innerHTML = `<span class="log-ts">${time}</span><span class="log-${level} log-msg">${linkifyUrls(message)}</span>`;
  return div;
}

function appendEpConsoleLog(name, level, message, ts) {
  const s = epLaunchState[name] || (epLaunchState[name] = {});
  if (!s.logs) s.logs = [];
  s.logs.push({ level, message, ts: ts || Date.now() });
  if (s.logs.length > 2000) s.logs.shift();

  // Only append live to the drawer if it's open and showing this repo's logs
  if (_epConsoleRepo !== name) return;
  const el = document.getElementById('ep-log');
  if (!el) return;
  el.appendChild(_makeConsoleLine(level, message, ts));
  let over = el.childElementCount - 500;
  while (over-- > 0 && el.firstChild) el.removeChild(el.firstChild);
  el.scrollTop = el.scrollHeight;
}

function onLaunchStart(name) {
  const j = jobs[name]; if (j) j.launchRunning = true;
  setLaunchBtn(name, true);
  setEpLaunchBtn(name, true);
  // Clear previous launch logs so the console shows only the current run
  const s = epLaunchState[name] || (epLaunchState[name] = {});
  s.logs = [];
  // If the global drawer is open for this repo, clear it too
  if (_epConsoleRepo === name) {
    const logEl = document.getElementById('ep-log');
    if (logEl) logEl.innerHTML = '';
  }
  toast(`Launching ${name}…`, 'info');
}

// Fired when the server detects a startup-failure log pattern (e.g. Spring
// context error, AccessDeniedException). The process (Tomcat) is still running
// — only the webapp failed to init. We show the suggestion without flipping the
// Launch/Stop button so the user can still click Stop, fix the issue, and retry.
function onLaunchAppError(name) {
  appendLog(name, 'err', '✗ App startup failed — see suggestion below');
  toast(`${name} startup failed — see suggestion`, 'error');
  const card = document.getElementById(`jcard-${name}`);
  if (card) { card.classList.remove('notes-only'); card.classList.add('expanded'); }
  suggestJob(name, 'launch');
}

function onLaunchStopped(name, code) {
  const j = jobs[name]; if (j) j.launchRunning = false;
  setLaunchBtn(name, false);
  setEpLaunchBtn(name, false);

  const epS = epLaunchState[name];
  const epUserStopped = !!(epS && epS.userStopped);
  if (epS) epS.userStopped = false;

  const userStopped = !!(j && j.launchUserStopped) || epUserStopped;
  if (j) j.launchUserStopped = false;

  // A clean exit (code 0) or a stop the user initiated isn't a failure.
  // Anything else — a non-zero exit, or an unexpected signal kill — is.
  const failed = !userStopped && code !== 0;
  if (failed) {
    appendLog(name, 'err', `■ Launch failed (${code == null ? 'terminated' : 'exit ' + code})`);
    toast(`${name} failed to launch — see suggestion`, 'error');
    // Reveal the logs and run the same Claude/heuristic triage as a setup failure.
    const card = document.getElementById(`jcard-${name}`);
    if (card) { card.classList.remove('notes-only'); card.classList.add('expanded'); }
    suggestJob(name, 'launch');
  } else {
    appendLog(name, 'info', '■ Stopped');
    toast(`${name} stopped`, 'info');
  }
}

// ── Retry a failed job ───────────────────────────────────────────────────────
async function retryJob(name) {
  const repo = allRepos.find(r => r.name === name);
  if (!repo) { toast(`Can't find repo ${name} to retry`, 'error'); return; }
  const j = jobs[name];
  if (j) {
    clearInterval(j.timer);
    stopProgressCrawl(name);
    Object.assign(j, { status: 'waiting', progress: 0, stepsDone: 0, elapsed: 0, startTs: null, timer: null, logs: [] });
  }
  // Reset the card visuals
  const log = document.getElementById(`jlog-${name}`); if (log) log.innerHTML = '';
  const bar = document.getElementById(`jbar-${name}`); if (bar) bar.style.width = '0%';
  const pct = document.getElementById(`jpct-${name}`); if (pct) pct.textContent = '0%';
  const time = document.getElementById(`jtime-${name}`); if (time) time.textContent = '0s';
  hideSuggestion(name);
  hideLaunchSuggestion(name);
  updateJobStep(name, 'Retrying…');
  setJobStatus(name, 'waiting');

  // Same WS wait as launchSetup — job_start fires the instant runSetup begins.
  // If WS is mid-reconnect that event is silently dropped and the card hangs at
  // "Waiting" forever. Waiting here costs at most ~2 seconds.
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    connectWebSocket();
    let waited = 0;
    while ((!ws || ws.readyState !== WebSocket.OPEN) && waited < 3000) {
      await new Promise(r => setTimeout(r, 100));
      waited += 100;
    }
  }

  const doRetry = async () => fetch(`${API}/api/setup`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session: sessionId, repos: [repo], options: getOptions() })
  });

  try {
    let resp = await doRetry();
    if (resp.status === 401) {
      const ok = await reconnectSession();
      if (!ok) { setJobStatus(name, 'error'); showSessionExpired(); return; }
      resp = await doRetry();
    }
    if (!resp.ok) throw new Error((await resp.json()).error);
  } catch (err) {
    toast('Failed to retry: ' + err.message, 'error');
    setJobStatus(name, 'error');
  }
}

// ── Claude/heuristic suggestion for a failed job ─────────────────────────────
function hideSuggestion(name) {
  const el = document.getElementById(`jsug-${name}`);
  if (el) { el.hidden = true; el.innerHTML = ''; }
}

function hideLaunchSuggestion(name) {
  const el = document.getElementById(`jlaunchsug-${name}`);
  if (el) { el.hidden = true; el.innerHTML = ''; }
}

async function suggestJob(name, phase = 'setup') {
  const j = jobs[name]; if (!j) return;
  const card = document.getElementById(`jcard-${name}`);
  if (card && !card.classList.contains('expanded')) toggleJobExpand(name);

  // Launch failures render into their OWN panel (above the post-setup notes), so
  // the notes section with the Launch button stays visible and you can re-launch
  // after following the suggestion. Setup failures use the notes panel itself.
  const panel = document.getElementById(`${phase === 'launch' ? 'jlaunchsug' : 'jsug'}-${name}`);
  if (!panel) return;
  panel.hidden = false;
  panel.innerHTML = `<div class="sug-head">💡 Suggestion</div><div class="sug-body sug-loading">Analyzing the failure…</div>`;

  // Send the most recent log lines (cap to keep payload small)
  const logs = (j.logs || []).slice(-120).map(l => `[${l.level}] ${l.message}`).join('\n');
  const repo = allRepos.find(r => r.name === name);

  try {
    const resp = await fetch(`${API}/api/suggest`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name, language: repo?.language || '', logs, phase })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Suggestion failed');
    const badge = data.source === 'bedrock'
      ? '<span class="sug-src sug-src-claude">Claude · Bedrock</span>'
      : '<span class="sug-src">generic</span>';
    const hint = data.reason === 'no-access'
      ? `<div class="sug-hint" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
           <span>AWS credentials expired — AI triage unavailable.</span>
           <button class="btn btn-ghost btn-sm" onclick="refreshCredentialsAndReSuggest('${name}')">↻ Refresh &amp; retry</button>
         </div>`
      : data.reason === 'denied'
      ? `<div class="sug-hint">Your AWS role doesn't have Bedrock access to the configured Claude model — refreshing credentials won't help. Ask the platform team for <code>bedrock:InvokeModel</code> on the model in <code>config/oasis.yml</code>.</div>`
      : '';
    // If the suggestion includes runnable commands, offer to run each one
    // individually. A manual-only suggestion (no commands) just shows the text.
    const cmds = Array.isArray(data.commands) ? data.commands : [];
    j.fixCommands = cmds.slice();
    const rows = cmds.map((c, i) => cmdRowHtml(name, i, c, false)).join('');
    // After applying fixes, re-launch for a launch failure, or re-run setup otherwise.
    const retryBtn = phase === 'launch'
      ? `<button class="btn btn-ghost btn-sm" onclick="toggleLaunch('${name}')">▶ Launch again</button>`
      : `<button class="btn btn-ghost btn-sm" onclick="retryJob('${name}')">↻ Try setup again</button>`;
    const run = cmds.length
      ? `<div class="sug-run" id="sugrun-${name}">` +
          `<div class="sug-run-label">Run each command in the repo (in order):</div>` +
          `<div class="cmd-list" id="cmdlist-${name}">${rows}</div>` +
          retryBtn +
        `</div>`
      : '';
    panel.innerHTML = `<div class="sug-head">💡 Suggestion ${badge}</div>` +
      `<div class="sug-body">${renderMarkdown(data.suggestion || 'No suggestion available.')}</div>` + run + hint;
  } catch (err) {
    panel.innerHTML = `<div class="sug-head">💡 Suggestion</div>` +
      `<div class="sug-body sug-error">Could not get a suggestion: ${escHtml(err.message)}</div>`;
  }
}

function launchFuselage() {
  const existing = document.getElementById('fuselage-modal');
  if (existing) { existing.remove(); return; }

  const modal = document.createElement('div');
  modal.id = 'fuselage-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal" style="max-width:420px">
      <div class="modal-header">
        <div class="modal-title"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" style="vertical-align:middle;margin-right:6px"><path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/></svg>Fuselage</div>
        <button class="modal-close" onclick="document.getElementById('fuselage-modal').remove()">✕</button>
      </div>
      <div class="modal-body">
        <p style="font-size:14px;color:var(--text2);margin:0 0 16px">This build requires parameters:</p>
        <label class="check-row fuselage-opt" id="fuselage-launch-row" style="margin-bottom:12px;font-size:14px;color:var(--text)">
          <input type="checkbox" id="fuselage-launch" checked onchange="fuselageToggle('launch')">
          <span class="check-box-ui"></span>
          <span><strong>LAUNCH</strong> — launch a fuselage instance in AWS</span>
        </label>
        <label class="check-row fuselage-opt" id="fuselage-delete-row" style="font-size:14px;color:var(--text)">
          <input type="checkbox" id="fuselage-delete" onchange="fuselageToggle('delete')">
          <span class="check-box-ui"></span>
          <span><strong>DELETE</strong> — delete your existing fuselage instance</span>
        </label>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="document.getElementById('fuselage-modal').remove()">Cancel</button>
        <button class="btn btn-primary" id="fuselage-submit-btn" onclick="submitFuselage()">Submit</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
}

function fuselageToggle(picked) {
  const launchCb = document.getElementById('fuselage-launch');
  const deleteCb = document.getElementById('fuselage-delete');
  if (picked === 'launch' && launchCb.checked) deleteCb.checked = false;
  if (picked === 'delete' && deleteCb.checked) launchCb.checked = false;
}

async function submitFuselage() {
  const doLaunch = document.getElementById('fuselage-launch').checked;
  const doDelete = document.getElementById('fuselage-delete').checked;
  if (!doLaunch && !doDelete) {
    toast('Select at least one option.', 'error'); return;
  }

  const submitBtn = document.getElementById('fuselage-submit-btn');
  if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Submitting…'; }

  try {
    const resp = await fetch(`${API}/api/launch-fuselage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, launch: doLaunch, doDelete }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Launch failed');
    document.getElementById('fuselage-modal')?.remove();
    const action = doLaunch ? '🚀 Fuselage launch triggered successfully' : '🗑 Fuselage deletion triggered successfully';
    toast(action, 'success');
  } catch (e) {
    toast('Failed: ' + e.message, 'error');
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Submit'; }
  }
}

async function cancelFixCommand(name, idx) {
  try {
    await fetch(`${API}/api/cancel-fix`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name }),
    });
  } catch (e) { /* ignore */ }
  // UI update happens when fix_done arrives with cancelled=true
  const cancelBtn = document.querySelector(`#cmdrow-${name}-${idx} .btn-danger`);
  if (cancelBtn) { cancelBtn.disabled = true; cancelBtn.textContent = 'Cancelling…'; }
}

// Shared credential refresh — opens SSO browser login automatically, then retries.
async function refreshCredentials(statusEl) {
  if (statusEl) statusEl.textContent = 'Refreshing AWS credentials — a browser window may open for SSO login…';
  try {
    const resp = await fetch(`${API}/api/refresh-credentials`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId }),
    });
    const data = await resp.json();
    return data.ok === true;
  } catch (e) {
    return false;
  }
}

async function refreshCredentialsAndReSuggest(name) {
  const panel = document.getElementById(`jsug-${name}`);
  if (panel) panel.innerHTML = `<div class="sug-head">💡 Suggestion</div><div class="sug-body sug-loading">Refreshing AWS credentials — a browser window may open for SSO login…</div>`;
  const ok = await refreshCredentials(null);
  if (ok) {
    suggestJob(name);
  } else {
    if (panel) panel.innerHTML = `<div class="sug-head">💡 Suggestion</div>` +
      `<div class="sug-body sug-error">Could not refresh credentials. Check your AWS SSO configuration and try again.</div>`;
  }
}

async function refreshCredentialsAndRetryChat() {
  const msgs = document.getElementById('chat-messages');
  const statusDiv = document.createElement('div');
  statusDiv.className = 'chat-msg assistant';
  statusDiv.innerHTML = `<div class="chat-avatar"><svg viewBox="0 0 20 20" width="14" height="14" fill="currentColor"><path d="M18 2H2C.9 2 0 2.9 0 4v12c0 1.1.9 2 2 2h3v3.5l5-3.5h8c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg></div><div class="chat-bubble"><span class="chat-thinking">Refreshing AWS credentials…</span></div>`;
  msgs.appendChild(statusDiv);
  msgs.scrollTop = 9999;
  const ok = await refreshCredentials(statusDiv.querySelector('.chat-thinking'));
  if (ok) {
    statusDiv.remove();
    sendChatMessage();
  } else {
    statusDiv.querySelector('.chat-bubble').innerHTML = `<span style="color:var(--red)">Could not refresh credentials. Check your AWS SSO configuration.</span>`;
  }
}

// Commands that delete/overwrite/force — run only after an explicit confirm.
function isDestructiveCmd(c) {
  if (/--dry-run\b/.test(c)) return false;   // dry-run only previews, never writes
  return /^(sudo\s+)?(rm|rmdir)\b/.test(c) || /\brm\s+-[a-z]*f/.test(c) ||
         /--force\b|--overwrite\b/.test(c) || /(^|\s)>>?\s*\//.test(c);
}

// One command row: a Run button, the command, and a status slot. fromOutput
// marks commands discovered in a previous command's output (e.g. brew link).
function cmdRowHtml(name, i, cmd, fromOutput) {
  const danger = isDestructiveCmd(cmd);
  return `<div class="cmd-row${danger ? ' cmd-danger' : ''}" id="cmdrow-${name}-${i}">` +
    `<button class="btn btn-sm ${danger ? 'btn-danger' : 'btn-run'} cmd-run-btn" onclick="runFixCommand('${name}',${i})">▶ Run</button>` +
    `<code class="cmd-text">${escHtml(cmd)}</code>` +
    (danger ? `<span class="cmd-warn" title="Deletes or overwrites files — confirms before running">⚠ destructive</span>` : '') +
    (fromOutput ? `<span class="cmd-from">suggested by output</span>` : '') +
    `<span class="cmd-status" id="cmdstat-${name}-${i}"></span>` +
  `</div>`;
}

// Called when a fix command starts — expand the card and scroll the terminal
// into view so the user can see the streaming output immediately.
function onFixStart(name) {
  const card = document.getElementById(`jcard-${name}`);
  if (card && !card.classList.contains('expanded')) toggleJobExpand(name);
  // Give the DOM a tick to render, then scroll the terminal into view
  setTimeout(() => {
    const terminal = document.getElementById(`jlog-${name}`);
    if (terminal) terminal.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, 80);
}

// Run a single suggested command (by index). Output streams into the job
// terminal (same WS 'log' messages as setup); completion arrives as a
// 'fix_done' event (carrying cmdIndex) handled by onFixDone().
async function runFixCommand(name, idx) {
  const j = jobs[name];
  const cmd = j && (j.fixCommands || [])[idx];
  if (!cmd) return;
  // Destructive commands (rm / --force / --overwrite / redirects) need a confirm.
  if (isDestructiveCmd(cmd) &&
      !confirm(`This command can delete or overwrite files:\n\n${cmd}\n\nRun it anyway?`)) {
    return;
  }
  const card = document.getElementById(`jcard-${name}`);
  if (card && !card.classList.contains('expanded')) toggleJobExpand(name);

  const btn  = document.querySelector(`#cmdrow-${name}-${idx} .cmd-run-btn`);
  const stat = document.getElementById(`cmdstat-${name}-${idx}`);
  if (btn) { btn.disabled = true; btn.textContent = '▶ Running'; }
  if (stat) { stat.className = 'cmd-status sug-loading'; stat.textContent = 'running…'; }

  // Show a Cancel button while the command runs
  const row = document.getElementById(`cmdrow-${name}-${idx}`);
  let cancelBtn = null;
  if (row) {
    cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn btn-sm btn-danger';
    cancelBtn.textContent = '✕ Cancel';
    cancelBtn.style.marginLeft = '6px';
    cancelBtn.onclick = () => cancelFixCommand(name, idx);
    row.appendChild(cancelBtn);
  }

  try {
    const resp = await fetch(`${API}/api/run-commands`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo: name, commands: [cmd], cmdIndex: idx })
    });
    const d = await resp.json();
    if (!resp.ok) throw new Error(d.error || 'Failed to run command');
  } catch (err) {
    if (btn) btn.disabled = false;
    if (stat) { stat.className = 'cmd-status sug-error'; stat.textContent = err.message; }
  }
}

// Called when a single command finishes — updates that command's row, then
// appends any follow-up commands the output itself suggested (e.g. brew link).
function onFixDone(name, success, error, cmdIndex, followups, cancelled) {
  if (typeof cmdIndex === 'number') {
    const row  = document.getElementById(`cmdrow-${name}-${cmdIndex}`);
    const btn  = document.querySelector(`#cmdrow-${name}-${cmdIndex} .cmd-run-btn`);
    const stat = document.getElementById(`cmdstat-${name}-${cmdIndex}`);
    // Remove the cancel button
    row?.querySelectorAll('.btn-danger').forEach(b => b.remove());
    if (btn) { btn.disabled = false; btn.textContent = success ? '▶ Run again' : '▶ Retry'; }
    if (stat) {
      if (cancelled) {
        stat.className = 'cmd-status sug-error'; stat.textContent = '✕ cancelled';
      } else {
        stat.className = 'cmd-status ' + (success ? 'sug-ok' : 'sug-error');
        stat.textContent = success ? '✓ done' : ('✗ ' + (error || 'failed') + ' — see log');
      }
    }
  }

  const j = jobs[name];
  const list = document.getElementById(`cmdlist-${name}`);
  if (j && list && Array.isArray(followups) && followups.length) {
    followups.forEach(cmd => {
      if (j.fixCommands.includes(cmd)) return;   // already listed
      const i = j.fixCommands.length;
      j.fixCommands.push(cmd);
      list.insertAdjacentHTML('beforeend', cmdRowHtml(name, i, cmd, true));
    });
  }
}

// Minimal, safe markdown → HTML (bold, code, inline code, line breaks, bullets)
function renderMarkdown(md) {
  const esc = escHtml(md);
  return esc
    .replace(/```([\s\S]*?)```/g, (_, c) => `<pre class="sug-pre">${c.trim()}</pre>`)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/^\s*[-*]\s+(.*)$/gm, '<li>$1</li>')
    .replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>')
    .replace(/\n{2,}/g, '<br><br>')
    .replace(/\n/g, '<br>');
}

// Live terminals are capped so a multi-thousand-line build doesn't grow the DOM
// without bound (which makes every append slower and laggier). The full log is
// always kept in memory (j.logs) for the export/suggestion features.
const MAX_DOM_LINES = 2000;
const _pendingRender = {};      // name -> [{ level, message, ts }]
let   _renderScheduled = false;

function appendLog(name, level, message, ts) {
  const j = jobs[name];
  if (j) j.logs.push({ level, message, ts });          // full history, uncapped
  (_pendingRender[name] ||= []).push({ level, message, ts: ts || Date.now() });
  if (!_renderScheduled) {
    _renderScheduled = true;
    requestAnimationFrame(flushLogRender);             // coalesce DOM writes per frame
  }
}

function flushLogRender() {
  _renderScheduled = false;
  for (const name in _pendingRender) {
    const buf = _pendingRender[name];
    delete _pendingRender[name];
    const log = document.getElementById(`jlog-${name}`);
    if (!log) continue;
    const frag = document.createDocumentFragment();
    for (const e of buf) {
      const time = new Date(e.ts).toLocaleTimeString('en', { hour12: false });
      const line = document.createElement('div');
      line.className = 'log-line';
      line.innerHTML = `<span class="log-ts">${time}</span><span class="log-${e.level} log-msg">${linkifyUrls(e.message)}</span>`;
      frag.appendChild(line);
    }
    log.appendChild(frag);
    // Trim oldest lines beyond the cap.
    let over = log.childElementCount - MAX_DOM_LINES;
    while (over-- > 0 && log.firstChild) log.removeChild(log.firstChild);
    const card = document.getElementById(`jcard-${name}`);
    if (card && card.classList.contains('expanded')) log.scrollTop = log.scrollHeight;
  }
}

// ── Summary bar ────────────────────────────────────────────────────────────
function updateSummaryBar() {
  const all = Object.values(jobs);
  const done    = all.filter(j => j.status === 'done').length;
  const running = all.filter(j => j.status === 'running').length;
  const errors  = all.filter(j => j.status === 'error').length;

  document.getElementById('sj-total').textContent = all.length;
  document.getElementById('sj-run').textContent   = running;
  document.getElementById('sj-done').textContent  = done;
  document.getElementById('sj-err').textContent   = errors;

  const totalPct = all.length ? Math.round(all.reduce((a, j) => a + j.progress, 0) / all.length) : 0;
  document.getElementById('overall-fill').style.width = totalPct + '%';
  document.getElementById('overall-pct').textContent  = totalPct + '%';
}

function checkAllDone() {
  const all = Object.values(jobs);
  if (all.every(j => j.status === 'done' || j.status === 'error')) {
    const failed = all.filter(j => j.status === 'error').length;
    setTimeout(() => {
      if (failed === 0) toast(`All ${all.length} repos set up successfully 🎉`, 'success');
      else toast(`${all.length - failed} done, ${failed} failed`, 'error');
    }, 400);
  }
}
