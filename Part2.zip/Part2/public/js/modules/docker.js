// =============================================================================
// Docker — service catalog, start/stop/install operations, container status polling
// =============================================================================
async function dockerCardOp(operation, name, container) {
  // Confirm destructive deletes before removing the container.
  if (operation === 'delete') {
    const ok = await uiConfirm({
      title: `Delete "${name}" container?`,
      message: 'This removes the container (docker rm -f).\nThe image is kept — you can reinstall it anytime.',
      confirmText: '🗑️ Delete', danger: true,
    });
    if (!ok) return;
  }
  // Starting another op stops any live log follow streaming into the drawer.
  stopDockerLogs();
  _dockerBusy.add(name);
  renderDockerCards();
  const label = { install:'Installing', start:'Starting', stop:'Stopping', restart:'Restarting', delete:'Deleting' }[operation] || operation;
  const opId = `docker-op-${++_dockerOpId}`;
  _dockerOpReturns = _dockerOpReturns || {};
  _dockerOpReturns[opId] = name;
  showDockerLog(`${label} ${name}…`);
  try {
    const resp = await fetch(`${API}/api/docker/op`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, operation, services: [{ name, container }], opId }),
    });
    if (!resp.ok) { const d = await resp.json(); throw new Error(d.error || 'failed'); }
  } catch (e) {
    _dockerBusy.delete(name);
    renderDockerCards();
    toast(`${label} ${name} failed: ${e.message}`, 'error');
  }
}

const _dockerLogsOpIds = new Set();   // ops that are live log follows (suppress "✓ Done")
let _dockerLogsActive = false;

function dockerCardLogs(name, container) {
  stopDockerLogs();                    // stop any previous follow first
  const opId = `docker-op-${++_dockerOpId}`;
  _dockerLogsOpIds.add(opId);
  _dockerLogsActive = true;
  showDockerLog(`📄 Logs · ${name}  ·  live`);
  fetch(`${API}/api/docker/op`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session: sessionId, operation: 'logs', services: [{ name, container }], opId }),
  }).catch(e => toast('Could not fetch logs: ' + e.message, 'error'));
}

// Tell the server to stop the live `docker logs -f` follow (on drawer close or
// when another op starts) so it doesn't keep streaming into the drawer.
function stopDockerLogs() {
  if (!_dockerLogsActive) return;
  _dockerLogsActive = false;
  const opId = `docker-op-${++_dockerOpId}`;
  _dockerLogsOpIds.add(opId);   // suppress its "done" event
  fetch(`${API}/api/docker/op`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session: sessionId, operation: 'logs-stop', services: [], opId }),
  }).catch(() => {});
}

let _dockerOpReturns = {};
function onDockerOpDone(opId, success, error) {
  // Log follows ending (or being stopped) shouldn't print "✓ Done" or re-poll.
  if (_dockerLogsOpIds.has(opId)) {
    _dockerLogsOpIds.delete(opId);
    if (!success && error) appendDockerLog('err', '✗ ' + error);
    return;
  }
  const name = _dockerOpReturns[opId];
  if (name) { _dockerBusy.delete(name); delete _dockerOpReturns[opId]; }
  if (success) appendDockerLog('ok', '✓ Done');
  else { appendDockerLog('err', '✗ ' + (error || 'Failed')); if (error) toast(error, 'error'); }
  refreshDockerContainers();   // re-render with fresh status
}

// ── Op log drawer ───────────────────────────────────────────────────────────
function showDockerLog(title) {
  const wrap = document.getElementById('docker-log-wrap');
  if (wrap) wrap.classList.remove('hidden');
  const t = document.getElementById('docker-log-title');
  if (t) t.textContent = title;
  const log = document.getElementById('docker-log');
  if (log) log.innerHTML = '';
}
function appendDockerLog(level, msg) {
  const log = document.getElementById('docker-log'); if (!log) return;
  const line = document.createElement('div');
  line.className = 'log-line';
  line.innerHTML = `<span class="log-ts">${new Date().toLocaleTimeString('en',{hour12:false})}</span><span class="log-${level} log-msg">${linkifyUrls(msg)}</span>`;
  log.appendChild(line);
  log.scrollTop = log.scrollHeight;
}
function clearDockerLog() {
  stopDockerLogs();   // stop the live follow when the drawer is closed
  const wrap = document.getElementById('docker-log-wrap');
  if (wrap) wrap.classList.add('hidden');
}

// ── Container status polling ──────────────────────────────────────────────────
async function refreshDockerContainers() {
  try {
    const resp = await fetch(`${API}/api/docker/containers?session=${sessionId}`);
    const { containers = [] } = await resp.json();
    const map = {};
    for (const c of containers) {
      const nm = (c.Names || c.Name || '').replace(/^\//, '');
      if (nm) map[nm] = c;
    }
    _dockerContainers = map;
    renderDockerCards();
  } catch (_) { /* ignore poll errors */ }
}

function startDockerPolling() {
  stopDockerPolling();
  _dockerPollTimer = setInterval(refreshDockerContainers, 5000);
}
function stopDockerPolling() {
  if (_dockerPollTimer) { clearInterval(_dockerPollTimer); _dockerPollTimer = null; }
}
