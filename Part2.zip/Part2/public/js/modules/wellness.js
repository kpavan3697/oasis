// =============================================================================
// Wellness — hydration reminders, eye breaks, and body stretch notifications
// =============================================================================
// The timer runs in the main process (server/index.js) so it fires even when
// this renderer window is minimized or throttled by Chromium.
// The server calls window.wellnessShowFromServer() when OASIS is focused;
// otherwise it creates a BrowserWindow corner popup visible above all other apps.

(function () {
  'use strict';

  function apiBase() { return typeof API !== 'undefined' ? API : window.location.origin; }
  function callToast(msg, type) { if (typeof toast === 'function') toast(msg, type); }

  // ── Toggle ────────────────────────────────────────────────────────────────

  async function wellnessToggle() {
    const btn = document.getElementById('wellness-toggle-btn');
    const isOn = btn && btn.classList.contains('wellness-active');
    try {
      const r = await fetch(apiBase() + (isOn ? '/api/wellness/stop' : '/api/wellness/start'), { method: 'POST' });
      const data = await r.json();
      setButtonState(data.enabled);
      callToast(data.enabled ? 'Wellness reminders enabled 💚' : 'Wellness reminders paused', data.enabled ? 'success' : 'info');
    } catch (e) { /* server unreachable */ }
  }

  function setButtonState(on) {
    const btn = document.getElementById('wellness-toggle-btn');
    if (!btn) return;
    btn.classList.toggle('wellness-active', !!on);
    btn.title = on ? 'Wellness ON — click to disable' : 'Enable wellness reminders';
  }

  // ── Called by server when timer fires and OASIS is focused ─────────────

  window.wellnessShowFromServer = function (data) {
    if (activeOverlay) return;
    if (data.type === 'water') showWater(data.count);
    else showBreak(data.type);
  };

  // Called by server after popup interaction to close any open overlay
  window.wellnessExternalResult = function () {
    if (activeOverlay) closeOverlay(false);
  };

  // ── Overlay state ─────────────────────────────────────────────────────────

  var activeOverlay = null;
  var eyeCountdown  = null;

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape' || !activeOverlay) return;
    if (activeOverlay._type === 'water') wellnessDismissWater(false);
    else wellnessDismissBreak();
  });

  // ── Overlay helpers ───────────────────────────────────────────────────────

  function mkOverlay(html) {
    closeOverlay(false);
    var el = document.createElement('div');
    el.className = 'wl-overlay';
    el.id        = 'wl-overlay';
    el.innerHTML = '<div class="wl-card">' + html + '</div>';
    document.body.appendChild(el);
    requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.add('wl-in'); }); });
    activeOverlay = el;
    return el;
  }

  function closeOverlay(animated) {
    if (eyeCountdown) { clearInterval(eyeCountdown); eyeCountdown = null; }
    if (!activeOverlay) return;
    var el = activeOverlay;
    activeOverlay = null;
    if (animated) {
      el.classList.add('wl-out');
      setTimeout(function () { el.remove(); }, 350);
    } else {
      el.remove();
    }
  }

  function postResult(data) {
    fetch(apiBase() + '/api/wellness/overlay-result', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).catch(function () {});
  }

  // ── Water reminder ────────────────────────────────────────────────────────

  var WATER_MSGS = [
    'Your body is 60% water — top it off! 💧',
    'H₂O calling! Answer the hydration hotline! 📞',
    'Every sip is a high-five to your kidneys! 🙌',
    'Drink water or your brain will file a complaint. 🧠',
    'Future you says: please drink some water! 🥺',
    'Stay hydrated or the rubber duck debugger won\'t help. 🦆',
  ];

  function showWater(count) {
    var msg     = WATER_MSGS[Math.floor(Date.now() / 60000) % WATER_MSGS.length];
    var plural  = count > 1;
    var glasses = '';
    for (var i = 0; i < count; i++) {
      glasses += '<button class="wl-glass-btn" id="wlg' + i + '" onclick="wellnessGlassClick(' + i + ')" title="Click to drink!">'
        + glassSVG(i) + '<span class="wl-glass-lbl">Drink!</span></button>';
    }
    var penalty = plural
      ? '<div class="wl-penalty">⚠️ You skipped last time — drink all ' + count + ' glasses!</div>' : '';
    var html = '<div class="wl-hdr">'
      + '<span class="wl-badge wl-badge-water">💧 Hydration Time!</span>'
      + '<button class="wl-xbtn" onclick="wellnessDismissWater(false)" title="Skip (more glasses next time)">✕</button>'
      + '</div>'
      + '<p class="wl-msg">' + msg + '</p>'
      + penalty
      + '<div class="wl-glasses" id="wl-glasses">' + glasses + '</div>'
      + '<div class="wl-ftr"><button class="btn btn-ghost btn-sm" onclick="wellnessDismissWater(true)">⏰ Snooze 10 min</button></div>';
    var el = mkOverlay(html);
    el._count   = count;
    el._clicked = new Set();
    el._type    = 'water';
  }

  function glassSVG(i) {
    var c = 'wlc' + i;
    return '<svg class="wl-gsv" viewBox="0 0 70 100" xmlns="http://www.w3.org/2000/svg">'
      + '<defs>'
      + '<clipPath id="' + c + '"><path d="M10 14 L6 92 Q6 97 12 97 L58 97 Q64 97 64 92 L60 14 Z"/></clipPath>'
      + '<linearGradient id="wlwg' + i + '" x1="0" y1="0" x2="1" y2="0">'
      + '<stop offset="0%" stop-color="#38bdf8"/><stop offset="100%" stop-color="#0ea5e9"/>'
      + '</linearGradient></defs>'
      + '<g clip-path="url(#' + c + ')">'
      + '<rect class="wl-water" x="6" y="35" width="58" height="62" fill="url(#wlwg' + i + ')"/>'
      + '<rect class="wl-wave" x="-18" y="32" width="106" height="9" rx="4" fill="#7dd3fc" opacity="0.65"/>'
      + '<circle class="wl-b1" cx="24" cy="72" r="3" fill="white" opacity="0.4"/>'
      + '<circle class="wl-b2" cx="46" cy="60" r="2.5" fill="white" opacity="0.35"/>'
      + '<circle class="wl-b3" cx="35" cy="80" r="2" fill="white" opacity="0.3"/>'
      + '</g>'
      + '<rect class="wl-ice1" clip-path="url(#' + c + ')" x="14" y="56" width="14" height="14" rx="3" fill="#bfdbfe" opacity="0.55"/>'
      + '<rect class="wl-ice2" clip-path="url(#' + c + ')" x="40" y="63" width="14" height="14" rx="3" fill="#bfdbfe" opacity="0.45"/>'
      + '<path d="M10 14 L6 92 Q6 97 12 97 L58 97 Q64 97 64 92 L60 14 Z" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round"/>'
      + '<line x1="11" y1="14" x2="59" y2="14" stroke="white" stroke-width="2" opacity="0.25" stroke-linecap="round"/>'
      + '<path d="M17 22 Q19 58 18 82" fill="none" stroke="white" opacity="0.12" stroke-width="3.5" stroke-linecap="round"/>'
      + '</svg>';
  }

  window.wellnessGlassClick = function (idx) {
    if (!activeOverlay || activeOverlay._type !== 'water') return;
    var btn = document.getElementById('wlg' + idx);
    if (!btn || btn.classList.contains('wl-drunk')) return;
    btn.classList.add('wl-drunk');
    activeOverlay._clicked.add(idx);
    if (activeOverlay._clicked.size >= activeOverlay._count) {
      var clicked = activeOverlay._clicked.size;
      var total   = activeOverlay._count;
      setTimeout(function () {
        showSuccess();
        postResult({ type: 'water', clicked: clicked, total: total, snooze: false });
      }, 900);
    }
  };

  window.wellnessDismissWater = function (isSnooze) {
    if (!activeOverlay) return;
    var clicked = activeOverlay._clicked ? activeOverlay._clicked.size : 0;
    var total   = activeOverlay._count || 1;
    closeOverlay(true);
    postResult({ type: 'water', clicked: clicked, total: total, snooze: !!isSnooze });
  };

  function showSuccess() {
    closeOverlay(false);
    var el = document.createElement('div');
    el.className = 'wl-success';
    el.innerHTML = '<div class="wl-success-box">💧 Hydrated! You\'re crushing it! 💪</div>';
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 2800);
  }

  // ── Break reminders ───────────────────────────────────────────────────────

  function showBreak(type) {
    if (type === 'eye') showEye();
    else if (type === 'stretch-deep') showStretchDeep();
    else showStretch();
  }

  function showEye() {
    var html = '<div class="wl-hdr">'
      + '<span class="wl-badge wl-badge-eye">👁️ Eye Break!</span>'
      + '<button class="wl-xbtn" onclick="wellnessDismissBreak()">✕</button>'
      + '</div>'
      + '<p class="wl-msg">Follow the glowing dot with your eyes — keep your head still!</p>'
      + '<div class="wl-anim-wrap">' + eyeSVG() + '</div>'
      + '<div class="wl-2020"><strong>Eye Reset:</strong> Trace the dot to loosen tired focus muscles, then blink slowly. <span id="wl-timer" class="wl-timer">20</span>s left</div>'
      + '<div class="wl-ftr"><button class="btn btn-primary btn-sm" onclick="wellnessDismissBreak()">Done! 👍</button></div>';
    var el = mkOverlay(html);
    el._type = 'eye';
    var secs = 20;
    eyeCountdown = setInterval(function () {
      secs--;
      var t = document.getElementById('wl-timer');
      if (t) t.textContent = secs;
      if (secs <= 0) { clearInterval(eyeCountdown); eyeCountdown = null; wellnessDismissBreak(); }
    }, 1000);
  }

  // The eye art is a self-animating SVG (SMIL): the pupils trace a path on their own,
  // so loading it via <img> is enough — no page CSS animation needed.
  function eyeSVG() {
    return '<img class="wl-eye-img" src="svg/eye.svg" alt="Animated eyes tracing a path">';
  }

  function showStretch() {
    var moves = [
      { name: 'Arms Up! 🙌',       desc: 'Reach both arms as high as you can. Hold for 5 seconds. Breathe!' },
      { name: 'Neck Roll 🔄',       desc: 'Slowly roll your neck left → back → right → forward. Repeat 3×.' },
      { name: 'Shoulder Shrug 💆',  desc: 'Raise shoulders to ears, squeeze, hold 3s, drop. Repeat 5×.' },
      { name: 'Wrist Shake 🤙',     desc: 'Shake out both wrists loosely for 10 seconds. Go on, flap \'em.' },
    ];
    var m = moves[Math.floor(Date.now() / 3600000) % moves.length];
    var html = '<div class="wl-hdr">'
      + '<span class="wl-badge wl-badge-stretch">🧘 Micro-Break!</span>'
      + '<button class="wl-xbtn" onclick="wellnessDismissBreak()">✕</button>'
      + '</div>'
      + '<p class="wl-msg">1 minute — stand up, open your chest, roll your neck. Your back will thank you! 🏃</p>'
      + '<div class="wl-anim-wrap">' + figureSVG() + '</div>'
      + '<div class="wl-stretch-name">' + m.name + '</div>'
      + '<div class="wl-stretch-desc">' + m.desc + '</div>'
      + '<div class="wl-ftr">'
      + '<button class="btn btn-primary btn-sm" onclick="wellnessDismissBreak()">Done! 💪</button>'
      + '<button class="btn btn-ghost btn-sm" onclick="wellnessDismissBreak()">Skip</button>'
      + '</div>';
    var el = mkOverlay(html);
    el._type = 'stretch';
  }

  function showStretchDeep() {
    var moves = [
      { name: 'Touch Your Toes 🖐️',        desc: 'Stand, hinge at hips, reach toward the floor. Hold 20s. Loosen tight hamstrings.' },
      { name: 'Standing Quad Stretch 🦵',  desc: 'Balance on one foot, pull the other heel to your glute. Hold 15s each side.' },
      { name: 'Chest Opener 🙌',            desc: 'Interlace fingers behind back, straighten arms and lift slightly. Hold 15s. Counter the keyboard hunch.' },
      { name: 'Wrist & Forearm Stretch 🤙', desc: 'Extend arm forward, palm up. Gently pull fingers down with the other hand. 15s each side.' },
      { name: 'Hip Flexor Lunge 🏋️',       desc: 'Step one foot forward into a lunge, drop the back knee to the floor. Hold 20s each side. Releases hip tension from sitting.' },
    ];
    var m = moves[Math.floor(Date.now() / (2 * 3600000)) % moves.length];
    var html = '<div class="wl-hdr">'
      + '<span class="wl-badge wl-badge-deep">🤸 Deep Stretch!</span>'
      + '<button class="wl-xbtn" onclick="wellnessDismissBreak()">✕</button>'
      + '</div>'
      + '<p class="wl-msg"><strong>5 minutes</strong> — step fully away from your desk. Your body has been static for 2 hours! 🏃</p>'
      + '<div class="wl-anim-wrap">' + figureSVGDeep() + '</div>'
      + '<div class="wl-stretch-name">' + m.name + '</div>'
      + '<div class="wl-stretch-desc">' + m.desc + '</div>'
      + '<div class="wl-stretch-steps">Sequence: touch toes → quad stretch → chest opener → wrist stretch → hip flexor lunge</div>'
      + '<div class="wl-ftr">'
      + '<button class="btn btn-primary btn-sm" onclick="wellnessDismissBreak()">Done! 💪</button>'
      + '<button class="btn btn-ghost btn-sm" onclick="wellnessDismissBreak()">Skip</button>'
      + '</div>';
    var el = mkOverlay(html);
    el._type = 'stretch-deep';
  }

  // Micro-break: first 3 yoga poses, crossfading.
  function figureSVG() {
    return '<div class="wl-poses">'
      + '<img class="wl-yoga-svg wl-p1" src="svg/yoga-1.svg" alt="">'
      + '<img class="wl-yoga-svg wl-p2" src="svg/yoga-2.svg" alt="">'
      + '<img class="wl-yoga-svg wl-p3" src="svg/yoga-3.svg" alt="">'
      + '</div>';
  }

  // Deep stretch: all 7 yoga poses, crossfading.
  function figureSVGDeep() {
    var poses = '';
    for (var i = 1; i <= 7; i++) {
      poses += '<img class="wl-deep-svg wl-pd' + i + '" src="svg/yoga-' + i + '.svg" alt="">';
    }
    return '<div class="wl-deep-poses">' + poses + '</div>';
  }

  window.wellnessDismissBreak = function () {
    var type = activeOverlay ? activeOverlay._type : 'eye';
    closeOverlay(true);
    postResult({ type: type });
  };

  // ── Init ──────────────────────────────────────────────────────────────────

  function init() {
    var right = document.querySelector('.topbar-right');
    if (right) {
      var btn = document.createElement('button');
      btn.id        = 'wellness-toggle-btn';
      btn.className = 'btn btn-ghost btn-sm';
      btn.onclick   = wellnessToggle;
      btn.innerHTML = '<svg viewBox="0 0 20 20" width="15" height="15" fill="currentColor" xmlns="http://www.w3.org/2000/svg">'
        + '<path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"/>'
        + '</svg>';
      var themeBtn = document.getElementById('theme-toggle');
      if (themeBtn) right.insertBefore(btn, themeBtn);
      else right.prepend(btn);
    }

    window.wellnessToggle = wellnessToggle;

    // Restore toggle button state from server
    fetch(apiBase() + '/api/wellness/state')
      .then(function (r) { return r.json(); })
      .then(function (d) { setButtonState(d.enabled); })
      .catch(function () {});
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
