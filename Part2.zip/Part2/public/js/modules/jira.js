// =============================================================================
// JIRA — connect/restore session, sync tickets, sprint/filter views, PR & CI work panels
// =============================================================================

const JIRA_COOKIE = 'iready_oasis_jira_token';

function saveJiraCookie(token) {
  const exp = new Date(Date.now() + 90 * 24 * 3600 * 1000).toUTCString();
  document.cookie = `${JIRA_COOKIE}=${encodeURIComponent(token)}; expires=${exp}; path=/; SameSite=Strict`;
}
function loadJiraCookie() {
  const m = document.cookie.split('; ').find(r => r.startsWith(JIRA_COOKIE + '='));
  return m ? decodeURIComponent(m.split('=')[1]) : null;
}
function clearJiraCookie() {
  document.cookie = `${JIRA_COOKIE}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}

let _jiraConfigured = false;
let _jiraData = null;          // last /api/jira/history response

async function autoConnectJira() {
  const token = loadJiraCookie();
  if (!token || !sessionId) return;
  try {
    const status = await fetch(`${API}/api/jira/status?session=${sessionId}`).then(r => r.json()).catch(() => ({}));
    if (status.configured) _jiraConfigured = true;
    else if (!(await _restoreJiraSession(token))) return;
    // Connected — warm the JIRA history cache in the background so the tab opens
    // instantly (mirrors the dependency-graph / docker prefetch).
    loadJiraHistory();
  } catch (_) {}
}

async function _restoreJiraSession(token) {
  token = token || loadJiraCookie();
  if (!token || !sessionId) return false;
  const prefs = await fetch(`${API}/api/prefs?session=${sessionId}`).then(r => r.json()).catch(() => ({}));
  const url = prefs.jiraUrl || '';
  if (!url) return false;
  // Use restore=true to skip re-validation — avoids cert/network failures on startup
  const cr = await fetch(`${API}/api/jira/connect`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session: sessionId, jiraUrl: url, jiraToken: token,
      jiraEmail: prefs.jiraEmail || '', jiraPointsField: prefs.jiraPointsField || '',
      jiraAccountId: prefs.jiraAccountId || '', jiraDisplayName: prefs.jiraDisplayName || '',
      restore: true }),
  });
  if (cr.ok) { _jiraConfigured = true; return true; }
  return false;
}

function initJiraTab() {
  if (_jiraConfigured) {
    showJiraConnected();
    loadJiraHistory();
    return;
  }
  fetch(`${API}/api/jira/status?session=${sessionId}`)
    .then(r => r.json())
    .then(d => {
      if (d.configured) { _jiraConfigured = true; showJiraConnected(); loadJiraHistory(); }
      else showJiraSetup();
    })
    .catch(() => showJiraSetup());
}

function showJiraSetup() {
  stopJiraAutoSync();
  document.getElementById('jira-setup').classList.remove('hidden');
  document.getElementById('jira-connected').classList.add('hidden');
  // Pre-fill URL from previously saved prefs
  const urlInput = document.getElementById('jira-url-input');
  if (urlInput && !urlInput.value && _jiraData?.jiraUrl) urlInput.value = _jiraData.jiraUrl;
}
function showJiraConnected() {
  document.getElementById('jira-setup').classList.add('hidden');
  document.getElementById('jira-connected').classList.remove('hidden');
  startJiraAutoSync();
}

function openJiraTokenPage() {
  const url = 'https://id.atlassian.com/manage-profile/security/api-tokens';
  if (window.electronAPI?.openExternal) window.electronAPI.openExternal(url);
  else window.open(url, '_blank');
}

async function connectJira() {
  const btn   = document.getElementById('jira-connect-btn');
  const msgEl = document.getElementById('jira-connect-msg');
  const url   = (document.getElementById('jira-url-input')?.value || '').trim().replace(/\/$/, '');
  const token = (document.getElementById('jira-token-input')?.value || '').trim();
  const pts   = (document.getElementById('jira-points-input')?.value || '').trim();

  msgEl.className = 'jira-connect-msg';
  if (!url)   { msgEl.textContent = 'JIRA URL is required.';  msgEl.classList.add('error'); return; }
  if (!token) { msgEl.textContent = 'API token is required.'; msgEl.classList.add('error'); return; }

  btn.disabled = true; btn.textContent = 'Verifying…';
  try {
    const resp = await fetch(`${API}/api/jira/connect`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, jiraUrl: url, jiraToken: token, jiraPointsField: pts }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      msgEl.textContent = data.error || 'Connection failed.';
      msgEl.classList.add('error');
      return;
    }
    saveJiraCookie(token);
    _jiraConfigured = true;
    msgEl.textContent = `✓ Connected as ${data.displayName || 'you'}`;
    msgEl.classList.add('success');
    setTimeout(() => { showJiraConnected(); loadJiraHistory(); }, 600);
  } catch (e) {
    msgEl.textContent = 'Network error: ' + e.message;
    msgEl.classList.add('error');
  } finally {
    btn.disabled = false; btn.textContent = 'Connect & Verify';
  }
}

async function settingsConnectJira() {
  const btn  = document.getElementById('s-jira-connect-btn');
  const msg  = document.getElementById('s-jira-msg');
  const url  = (document.getElementById('s-jira-url-input')?.value || '').trim().replace(/\/$/, '');
  const token = (document.getElementById('s-jira-token-input')?.value || '').trim() || loadJiraCookie();
  const pts  = (document.getElementById('s-jira-pts-input')?.value || '').trim();

  if (!url)   { msg.innerHTML = '<span style="color:var(--red)">JIRA URL is required</span>'; return; }
  if (!token) { msg.innerHTML = '<span style="color:var(--red)">API token is required</span>'; return; }

  btn.disabled = true; btn.textContent = 'Verifying…';
  msg.innerHTML = '';
  try {
    const resp = await fetch(`${API}/api/jira/connect`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, jiraUrl: url, jiraToken: token, jiraPointsField: pts }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      msg.innerHTML = `<span style="color:var(--red)">${escHtml(data.error || 'Connection failed')}</span>`;
      return;
    }
    saveJiraCookie(token);
    _jiraConfigured = true;
    const name = data.displayName || '';
    msg.innerHTML = `<span style="color:var(--green)">✓ Connected${name ? ' as ' + escHtml(name) : ''}</span>`;
    document.getElementById('jira-settings-status').innerHTML =
      `<span class="jira-status-connected">✓ Connected${name ? ' as <strong>' + escHtml(name) + '</strong>' : ''}</span>`;
    // Show disconnect button if it wasn't there
    const actions = document.querySelector('.jira-settings-actions');
    if (actions && !actions.querySelector('.jira-disconnect-btn')) {
      const dBtn = document.createElement('button');
      dBtn.className = 'btn btn-ghost btn-sm jira-disconnect-btn';
      dBtn.style.color = 'var(--red)';
      dBtn.textContent = 'Disconnect';
      dBtn.onclick = disconnectJira;
      actions.appendChild(dBtn);
    }
  } catch (e) {
    msg.innerHTML = `<span style="color:var(--red)">Network error: ${escHtml(e.message)}</span>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Connect & Verify';
  }
}

let _jiraAutoSyncTimer = null;
const JIRA_AUTO_SYNC_MS = 5 * 60 * 1000;

function startJiraAutoSync() {
  if (_jiraAutoSyncTimer) return;
  _jiraAutoSyncTimer = setInterval(() => syncJira(true), JIRA_AUTO_SYNC_MS);
}

function stopJiraAutoSync() {
  if (_jiraAutoSyncTimer) { clearInterval(_jiraAutoSyncTimer); _jiraAutoSyncTimer = null; }
}

async function syncJira(silent = false) {
  const btn = document.getElementById('jira-sync-btn');
  if (!sessionId) return;
  if (!silent) {
    btn.disabled = true; btn.innerHTML = `<span class="spinner" style="width:10px;height:10px;border-width:1.5px;margin-right:5px;"></span>Syncing…`;
  }
  try {
    let resp = await fetch(`${API}/api/jira/sync`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId }),
    });
    // Session lost between restart and sync — restore from prefs and retry once
    if (resp.status === 400) {
      const restored = await _restoreJiraSession();
      if (restored) {
        resp = await fetch(`${API}/api/jira/sync`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session: sessionId }),
        });
      }
    }
    const data = await resp.json();
    if (!resp.ok) { if (!silent) alert('Sync failed: ' + (data.error || 'Unknown error')); return; }
    _jiraWorkCache = {};   // force re-fetch of repo/PR/CI status after a sync
    await loadJiraHistory();
  } catch (e) {
    if (!silent) alert('Sync error: ' + e.message);
  } finally {
    if (!silent) {
      btn.disabled = false;
      btn.innerHTML = `<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M13.5 8a5.5 5.5 0 11-1.1-3.3"/><polyline points="13.5 2 13.5 5 10.5 5"/></svg> Sync`;
    }
  }
}

async function loadJiraHistory() {
  if (!sessionId) return;
  try {
    const resp = await fetch(`${API}/api/jira/history?session=${sessionId}`);
    if (!resp.ok) return;
    _jiraData = await resp.json();
    renderJiraHeader();
    populateJiraFilters();
    renderJiraTickets();
  } catch (_) {}
}

function renderJiraHeader() {
  if (!_jiraData) return;
  const el = document.getElementById('jira-header-meta');
  if (!el) return;
  const synced = _jiraData.lastSynced ? new Date(_jiraData.lastSynced).toLocaleString() : 'never';
  el.textContent = `Last synced: ${synced}`;
}

function populateJiraFilters() {
  if (!_jiraData) return;
  const sprints = _jiraData.sprints || [];
  const pis = [...new Set((_jiraData.tickets || []).map(t => t.pi).filter(Boolean))].sort();

  const sf = document.getElementById('jira-filter-sprint');
  const pf = document.getElementById('jira-filter-pi');
  if (!sf || !pf) return;

  const curSprint = sf.value;
  const curPi = pf.value;

  sf.innerHTML = '<option value="">All Sprints</option>' +
    sprints.map(s => `<option value="${escHtml(s.id)}">${escHtml(s.name)}${s.state === 'active' ? ' ★' : ''}</option>`).join('');
  pf.innerHTML = '<option value="">All PIs</option>' +
    pis.map(p => `<option value="${escHtml(p)}">${escHtml(p)}</option>`).join('');

  if (curSprint) sf.value = curSprint;
  if (curPi) pf.value = curPi;
}

// Filter handlers call this; only the tickets view remains.
function renderJiraView() { renderJiraTickets(); }

// Pill-group filter toggle (type / status)
function setJiraFilter(group, value, btn) {
  const wrap = document.getElementById(`jira-filter-${group}`);
  if (!wrap) return;
  wrap.dataset.value = value;
  wrap.querySelectorAll('.jira-pill').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  renderJiraView();
}

function clearJiraFilters() {
  ['type', 'status'].forEach(g => {
    const wrap = document.getElementById(`jira-filter-${g}`);
    if (wrap) {
      wrap.dataset.value = '';
      wrap.querySelectorAll('.jira-pill').forEach((p, i) => p.classList.toggle('active', i === 0));
    }
  });
  const se = document.getElementById('jira-filter-search'); if (se) se.value = '';
  renderJiraView();
}

const JIRA_TYPE_ICON = {
  Story:    '<svg viewBox="0 0 16 16" width="11" height="11" fill="var(--green)"><path d="M8 1a7 7 0 100 14A7 7 0 008 1zm-.5 9.5v-4l-2 2-.707-.707L8 4.586l3.207 3.207-.707.707-2-2v4h-1z"/></svg>',
  Bug:      '<svg viewBox="0 0 16 16" width="11" height="11" fill="var(--red)"><path d="M11 2a3 3 0 00-6 0H3.5a.5.5 0 000 1H5v1H3.5a.5.5 0 000 1H5v.379A4.001 4.001 0 004 9v1H2.5a.5.5 0 000 1H4v.5a4 4 0 008 0V11h1.5a.5.5 0 000-1H12V9a4.001 4.001 0 00-1-2.621V6h1.5a.5.5 0 000-1H11V4h1.5a.5.5 0 000-1H11z"/></svg>',
  Task:     '<svg viewBox="0 0 16 16" width="11" height="11" fill="var(--accent)"><path d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8z"/></svg>',
};

function renderJiraTickets() {
  const list = document.getElementById('jira-tickets-list');
  if (!list || !_jiraData) return;

  const tickets = _jiraData.tickets || [];
  if (!tickets.length) {
    list.innerHTML = '<div class="jira-empty"><div class="jira-empty-icon">🎫</div>No tickets loaded yet.<br><span>Click Sync to fetch your tickets from JIRA</span></div>';
    return;
  }

  const filterType   = document.getElementById('jira-filter-type')?.dataset.value || '';
  const filterStatus = document.getElementById('jira-filter-status')?.dataset.value || '';
  const filterSearch = (document.getElementById('jira-filter-search')?.value || '').toLowerCase();

  const filtered = tickets.filter(t => {
    if (filterType && t.type !== filterType && !(filterType === 'Task' && /task/i.test(t.type))) return false;
    if (filterStatus && t.statusCat !== filterStatus) return false;
    if (filterSearch && !t.key.toLowerCase().includes(filterSearch) && !t.summary.toLowerCase().includes(filterSearch)) return false;
    return true;
  });

  const anyActive = filterType || filterStatus || filterSearch;
  document.getElementById('jira-clear-filters')?.classList.toggle('hidden', !anyActive);

  const countEl = document.getElementById('jira-filter-count');
  if (countEl) countEl.textContent = '';

  if (!filtered.length) {
    list.innerHTML = '<div class="jira-empty">No tickets match the filters.</div>';
    return;
  }

  const sprintMeta = Object.fromEntries((_jiraData.sprints || []).map(s => [s.name, s]));
  const stateRank = { active: 0, future: 1, unknown: 1, '': 1, closed: 2 };

  // Sort tickets: active sprint first, then future/unknown, then closed, then no sprint
  const sorted = [...filtered].sort((a, b) => {
    const ma = sprintMeta[a.sprint] || {}, mb = sprintMeta[b.sprint] || {};
    const ra = a.sprint ? (stateRank[ma.state] ?? 1) : 3;
    const rb = b.sprint ? (stateRank[mb.state] ?? 1) : 3;
    if (ra !== rb) return ra - rb;
    return (mb.id || 0) - (ma.id || 0);
  });

  const isRFA = t => t.status?.toLowerCase() === 'ready for acceptance';
  // A ticket is "closed" only when its own status is Done — not because its
  // sprint closed. An unfinished ticket carried into a new sprint (e.g. still
  // In Review) stays in the In Progress section regardless of sprint state.
  const isEffectivelyClosed = t =>
    !isRFA(t) && t.statusCat === 'done';

  const inProgress = sorted.filter(t => !isEffectivelyClosed(t));
  const closed     = sorted.filter(t =>  isEffectivelyClosed(t));

  const renderSection = (label, tickets, isCollapsed) => {
    if (!tickets.length) return '';
    const pts     = tickets.reduce((s, t) => s + (t.points || 0), 0);
    const ptsDone = tickets.filter(t => t.statusCat === 'done').reduce((s, t) => s + (t.points || 0), 0);
    const ptsStr  = pts > 0 ? `<span class="jira-group-pts">${ptsDone}/${pts} pts</span>` : '';
    const secId   = `jira-sec-${label.replace(/\s+/g, '-').toLowerCase()}`;
    const collapsedCls = isCollapsed ? ' jira-section-collapsed' : '';
    return `
      <div class="jira-stage-divider jira-stage-toggle${collapsedCls}" onclick="toggleJiraSection('${secId}', this)" title="Click to expand/collapse">
        <span class="jira-stage-chevron">▾</span><span>${label}</span>${ptsStr}<span class="jira-group-count">${tickets.length}</span>
      </div>
      <div id="${secId}" class="row g-2 jira-ticket-rows${collapsedCls}">
        ${tickets.map(t => `<div class="col-12 col-xl-6">${renderTicketRow(t, sprintMeta)}</div>`).join('')}
      </div>`;
  };

  list.innerHTML = renderSection('In Progress', inProgress, false) + renderSection('Closed', closed, true);

  // Populate work panels (repos/PR/Jenkins) for visible in-progress tickets
  const inProgKeys = filtered.filter(t => !isEffectivelyClosed(t)).map(t => t.key);
  if (inProgKeys.length) loadJiraTicketWork(inProgKeys);
}

function toggleJiraSection(secId, headerEl) {
  const body = document.getElementById(secId);
  if (!body) return;
  const collapsed = body.classList.toggle('jira-section-collapsed');
  if (headerEl) headerEl.classList.toggle('jira-section-collapsed', collapsed);
}

let _jiraWorkCache = {};            // key -> { data: [{repo, branch, current, pr, jenkins}], ts }
const WORK_CACHE_TTL_MS = 90_000;  // refetch a ticket's repo/PR/CI status after this long

async function loadJiraTicketWork(keys) {
  if (!sessionId) return;
  // Render whatever we have cached right away (avoids a blank flash), but only
  // SKIP the network fetch for entries still within the TTL. Stale entries are
  // re-rendered from cache immediately, then refreshed below — this is what lets
  // repos/PRs created after the first load eventually show up without a Sync.
  const now = Date.now();
  const fresh = k => { const hit = _jiraWorkCache[k]; return hit && (now - hit.ts) < WORK_CACHE_TTL_MS; };
  keys.forEach(k => { if (_jiraWorkCache[k]) renderTicketWork(k, _jiraWorkCache[k].data); });
  const need = keys.filter(k => !fresh(k));
  if (!need.length) return;
  try {
    const resp = await fetch(`${API}/api/jira/ticket-work?session=${sessionId}&keys=${need.map(encodeURIComponent).join(',')}`);
    if (!resp.ok) return;
    const data = await resp.json();
    for (const k of need) {
      _jiraWorkCache[k] = { data: data[k] || [], ts: Date.now() };
      renderTicketWork(k, _jiraWorkCache[k].data);
    }
  } catch (_) {}
}

function renderTicketWork(key, repos) {
  const el = document.getElementById(`jt-work-${key}`);
  if (!el) return;
  if (!repos || !repos.length) { el.innerHTML = ''; return; }

  const TICK   = `<svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="2,6 5,9 10,3"/></svg>`;
  const DOWN   = `<svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="1" x2="6" y2="9"/><polyline points="3,6.5 6,9.5 9,6.5"/></svg>`;
  const PR_ICO = `<svg viewBox="0 0 16 16" width="10" height="10" fill="currentColor" style="flex-shrink:0;vertical-align:middle"><path d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"/></svg>`;
  const JK     = `<img src="img/jenkins.png" width="10" height="10" style="object-fit:contain;flex-shrink:0;vertical-align:middle" alt="">`;

  el.innerHTML = repos.map(r => {
    // PR chip — color reflects review status (approved=green, changes requested=red, pending=yellow)
    let prChip;
    if (r.pr && r.pr.merged) {
      const tip = r.pr.title ? r.pr.title : `PR#${r.pr.number} merged`;
      prChip = `<a class="jt-wr-chip jt-wr-pr-merged" href="${escHtml(r.pr.url)}" target="_blank" title="${escHtml(tip)}">⬡ Merged #${r.pr.number}</a>`;
    } else if (r.pr) {
      const rv = r.pr.review || 'pending';
      const prCls = rv === 'approved' ? 'jt-wr-pr-approved'
                  : rv === 'changes'  ? 'jt-wr-pr-changes'
                  :                     'jt-wr-pr-pending';
      const prTip = rv === 'approved' ? 'Approved'
                  : rv === 'changes'  ? 'Changes requested / pending review comments'
                  :                     'Review pending';
      const tip = (r.pr.title ? r.pr.title + ' — ' : '') + prTip;
      prChip = `<a class="jt-wr-chip jt-wr-pr ${prCls}" href="${escHtml(r.pr.url)}" target="_blank" title="${escHtml(tip)}">${PR_ICO} PR#${r.pr.number}</a>`;
    } else if (r.prError) {
      // The GitHub PR lookup itself failed (token/rate-limit/network) — don't
      // imply "no PR exists". Tell the user the check couldn't run.
      prChip = `<span class="jt-wr-chip jt-wr-pr-changes" title="${escHtml('PR check failed: ' + r.prError)}">${PR_ICO} PR check failed</span>`;
    } else {
      prChip = `<span class="jt-wr-nopr">No #PR</span>`;
    }

    // CI chip
    const j = r.jenkins || {};
    let ciChip = '';
    if (!j.error) {
      const failed  = j.result === 'FAILURE' || j.result === 'UNSTABLE';
      const running = j.building || j.result == null;
      const cls     = failed ? 'jt-wr-ci-fail' : running ? 'jt-wr-ci-run' : 'jt-wr-ci-pass';
      const label   = failed ? 'failed' : running ? 'building' : 'passed';
      ciChip = `<a class="jt-wr-chip ${cls}" href="${escHtml(j.url || '#')}" target="_blank" title="#${j.number} ${label}">${JK} ${j.number ? '#' + j.number : ''} ${label}</a>`;
    } else if (j.error !== 'no-token') {
      ciChip = `<span class="jt-wr-chip jt-wr-ci-muted" title="${j.error === 'auth' ? 'Jenkins auth failed' : 'No CI'}">${JK} No CI</span>`;
    }

    // Pull chip
    const behind = r.behind || 0;
    const pullChip = behind > 0
      ? `<button class="jt-wr-chip jt-wr-behind" title="${behind} commit${behind !== 1 ? 's' : ''} behind" onclick="pullJiraBranch('${escHtml(r.repo)}','${escHtml(r.branch)}', this)">${DOWN} Pull ${behind}</button>`
      : `<span class="jt-wr-chip jt-wr-ok">${TICK} synced</span>`;

    return `<div class="jt-wr${(!r.pr && !r.prError) ? ' jt-wr-nopr-card' : ''}">
      <div class="jt-wr-header">
        <span class="jt-wr-name" title="${escHtml(r.repo)}">${escHtml(r.repo)}</span>
        <span class="jt-wr-branch" title="${escHtml(r.branch)}">⎇ ${escHtml(r.branch)}</span>
      </div>
      <div class="jt-wr-chips">${prChip}${ciChip}${pullChip}</div>
    </div>`;
  }).join('');
}

async function pullJiraBranch(repo, branch, btn) {
  const orig = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner" style="width:9px;height:9px;border-width:1.5px"></span> Pulling…`;
  try {
    const resp = await fetch(`${API}/api/jira/pull-branch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, repo, branch }),
    });
    const data = await resp.json();
    if (resp.ok) {
      btn.innerHTML = '✓ Pulled';
      toast(`${repo}: ${data.message || 'Up to date'}`, 'success');
      // The branch is now up to date, so clear the stale "behind" count in the
      // cache. The same repo/branch may appear under several tickets — update
      // every match, then re-render so the chip flips from "Pull N" to "synced".
      const affected = [];
      for (const [k, entry] of Object.entries(_jiraWorkCache)) {
        let touched = false;
        for (const w of entry.data) {
          if (w.repo === repo && w.branch === branch && w.behind) { w.behind = 0; touched = true; }
        }
        if (touched) affected.push(k);
      }
      setTimeout(() => {
        btn.disabled = false;
        if (affected.length) affected.forEach(k => renderTicketWork(k, _jiraWorkCache[k].data));
        else btn.innerHTML = orig;
      }, 2500);
    } else {
      btn.innerHTML = '✕ Failed';
      toast(`${repo}: ${data.error || 'Pull failed'}`, 'error');
      setTimeout(() => { btn.disabled = false; btn.innerHTML = orig; }, 2500);
    }
  } catch (e) {
    btn.innerHTML = '✕ Failed';
    toast(`${repo}: ${e.message}`, 'error');
    setTimeout(() => { btn.disabled = false; btn.innerHTML = orig; }, 2500);
  }
}

function renderTicketRow(t, sprintMeta) {
  const jiraUrl = _jiraData?.jiraUrl || '';
  const link = jiraUrl ? `${jiraUrl}/browse/${t.key}` : '#';
  const typeIcon = JIRA_TYPE_ICON[t.type] || '';
  const typeClass = t.type === 'Story' ? 'type-story' : t.type === 'Bug' ? 'type-bug' : t.type === 'Task' ? 'type-task' : 'type-other';
  const isDone = t.statusCat === 'done' && t.status?.toLowerCase() !== 'ready for acceptance';
  const isInProg = t.statusCat === 'indeterminate' || t.status?.toLowerCase() === 'ready for acceptance';
  const statusClass = isDone ? 'status-done' : isInProg ? 'status-inprogress' : 'status-todo';
  const statusDot = isDone ? '●' : isInProg ? '◑' : '○';
  const pts = t.points != null ? `<span class="jira-chip jt-pts">${t.points}pt</span>` : '';
  const priorityIcon = t.priority === 'High' || t.priority === 'Highest'
    ? '<span class="jt-priority high" title="High priority">↑</span>'
    : t.priority === 'Low' || t.priority === 'Lowest'
    ? '<span class="jt-priority low" title="Low priority">↓</span>' : '';

  // Sprint state badge (top-right corner)
  const sm = (sprintMeta || {})[t.sprint] || {};
  const fmtD = d => d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
  const badgeMap = {
    active:  { label: 'Current',  cls: 'jt-sb-active'  },
    future:  { label: 'Future',   cls: 'jt-sb-future'  },
    closed:  { label: 'Closed',   cls: 'jt-sb-closed'  },
    rolled:  { label: 'Rolled',   cls: 'jt-sb-rolled'  },
    unknown: { label: 'Sprint',   cls: 'jt-sb-unknown' },
  };
  // A ticket in a closed sprint that never finished was rolled over, not closed.
  const isRolled = t.sprintState === 'closed' && !isDone;
  const sprintStateKey = isRolled ? 'rolled' : t.sprintState;
  const badgeConf  = t.sprint ? (badgeMap[sprintStateKey] || badgeMap.unknown) : null;
  const badgeTitle = t.sprint
    ? `${t.sprint}${sm.startDate || sm.endDate ? ' · ' + fmtD(sm.startDate) + (sm.endDate ? ' → ' + fmtD(sm.endDate) : '') : ''}`
    : 'No sprint assigned';
  const sprintBadge = badgeConf
    ? `<span class="jt-sprint-badge ${badgeConf.cls}" title="${escHtml(badgeTitle)}">${badgeConf.label}</span>`
    : `<span class="jt-sprint-badge jt-sb-backlog" title="${escHtml(badgeTitle)}">Backlog</span>`;

  // Label chips: show the first 2, but the tooltip on every chip lists ALL labels.
  const labelsHtml = (() => {
    if (!t.labels?.length) return '';
    const allTitle = escHtml(t.labels.join(', '));
    const chips = t.labels.slice(0, 2)
      .map(l => `<span class="jira-chip jt-label" title="${allTitle}">${escHtml(l)}</span>`).join('');
    const extra = t.labels.length - 2;
    const more = extra > 0
      ? `<span class="jira-chip jt-label jt-label-more" title="${allTitle}">+${extra}</span>` : '';
    return chips + more;
  })();

  const workPanel = !isDone ? `<div class="jt-work" id="jt-work-${escHtml(t.key)}"></div>` : '';

  return `<div class="jira-ticket-row${isDone ? ' jt-done' : ''}">
    ${sprintBadge}
    <div class="jt-left">
      <span class="jt-type-icon ${typeClass}" title="${escHtml(t.type)}">${typeIcon}</span>
    </div>
    <div class="jira-ticket-body">
      <div class="jt-top">
        <a class="jira-ticket-key" href="${escHtml(link)}" target="_blank">${escHtml(t.key)}</a>
        ${priorityIcon}
        <span class="jira-ticket-summary">${escHtml(t.summary)}</span>
      </div>
      <div class="jira-ticket-meta">
        <span class="jira-chip jt-status ${statusClass}">${statusDot} ${escHtml(t.status)}</span>
        ${pts}
        ${labelsHtml}
      </div>
      ${workPanel}
    </div>
  </div>`;
}

function openJiraSettings() {
  document.getElementById('settings-btn')?.click();
  setTimeout(() => {
    const sec = document.getElementById('settings-jira-section');
    if (sec) sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 150);
}

function exportJiraTicketsCsv() {
  if (!_jiraData?.tickets?.length) { alert('No tickets to export. Sync first.'); return; }
  const rows = [['Key','Type','Summary','Status','Points','Sprint','PI','Priority','Labels','Created','Updated']];
  for (const t of _jiraData.tickets) {
    rows.push([
      t.key, t.type, t.summary, t.status, t.points ?? '',
      t.sprint || '', t.pi || '', t.priority || '',
      (t.labels || []).join(';'),
      t.created ? t.created.slice(0,10) : '',
      t.updated ? t.updated.slice(0,10) : '',
    ]);
  }
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = `jira-tickets-${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a); URL.revokeObjectURL(url);
}

function disconnectJira() {
  clearJiraCookie();
  _jiraConfigured = false;
  _jiraData = null;
  closeModal('settings-modal');
  if (activeTab === 'jira') showJiraSetup();
  toast('JIRA disconnected', 'info');
}
