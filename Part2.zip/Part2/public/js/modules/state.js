// =============================================================================
// Shared mutable state — all module-level vars that are read/written across sections
// =============================================================================
let cfg = {};            // connection config
let sessionId = null;    // server session
let ws = null;           // WebSocket
let allRepos = [];       // all fetched repos
let filteredRepos = [];  // after search/filter
let selectedRepos = new Set();
let langFilters = new Set();
let jobs = {};           // { repoName: { status, progress, logs, elapsed, timer } }
let currentPage = 1;
let hasMorePages = false;
let _fetchGeneration = 0; // incremented on each new fetchAllRepos run to cancel stale ones

// Scheduled jobs state (keyed by repo name)
let scheduledJobs = {};

// Chat state
let chatRepo = null;
let chatMessages = [];  // [{role, content}]
let chatLogs = '';      // recent setup/launch console output for the chat repo (build-failure context)

// ── Cache ──────────────────────────────────────────────────────────────────
function saveCache() {
  try {
    const data = { ...cfg };
    delete data.token;
    localStorage.setItem(CACHE_KEY, JSON.stringify(data));
  } catch(e) {}
  saveCacheToFile();
}

function loadCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (raw) { cfg = JSON.parse(raw); return true; }
  } catch(e) {}
  return false;
}

async function loadCacheFromFile() {
  try {
    const resp = await fetch(`${API}/api/prefs`);
    if (!resp.ok) return false;
    const data = await resp.json();
    if (data.cfg) {
      cfg = { ...data.cfg, ...cfg }; // file as base, localStorage wins on conflict
      // cloneDir from the server (authoritative defaults.json) always wins — never let
      // stale localStorage silently revert to a wrong path.
      if (data.cfg.cloneDir) cfg.cloneDir = data.cfg.cloneDir;
      delete cfg.token;
    }
    if (Array.isArray(data.watchedRepos)) {
      data.watchedRepos.forEach(n => watchedRepos.add(n));
      saveWatched(watchedRepos);
    }
    return true;
  } catch (e) { return false; }
}

function saveCacheToFile() {
  try {
    const data = { cfg: { ...cfg }, watchedRepos: [...watchedRepos] };
    delete data.cfg.token;
    fetch(`${API}/api/prefs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).catch(() => {});
  } catch (e) {}
}

// Updates the Jenkins security page links with the real username when known.
function updateJenkinsSecurityLink(login) {
  if (!login) return;
  const url = `https://jenkins2.cainc.com/user/${encodeURIComponent(login)}/security/`;
  const linkEl = document.getElementById('w-jenkins-security-link');
  const openEl = document.getElementById('w-jenkins-open-link');
  if (linkEl) { linkEl.href = url; linkEl.textContent = `jenkins2.cainc.com/user/${login}/security/`; }
  if (openEl) { openEl.href = url; }
}
