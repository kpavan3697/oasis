# ⚡ i-Ready OASIS : Operational Assist and Smart Intervention System

A developer-environment setup & operations tool for the `github.cainc.com/iready` organization.

OASIS fetches every repository from GitHub Enterprise, lets you select and set them up (clone + build) with **live streamed logs**, **launch** the built apps locally, browse a **dependency graph**, and manage the local **Docker service stack** — all from one desktop app (or a browser).

It ships as a native **macOS app** (Electron) with **auto-update**, and also runs as a plain **web app** for development.

---

## Table of contents

- [Features](#features)
- [How it works (architecture)](#how-it-works-architecture)
- [Prerequisites](#prerequisites)
- [Running the web app](#running-the-web-app)
- [Running the desktop app](#running-the-desktop-app)
- [Configuration](#configuration)
- [Setup scripts](#setup-scripts)
- [The tabs explained](#the-tabs-explained)
- [Building the macOS app](#building-the-macos-app)
- [Signing, notarization & auto-update](#signing-notarization--auto-update)
- [Installing on a Mac](#installing-on-a-mac)
- [Releasing an update](#releasing-an-update)
- [Project layout](#project-layout)
- [Troubleshooting](#troubleshooting)

---

## Features

### Setup & projects
- 🔐 **Onboarding wizard** — collects GitHub Enterprise URL, org, **PAT**, and a **Jenkins API token** (both required & validated live).
- 💾 **Remember tokens** — one toggle persists *both* tokens in host‑scoped cookies and reuses them on the next launch (or clear them to re‑enter).
- 📦 **Live repo fetch** — pulls every repo in the org via the GitHub API (paginated) with search & language filters.
- ⚡ **Parallel or sequential setup** — set up to 10 repos; clone (shallow) + build with per‑repo progress bars that crawl smoothly during long builds.
- 📜 **Script‑first** — runs `scripts/<repo>.sh` if present, otherwise auto‑detects the project type (Maven / npm‑yarn‑pnpm / Ruby / Python).
- 🌊 **Real‑time log streaming** — batched WebSocket stdout/stderr into an expandable per‑job terminal (capped + smooth, so huge builds don't lag the UI).
- 🧠 **AI failure triage** — on a setup *or* launch failure, Claude (via AWS Bedrock) reads the logs + repo structure and suggests a fix with runnable commands; falls back to an offline heuristic analyzer when Bedrock isn't available.
- 🔑 **Mac password handoff** — when a setup needs `sudo`, the UI prompts for your Mac password and streams it to the running script live (no restart); wrong passwords re‑prompt.

### Launch & run
- ▶️ **Launch apps** — repos with a `scripts/<repo>.launch.sh` get a **Launch** button (e.g. iready‑core → Tomcat 10.1.16; learning‑delivery‑service → Spring Boot). Output streams to the job terminal; **Stop** kills it.
- 🟢/🔴 **Launch failure suggestions** — if an app fails to boot (or its webapp context fails inside a still‑running Tomcat), the Claude suggestion appears *below* the post‑setup notes so you can fix and re‑launch.
- ☁️ **Per‑user AWS profile** — launch scripts resolve credentials via your chosen profile and run `aws sso login` automatically when the session is expired.

### Operations
- 🕸️ **Dependency graph** — interactive repo/module dependency explorer.
- 🐳 **Docker Services tab** — manage the local `services` stack: a card grid of all images parsed from the repo's compose files, grouped by **Running / Stopped / Not Installed**, with per‑container **Install / Start / Stop / Restart / Delete / Logs**, category filters, search, and live 5‑second status polling.
- 🧩 **Local Repos** — see what's already cloned, with Jenkins build‑status badges and one‑click pulls.

### App
- 🎨 **Dark / light theme** toggle (persisted, no flash on load).
- 🔄 **Auto‑update** (desktop) from the internal Nexus feed.
- 🚀 Opens **maximized** on macOS.

---

## How it works (architecture)

```
┌─────────────────────────────────────────────────────────────┐
│  Electron main process (electron/main.js)                    │
│   • resolves the user's login PATH / AWS env                 │
│   • starts the embedded server on a free port                │
│   • opens a maximized BrowserWindow → http://localhost:PORT  │
│   • auto-update via electron-updater (Nexus feed)            │
└───────────────┬─────────────────────────────────────────────┘
                │ (desktop only — the web app skips Electron)
┌───────────────▼─────────────────────────────────────────────┐
│  Express + WebSocket server (server/index.js)                │
│   • proxies GitHub Enterprise & Jenkins APIs (avoids CORS)   │
│   • runs setup/launch/docker commands, streams logs over WS  │
│   • AI suggestions via AWS Bedrock                           │
│   • sessions + tokens held in memory only (never on disk)    │
└───────────────┬─────────────────────────────────────────────┘
                │ serves static UI
┌───────────────▼─────────────────────────────────────────────┐
│  Browser UI (public/)  index.html · js/app.js · css/app.css  │
└─────────────────────────────────────────────────────────────┘
```

- **One codebase, two runtimes.** `server/index.js` is the whole backend; the desktop app simply embeds it. `npm start` runs the same thing in a browser.
- **Secrets stay local.** Session credentials live only in server memory. The PAT and Jenkins token are persisted (when you opt in) in **host‑scoped cookies** so they survive the desktop app's random server port between launches.
- **Logs are batched.** The server coalesces stdout/stderr lines and the client renders them per animation frame with a capped DOM, so multi‑thousand‑line builds stay responsive.

---

## Prerequisites

| Tool | Required | Notes |
|------|----------|-------|
| Node.js | ✅ v18+ | `node --version` |
| npm | ✅ v8+ | bundled with Node |
| git | ✅ | must be on `PATH` |
| GitHub PAT | ✅ | `repo` / Contents:Read scope for the `iready` org |
| Jenkins API token | ✅ | from Jenkins → your profile → Security |
| Docker Desktop | For the Docker tab | `docker info` must succeed |
| AWS CLI v2 | For launch / AI suggestions | `aws sso login` is run automatically |
| mvn + JDK 17 | For Java repos | OASIS's setup can install these |
| IntelliJ IDEA | Optional | needs the `idea` CLI launcher |

---

## Running the web app

```bash
npm install
npm start            # → http://localhost:3000   (PORT=xxxx to override)
# or, with auto-restart on file changes:
npm run dev
```

Open the printed URL in a browser. Server route changes require a restart; `public/` (HTML/CSS/JS) changes only need a browser reload (the assets are cache‑busted with a `?v=` query).

---

## Running the desktop app

```bash
npm install
npm run electron     # launches the Electron app against the local source
```

This starts the embedded server on a random free port and opens the app window. No build step needed for local dev.

---

## Configuration

Runtime config lives in **`config/oasis.yml`**. In the desktop app it's seeded on first run into:

```
~/Library/Application Support/iready-oasis/config/oasis.yml
```

Key sections:

- **`suggestions.enabled`** — master switch for AI triage (`false` = always use the offline heuristic).
- **`aws.region` / `aws.profile`** — region + optional named profile for Bedrock.
- **`bedrock.model.id` / `.arn`** — the Claude model used for suggestions.
- **`jenkins.*`** — optional Jenkins URL / job pattern for build‑status badges.

Per‑user, in‑app **Settings** also stores: clone directory, IntelliJ CLI path, Maven args, extra env vars, **AWS profile**, and the **Docker services directory**.

---

## Setup scripts

Scripts live in `scripts/` and are bundled with the app (`extraResources`), so they're editable and survive updates.

Resolution order when setting up a repo:

1. `scripts/<repo>.sh` — a dedicated script (e.g. `iready-core.sh`, `learning-delivery-service.sh`)
2. Auto‑detected build by project type (Maven / npm / yarn / pnpm / Ruby / Python)

Conventions:

- `scripts/<repo>.launch.sh` — adds a **Launch** button for that repo. The first comment line `# oasis-launch-label: <text>` sets the button label.
- `scripts/lib/oasis-common.sh` — shared helpers (notifications, the sudo‑password handoff).
- `scripts/lib/aws-creds.sh` — resolves AWS SSO creds and exports them as env vars for launched apps.

---

## The tabs explained

| Tab | What it does |
|-----|--------------|
| **Home** | Select repos → **Setup Workspace** (clone + build). Per‑repo progress, live logs, post‑setup notes, **Launch** buttons, and AI suggestions on failure. |
| **Local Repos** | Repos already cloned locally, with Jenkins build status and quick pulls. |
| **Dependency Graph** | Interactive repo/module dependency visualization. |
| **Docker Services** | Card grid of the `iready/services` Docker stack — grouped by Running/Stopped/Not Installed, with Install/Start/Stop/Restart/Delete/Logs per container. Needs the `services` repo cloned (the tab guides you through it). |

---

## Building the macOS app

```bash
npm install
npm run dist:mac     # builds the .app → .dmg + .zip into release/
npm run dist:pkg     # the above, then builds a signed/notarized .pkg installer
```

Outputs land in `release/`:

- `i-Ready OASIS-<version>-arm64.dmg` — drag‑to‑Applications installer
- `i-Ready OASIS-<version>-arm64.zip` (+ `.blockmap`) — used by **auto‑update**
- `i-Ready OASIS-<version>-arm64.pkg` — double‑click installer (from `dist:pkg`)
- `latest-mac.yml` — the update manifest

> The build is **arm64** (Apple Silicon). Node 18+ and the dev dependencies (`electron`, `electron-builder`) must be installed.

---

## Signing, notarization & auto-update

Auto‑update and Gatekeeper **require a signed + notarized** build. Without credentials the build still succeeds but is **unsigned** (fine for local testing only).

Set these env vars before `npm run dist:pkg` (typically CI secrets — never commit them):

**App / pkg signing** (Developer ID):
```
CSC_LINK / CSC_KEY_PASSWORD               # .app  (base64 .p12 + password)
PKG_CSC_LINK / PKG_CSC_KEY_PASSWORD       # .pkg  (Developer ID Installer; falls back to CSC_*)
```

**Notarization** (one of):
```
APPLE_API_KEY  APPLE_API_KEY_ID  APPLE_API_ISSUER         # App Store Connect API key (preferred)
# — or —
APPLE_ID  APPLE_APP_SPECIFIC_PASSWORD  APPLE_TEAM_ID       # Apple ID + app-specific password
```

- `build/notarize.js` notarizes the `.app` (electron‑builder `afterSign` hook).
- `build/build-pkg.sh` signs + notarizes + staples the `.pkg`.
- Auto‑update feed (from `package.json` → `build.publish`):
  `generic` provider at **`https://nexus.cainc.com/repository/oasis/`**, channel `latest`.
- The app checks for updates on launch and every 4 hours, and offers **Check for Updates…** from the menu. Downloaded updates install on quit.

---

## Installing on a Mac

**Option A — the `.pkg` installer (recommended):**
1. Download `i-Ready OASIS-<version>-arm64.pkg`.
2. Double‑click and follow the installer → installs into `/Applications`.
3. Launch **i‑Ready OASIS** from Applications/Spotlight.

**Option B — the `.dmg`:**
1. Open the `.dmg` and drag the app to **Applications**.

**First launch (unsigned/dev builds only):** if macOS blocks it ("unidentified developer"), right‑click the app → **Open** → **Open**, or allow it in **System Settings → Privacy & Security**. Signed+notarized release builds open normally.

After install, the app self‑updates from the Nexus feed — no manual reinstall needed for later versions.

---

## Releasing an update

1. Bump the version: edit `version` in `package.json` (e.g. `1.1.1` → `1.1.2`). Auto‑update only triggers when the version increases.
2. Build signed + notarized artifacts:
   ```bash
   npm run dist:pkg     # with signing/notary env vars set
   ```
3. Publish the artifacts **and `latest-mac.yml`** to the Nexus feed:
   ```bash
   npm run publish      # electron-builder --publish always
   ```
   (or upload `release/*.zip`, `*.dmg`, `*.pkg`, and `latest-mac.yml` to `nexus.cainc.com/repository/oasis/`).
4. Installed apps pick up the new version on their next update check.

---

## Project layout

```
electron/main.js          Electron entry — embeds the server, window, auto-update
server/index.js           Express + WebSocket backend (the whole API)
public/                   Browser UI
  index.html  js/app.js  css/app.css
config/oasis.yml      Runtime config (AI suggestions, AWS, Jenkins)
scripts/                  Setup & launch scripts (bundled, editable)
  <repo>.sh               dedicated setup
  <repo>.launch.sh        adds a Launch button
  setup.sh                default auto-detect setup
  lib/                    shared bash helpers (sudo handoff, AWS creds)
build/                    macOS packaging — build-pkg.sh, notarize.js, entitlements, pkg/
release/                  build outputs (.dmg/.zip/.pkg/latest-mac.yml)
```

### npm scripts

| Script | Purpose |
|--------|---------|
| `npm start` / `start:web` | run the web app (server) |
| `npm run dev` | web app with nodemon auto‑restart |
| `npm run electron` / `start:desktop` | run the desktop app locally |
| `npm run dist:mac` | build `.app` → `.dmg` + `.zip` |
| `npm run dist:pkg` | `dist:mac` + signed/notarized `.pkg` |
| `npm run publish` | build + publish to the update feed |
| `npm run install:local` | build & install locally (`build/install-local.sh`) |

---

## Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| **"Could not reach the OASIS server"** (Docker tab) | The server wasn't restarted after a code change. Restart `node server/index.js`. |
| **Tokens not remembered after relaunch** | Make sure **Remember tokens on this device** is checked. Tokens are stored in cookies (host‑scoped) so they survive the desktop app's changing port. |
| **Setup stuck asking for a password** | Enter your Mac login password in the prompt; it's streamed to the running script live. Wrong passwords re‑prompt. |
| **Launch shows AWS / SSM errors** | Pick the right **AWS profile** in Settings → AWS; the launch script runs `aws sso login` automatically when expired. |
| **Docker tab: "services repo isn't set up"** | Follow the in‑tab steps — it jumps to Home, selects the `services` repo, then you click **Setup Workspace**. |
| **pnpm 404 from Nexus during a build** | The setup exports the project's `.npmrc` registry so global pnpm installs resolve from the right Nexus repo. |
| **Unsigned app won't open** | Right‑click → Open, or allow in System Settings → Privacy & Security. Use a signed/notarized build for distribution. |

---

© Curriculum Associates, LLC. Internal developer tooling.
