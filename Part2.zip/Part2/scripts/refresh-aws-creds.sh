#!/usr/bin/env bash
#
# refresh-aws-creds.sh — keep ~/.aws/credentials [default] fresh so i-Ready
# OASIS's "💡 Suggestion" feature reaches Claude on Bedrock.
#
# Why this is needed: the AWS SDK's default credential chain reads the static
# ~/.aws/credentials file BEFORE the SSO config in ~/.aws/config — and once it
# finds static keys there it does NOT fall through to SSO. So if [default] in
# the credentials file holds expired session keys, OASIS keeps using them,
# gets ExpiredToken from Bedrock, and shows the generic message even though you
# DO have Bedrock access via SSO. (The AWS CLI hides this because it falls
# through to SSO; the SDK does not.)
#
# This script writes genuinely fresh, SSO-derived temporary keys into
# ~/.aws/credentials [default]. Run it whenever suggestions come back "generic".
#
# It uses your own "default" profile (which OASIS's default credential chain
# resolves) — no per-user SSO profile name is hardcoded. If the SSO session is
# expired, it runs `aws sso login` for you. Override the profile only if your
# default isn't SSO-backed: ./scripts/refresh-aws-creds.sh [profile]

set -euo pipefail

PROFILE="${1:-${AWS_PROFILE:-default}}"
CRED_FILE="$HOME/.aws/credentials"
work="$(mktemp)"
trap 'rm -f "$work"' EXIT

# Resolve creds via SSO. Point the SDK/CLI at an empty credentials file so it
# can't read the (possibly stale) static keys and is forced through SSO.
export AWS_SHARED_CREDENTIALS_FILE="$work"

if ! aws sts get-caller-identity --profile "$PROFILE" >/dev/null 2>&1; then
  # By default we open the SSO browser login below. Automation that can't show
  # a browser can set OASIS_NONINTERACTIVE to bail out (exit 3) instead.
  # (OASIS runs this interactively, so the login flow opens for the user.)
  if [ -n "${OASIS_NONINTERACTIVE:-}" ]; then
    echo "→ SSO session expired — skipping interactive login (non-interactive mode)." >&2
    echo "  Run ./scripts/refresh-aws-creds.sh manually to sign in." >&2
    exit 3
  fi
  echo "→ SSO session expired — opening login…"
  aws sso login --profile "$PROFILE"
else
  echo "→ SSO session valid for profile '$PROFILE'."
fi

# Export the freshly-resolved temporary credentials as an ini [default] block.
aws configure export-credentials --profile "$PROFILE" --format process \
  | python3 -c '
import sys, json
c = json.load(sys.stdin)
print("[default]")
print("aws_access_key_id =", c["AccessKeyId"])
print("aws_secret_access_key =", c["SecretAccessKey"])
print("aws_session_token =", c["SessionToken"])
exp = c.get("Expiration")
if exp:
    sys.stderr.write("  expires: %s\n" % exp)
' > "$work"

unset AWS_SHARED_CREDENTIALS_FILE

# Back up the existing credentials file, then install the fresh [default].
if [ -f "$CRED_FILE" ]; then
  cp "$CRED_FILE" "$CRED_FILE.bak"
  echo "→ Backed up existing credentials to $CRED_FILE.bak"
fi
umask 077
cp "$work" "$CRED_FILE"

# Verify the STATIC keys in isolation (config disabled, so no SSO fallback can
# mask an expired key) — this is exactly how OASIS's SDK will resolve them.
echo "✓ $CRED_FILE refreshed. Verifying static keys in isolation…"
AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE="$CRED_FILE" \
  AWS_PROFILE=default AWS_EC2_METADATA_DISABLED=true \
  aws sts get-caller-identity --output text --query 'Arn'