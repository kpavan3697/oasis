#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — shared bootstrap helpers
#
# Sourced by scripts/setup.sh, scripts/iready-core.sh and the vendored
# scripts/iready-dev-setup/bootstrap.sh. Provides the pieces needed to run the
# (otherwise interactive) i-Ready dev-setup automation NON-interactively from
# OASIS, which spawns scripts with no controlling terminal and no stdin:
#
#   • dl_notify            — macOS notification (so the user knows what's happening)
#   • dl_prime_sudo        — pop ONE secure GUI password dialog, cache the sudo
#                            timestamp, and keep it warm for the whole run so
#                            every later `sudo` call works without prompting.
#                            The password is held only in memory and is unset
#                            immediately after priming — never written to disk.
#   • non-interactive env  — NONINTERACTIVE / INSTALL_CURSOR / etc. defaults so
#                            Homebrew and the install scripts don't block on a
#                            prompt that can never be answered.
#
# Guard against double-sourcing (the install scripts each source util/*.sh, and
# this file may be pulled in more than once).
# ─────────────────────────────────────────────────────────────────────────────
[[ -n "${OASIS_COMMON_SOURCED:-}" ]] && return 0
OASIS_COMMON_SOURCED=1

# ── Non-interactive defaults ───────────────────────────────────────────────
# Homebrew's installer blocks on "Press RETURN" unless this is set.
export NONINTERACTIVE=1
# Don't let any tool try to page output (git, brew, etc.).
export HOMEBREW_NO_ENV_HINTS=1
export GIT_PAGER=cat
export PAGER=cat
# Auto-answers for the dev-setup prompts. Override by exporting before sourcing.
export INSTALL_CURSOR="${INSTALL_CURSOR:-n}"   # skip optional Cursor IDE by default
export DOWNLOAD_JDK="${DOWNLOAD_JDK:-y}"       # auto-accept the required-JDK download

dl_log()  { echo "[$(date '+%H:%M:%S')] $*"; }

# ── macOS user-facing notification ─────────────────────────────────────────
# dl_notify <title> <message>
dl_notify() {
  [[ "$(uname)" == "Darwin" ]] || return 0
  local title="${1:-i-Ready OASIS}" msg="${2:-}"
  # Best-effort: never let a notification failure abort setup.
  osascript -e "display notification \"${msg//\"/\\\"}\" with title \"${title//\"/\\\"}\"" >/dev/null 2>&1 || true
}

# ── Secure GUI password prompt (osascript) ─────────────────────────────────
# Echoes the entered password on stdout. Returns non-zero if cancelled/empty.
# When OASIS_NO_DIALOG=1 (always set by the OASIS server) there is no
# desktop session to show a dialog, so instead we ask the OASIS UI for the
# password and block until it's delivered over a FIFO (see below).
_dl_ask_password() {
  local prompt="${1:-Enter your Mac (login) password to continue:}"
  if [[ -n "${OASIS_NO_DIALOG:-}" ]]; then
    _dl_wait_password_from_ui "$prompt"
    return $?
  fi
  osascript <<OSA 2>/dev/null
try
  set thePassword to text returned of (display dialog "${prompt//\"/\\\"}" default answer "" with title "i-Ready OASIS" with icon caution with hidden answer buttons {"OK"} default button "OK")
  return thePassword
on error
  return ""
end try
OSA
}

# Headless password handoff (OASIS server context).
# Emits a marker line the server watches for — it pops the password prompt in
# the browser — then blocks (bounded) until the server writes the password into
# the per-session FIFO. The secret only ever transits the pipe; it is never
# written to a regular file on disk. Echoes the password on stdout; non-zero if
# none arrived before the timeout. The server validates the password before
# sending it, so anything received here is already known-good.
_dl_wait_password_from_ui() {
  local fifo="${OASIS_SUDO_FIFO:-}"
  [[ -z "$fifo" ]] && { echo ""; return 1; }

  # Create the pipe if the server hasn't (0600 — owner-only).
  if [[ ! -p "$fifo" ]]; then
    ( umask 077; mkfifo "$fifo" ) 2>/dev/null || { echo ""; return 1; }
  fi

  # This exact phrase triggers the server to broadcast `sudo_required` to the UI.
  # Emit to STDERR, not stdout: the caller captures this function's stdout as the
  # password, so only the password itself may go there. The server scans stderr
  # too, so the prompt still fires.
  echo "[$(date '+%H:%M:%S')] Administrator access is required — waiting for your Mac password from the OASIS app…" >&2

  # Open read-write so neither end blocks merely opening the FIFO, then read one
  # line with a timeout (default 5 min; override with OASIS_SUDO_WAIT).
  local pw=""
  exec 9<>"$fifo"
  if read -r -t "${OASIS_SUDO_WAIT:-300}" pw <&9; then
    exec 9>&-
    printf '%s' "$pw"
    return 0
  fi
  exec 9>&-
  echo ""
  return 1
}

# Shared temp files used to coordinate across parallel setup processes.
_DL_KEEPALIVE_PID_FILE=/tmp/.oasis-sudo-keepalive.pid
_DL_SUDO_LOCK=/tmp/.oasis-sudo.lock

# ── Prime + keep sudo alive for the whole session ─────────────────────────
# Pops at most ONE password dialog per OASIS session. Safe to call from
# parallel or sequential scripts — a file lock prevents concurrent dialogs,
# and a persistent keepalive means the sudo timestamp stays valid for all
# subsequent repos without asking again.
dl_prime_sudo() {
  [[ "$(uname)" == "Darwin" ]] || return 0
  [[ -n "${DL_SUDO_PRIMED:-}" ]] && return 0

  # If a keepalive from a previous script in this session is still running,
  # the sudo timestamp is already warm — skip the dialog entirely.
  if _dl_keepalive_alive && sudo -n -v >/dev/null 2>&1; then
    dl_log "sudo already authorized (kept warm from previous setup step)."
    DL_SUDO_PRIMED=1
    return 0
  fi

  # Already have a valid sudo timestamp (e.g. passwordless sudo)?
  if sudo -n -v >/dev/null 2>&1; then
    dl_log "sudo already authorized — no password needed."
    _dl_start_sudo_keepalive
    DL_SUDO_PRIMED=1
    return 0
  fi

  # A parent step already collected the password (cached in the environment,
  # never on disk). Reuse it silently.
  if [[ -n "${OASIS_SUDO_PW:-}" ]] && \
     printf '%s\n' "$OASIS_SUDO_PW" | sudo -S -p '' -v >/dev/null 2>&1; then
    dl_log "Administrator access granted (reused cached credentials)."
    _dl_start_sudo_keepalive
    DL_SUDO_PRIMED=1
    return 0
  fi

  # ── Serialize: only one process may show the password dialog at a time ──
  # Use a lock file. While waiting, periodically recheck whether another
  # process has already primed sudo — if so, skip showing the dialog.
  local waited=0
  while ! (set -C; echo $$ > "$_DL_SUDO_LOCK") 2>/dev/null; do
    sleep 0.5
    (( waited++ ))
    [[ $waited -gt 120 ]] && break  # give up waiting after 60 s
    if sudo -n -v >/dev/null 2>&1; then
      dl_log "sudo now authorized (primed by a parallel setup step)."
      _dl_start_sudo_keepalive
      DL_SUDO_PRIMED=1
      return 0
    fi
  done

  dl_notify "Password needed" "OASIS needs your Mac password to install developer tools."

  local attempt pw rc=1
  for attempt in 1 2 3; do
    pw="$(_dl_ask_password "OASIS needs your Mac (login) password to install developer tools.

It is used locally to grant administrator access for this setup and is never stored on disk.")"
    if [[ -z "$pw" ]]; then
      dl_log "Password prompt cancelled."
      dl_notify "Setup paused" "No password entered — administrator steps will be skipped."
      rc=1; break
    fi
    if printf '%s\n' "$pw" | sudo -S -p '' -v >/dev/null 2>&1; then
      export OASIS_SUDO_PW="$pw"
      unset pw
      dl_log "Administrator access granted."
      _dl_start_sudo_keepalive
      DL_SUDO_PRIMED=1
      rc=0; break
    fi
    unset pw
    dl_notify "Incorrect password" "That password didn't work (attempt ${attempt}/3)."
  done

  rm -f "$_DL_SUDO_LOCK"
  [[ $rc -eq 0 ]] || dl_log "Could not obtain administrator access after 3 attempts."
  return $rc
}

# Returns 0 if the session-scoped keepalive process is still running.
_dl_keepalive_alive() {
  [[ -f "$_DL_KEEPALIVE_PID_FILE" ]] || return 1
  local pid
  pid=$(<"$_DL_KEEPALIVE_PID_FILE") 2>/dev/null || return 1
  kill -0 "$pid" 2>/dev/null
}

# Background loop that refreshes the sudo timestamp every 50 s. Persists
# across script boundaries (no EXIT trap) so the whole OASIS session
# only ever needs one password dialog. Exits on its own when sudo expires.
_dl_start_sudo_keepalive() {
  # Reuse an existing keepalive if it is still running.
  if _dl_keepalive_alive; then
    DL_SUDO_KEEPALIVE_PID=$(<"$_DL_KEEPALIVE_PID_FILE")
    return 0
  fi
  ( while true; do sudo -n -v >/dev/null 2>&1 || { rm -f "$_DL_KEEPALIVE_PID_FILE"; exit; }; sleep 50; done ) >/dev/null 2>&1 &
  DL_SUDO_KEEPALIVE_PID=$!
  echo "$DL_SUDO_KEEPALIVE_PID" > "$_DL_KEEPALIVE_PID_FILE"
  # No EXIT trap — the keepalive intentionally outlives each script so the
  # next repo setup in this session doesn't need to re-ask for the password.
}