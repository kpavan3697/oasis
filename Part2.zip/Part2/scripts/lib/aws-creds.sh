#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — shared AWS credential helper for launch scripts
#
# dl_ensure_aws_env [profile]
#   Makes sure valid AWS credentials are available, then exports them as
#   AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY / AWS_SESSION_TOKEN (and the region)
#   into the current environment.
#
# Why export env vars rather than rely on the profile: the JVM's AWS SDK resolves
# the EnvironmentVariableCredentialsProvider BEFORE the profile/SSO providers, so
# this works even when the app's SDK build lacks the optional "sso" module on its
# classpath (the exact failure: "To use Sso related properties in the 'default'
# profile, the 'sso' service module must be on the class path"). It also avoids a
# stale static [default] block masking a valid SSO session.
#
# If the SSO session is expired it runs `aws sso login` (opens a browser). Set
# OASIS_NONINTERACTIVE=1 to skip the interactive login instead.
# ─────────────────────────────────────────────────────────────────────────────

dl_ensure_aws_env() {
  local profile="${1:-${AWS_PROFILE:-default}}"

  if ! command -v aws >/dev/null 2>&1; then
    echo "⚠ AWS CLI not found — skipping AWS credential setup (app may fail if it needs AWS)." >&2
    return 0
  fi

  # Already have valid credentials for this profile?
  if ! aws sts get-caller-identity --profile "$profile" >/dev/null 2>&1; then
    if [ -n "${OASIS_NONINTERACTIVE:-}" ]; then
      echo "⚠ AWS session for profile '$profile' is not valid and we're non-interactive — skipping login." >&2
      echo "  Run 'aws sso login --profile $profile' yourself, then launch again." >&2
      return 1
    fi
    echo "→ AWS credentials for '$profile' aren't valid — starting SSO login (a browser window will open)…"
    if ! aws sso login --profile "$profile"; then
      echo "✗ 'aws sso login --profile $profile' failed." >&2
      return 1
    fi
  fi

  # Resolve the (now valid) temporary credentials and export them for the JVM.
  local creds
  if ! creds=$(aws configure export-credentials --profile "$profile" --format process 2>/dev/null); then
    echo "✗ Could not export AWS credentials for profile '$profile'." >&2
    return 1
  fi

  # Values are single-quoted (AWS keys/tokens never contain a single quote), so
  # eval is safe against the '/', '+', '=' characters that appear in tokens.
  local exports
  exports=$(printf '%s' "$creds" | python3 -c '
import sys, json
c = json.load(sys.stdin)
print("export AWS_ACCESS_KEY_ID=%r" % c["AccessKeyId"])
print("export AWS_SECRET_ACCESS_KEY=%r" % c["SecretAccessKey"])
if c.get("SessionToken"):
    print("export AWS_SESSION_TOKEN=%r" % c["SessionToken"])
' 2>/dev/null) || { echo "✗ Failed to parse AWS credentials." >&2; return 1; }
  eval "$exports"

  # Region: env override → profile region → leave unset.
  local region="${AWS_REGION:-${AWS_DEFAULT_REGION:-}}"
  [ -z "$region" ] && region=$(aws configure get region --profile "$profile" 2>/dev/null || true)
  if [ -n "$region" ]; then
    export AWS_REGION="$region"
    export AWS_DEFAULT_REGION="$region"
  fi

  echo "✓ AWS credentials loaded for profile '$profile'${region:+ (region $region)}."
  return 0
}