#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — Generic Setup Script
# Usage: ./scripts/setup.sh <clone_dir>
#
# Called automatically by the OASIS server when no repo-specific script
# is found. Detects project type and runs the appropriate setup steps.
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

CLONE_DIR="${1:?Usage: setup.sh <clone_dir>}"
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd "$CLONE_DIR"

log()  { echo "[$(date '+%H:%M:%S')] $*"; }
ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
warn() { echo "[$(date '+%H:%M:%S')] ⚠ $*"; }
fail() { echo "[$(date '+%H:%M:%S')] ✗ $*" >&2; exit 1; }

log "Starting generic setup in: $CLONE_DIR"

# ── Prerequisite toolchain ─────────────────────────────────────────────────
# Ensure the full i-Ready developer toolchain (git, JDK, Maven, Node, MySQL,
# Tomcat, Ant, AWS, …) is present before building. Each installer is idempotent
# and skips what's already there, so this is a fast no-op on a set-up machine.
# Set OASIS_SKIP_BOOTSTRAP=1 to bypass (e.g. CI or non-macOS).
BOOTSTRAP="$SCRIPT_DIR/iready-dev-setup/bootstrap.sh"
if [[ -z "${OASIS_SKIP_BOOTSTRAP:-}" && "$(uname)" == "Darwin" && -f "$BOOTSTRAP" ]]; then
  log "Ensuring developer toolchain is installed…"
  if bash "$BOOTSTRAP"; then
    ok "Toolchain ready"
  else
    warn "Toolchain bootstrap reported errors — continuing; build steps will verify required tools."
  fi
  # Privileged phase done — drop the cached password before the build steps.
  unset OASIS_SUDO_PW
  # bootstrap edits ~/.zshrc; pick up any new PATH/JAVA_HOME for the build below.
  # Use a zsh subshell — sourcing .zshrc directly in bash fails if it calls exit.
  _zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
    && eval "$_zsh_env" 2>/dev/null || true
fi

# ── Detect project type ───────────────────────────────────────────────────
detect_type() {
  if   [[ -f "pom.xml" ]];               then echo "java"
  elif [[ -f "build.gradle" ]];          then echo "gradle"
  elif [[ -f "package.json" ]];          then echo "node"
  elif [[ -f "Gemfile" ]];               then echo "ruby"
  elif [[ -f "requirements.txt" || -f "setup.py" || -f "pyproject.toml" ]]; then echo "python"
  elif [[ -f "go.mod" ]];                then echo "go"
  else                                        echo "unknown"
  fi
}

PROJECT_TYPE=$(detect_type)
log "Detected project type: $PROJECT_TYPE"

# ── Java / Maven ──────────────────────────────────────────────────────────
setup_java() {
  log "Java/Maven project detected"
  command -v java  >/dev/null || fail "Java not found. Install JDK and set JAVA_HOME."
  command -v mvn   >/dev/null || fail "Maven not found. Install Maven."
  log "Java:  $(java -version 2>&1 | head -1)"
  log "Maven: $(mvn --version | head -1)"
  MVN_ARGS="${MAVEN_ARGS:--DskipTests}"
  log "Running: mvn clean install $MVN_ARGS"
  mvn clean install $MVN_ARGS
  ok "Maven build complete"
}

# ── Gradle ───────────────────────────────────────────────────────────────
setup_gradle() {
  log "Gradle project detected"
  local gradle_cmd="./gradlew"
  [[ ! -x "$gradle_cmd" ]] && gradle_cmd="gradle"
  command -v $gradle_cmd >/dev/null || fail "Gradle not found."
  log "Running: $gradle_cmd build"
  $gradle_cmd build
  ok "Gradle build complete"
}

# ── Node.js ───────────────────────────────────────────────────────────────
setup_node() {
  log "Node.js project detected"
  command -v node >/dev/null || fail "Node.js not found. Install via nvm or brew."
  log "Node: $(node --version) | npm: $(npm --version)"

  # Detect package manager
  local PM="npm"
  [[ -f "yarn.lock"       ]] && PM="yarn"
  [[ -f "pnpm-lock.yaml"  ]] && PM="pnpm"
  log "Package manager: $PM"

  # nvm support
  if [[ -f ".nvmrc" ]] && command -v nvm &>/dev/null; then
    log "Using .nvmrc: $(cat .nvmrc)"
    nvm use || nvm install
  fi

  # Install
  $PM install

  # .env setup
  if [[ -f ".env.example" && ! -f ".env" ]]; then
    cp .env.example .env
    ok ".env created from .env.example"
    if [[ -n "${EXTRA_ENV:-}" ]]; then
      printf '\n%s\n' "$EXTRA_ENV" >> .env
      ok "Extra env vars appended"
    fi
  fi

  # Build
  if node -e "require('./package.json').scripts.build" 2>/dev/null; then
    log "Running build…"
    $PM run build
    ok "Build complete"
  fi
}

# ── Ruby ──────────────────────────────────────────────────────────────────
setup_ruby() {
  log "Ruby project detected"
  command -v ruby   >/dev/null || fail "Ruby not found."
  command -v bundle >/dev/null || fail "Bundler not found. Run: gem install bundler"
  log "Ruby: $(ruby --version)"

  # rbenv / rvm
  if [[ -f ".ruby-version" ]] && command -v rbenv &>/dev/null; then
    rbenv install --skip-existing "$(cat .ruby-version)"
    rbenv local "$(cat .ruby-version)"
  fi

  bundle install

  if [[ -f ".env.example" && ! -f ".env" ]]; then cp .env.example .env; fi

  if grep -q "rails" Gemfile 2>/dev/null; then
    log "Rails app detected — running db:setup"
    bundle exec rails db:setup || warn "db:setup failed (may need running DB)"
  fi
  ok "Ruby setup complete"
}

# ── Python ────────────────────────────────────────────────────────────────
setup_python() {
  log "Python project detected"
  local PYTHON_BIN="${PYTHON_BIN:-python3}"
  command -v $PYTHON_BIN >/dev/null || fail "Python3 not found."
  log "Python: $($PYTHON_BIN --version)"

  local VENV_DIR="$CLONE_DIR/venv"
  if [[ ! -d "$VENV_DIR" ]]; then
    $PYTHON_BIN -m venv "$VENV_DIR"
    ok "Virtual environment created"
  fi

  source "$VENV_DIR/bin/activate"
  pip install --upgrade pip -q

  [[ -f "requirements.txt"  ]] && pip install -r requirements.txt
  [[ -f "requirements-dev.txt" ]] && pip install -r requirements-dev.txt
  [[ -f "pyproject.toml"    ]] && pip install -e ".[dev]" 2>/dev/null || pip install -e . 2>/dev/null || true

  if [[ -f ".env.example" && ! -f ".env" ]]; then cp .env.example .env; fi

  # Django migrations
  if [[ -f "manage.py" ]]; then
    log "Django project detected — running migrations"
    python manage.py migrate || warn "Migrations failed"
  fi

  ok "Python setup complete"
}

# ── Go ────────────────────────────────────────────────────────────────────
setup_go() {
  log "Go project detected"
  command -v go >/dev/null || fail "Go not found."
  log "Go: $(go version)"
  go mod download
  go build ./...
  ok "Go build complete"
}

# ── Open in IntelliJ ──────────────────────────────────────────────────────
open_intellij() {
  if [[ -n "${INTELLIJ_PATH:-}" && -x "$INTELLIJ_PATH" ]]; then
    log "Opening in IntelliJ IDEA: $INTELLIJ_PATH $CLONE_DIR"
    # Detach stdio and disown: otherwise the IDE inherits this script's stdout/
    # stderr (a pipe to the OASIS server) and holds it open for its whole
    # lifetime, so the server never sees the output stream close and the job
    # spins forever instead of completing.
    "$INTELLIJ_PATH" "$CLONE_DIR" >/dev/null 2>&1 &
    disown
    ok "IntelliJ IDEA launched"
  fi
}

# ── Run ───────────────────────────────────────────────────────────────────
case "$PROJECT_TYPE" in
  java)    setup_java    ;;
  gradle)  setup_gradle  ;;
  node)    setup_node    ;;
  ruby)    setup_ruby    ;;
  python)  setup_python  ;;
  go)      setup_go      ;;
  unknown) warn "Could not detect project type — skipping build step" ;;
esac

open_intellij

ok "Setup complete for $(basename $CLONE_DIR)"
