#!/usr/bin/env bash
# i-Ready OASIS — Java/Maven Setup Script
# Usage: ./scripts/setup-java.sh <clone_dir>
set -euo pipefail

CLONE_DIR="${1:?Usage: setup-java.sh <clone_dir>}"
cd "$CLONE_DIR"

log()  { echo "[$(date '+%H:%M:%S')] $*"; }
ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
fail() { echo "[$(date '+%H:%M:%S')] ✗ $*" >&2; exit 1; }

log "Java/Maven setup for: $(basename $CLONE_DIR)"

# Java / Maven checks
command -v java >/dev/null || fail "Java not found. Set JAVA_HOME and add java to PATH."
command -v mvn  >/dev/null || fail "Maven not found. Install Maven (brew install maven)."

log "Java:  $(java -version 2>&1 | head -1)"
log "Maven: $(mvn --version 2>&1 | head -1)"

# Optional JAVA_HOME override
if [[ -n "${JAVA_HOME_OVERRIDE:-}" ]]; then
  export JAVA_HOME="$JAVA_HOME_OVERRIDE"
  log "JAVA_HOME set to $JAVA_HOME"
fi

# Build
MVN_ARGS="${MAVEN_ARGS:--DskipTests}"
log "Running: mvn clean install $MVN_ARGS"
mvn clean install $MVN_ARGS

ok "Maven build complete"

# Open IDE
if [[ -n "${INTELLIJ_PATH:-}" && -x "${INTELLIJ_PATH}" ]]; then
  log "Opening in IntelliJ IDEA…"
  # Detach stdio + disown so the IDE doesn't hold the server's output pipe open
  # (which would stall the job at "complete" forever).
  "${INTELLIJ_PATH}" "$CLONE_DIR" >/dev/null 2>&1 &
  disown
  ok "IntelliJ IDEA launched"
fi

log "Done — $(basename $CLONE_DIR) is ready"
