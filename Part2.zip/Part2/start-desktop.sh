#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

echo "Starting i-Ready OASIS desktop app (Electron)"

npx electron .