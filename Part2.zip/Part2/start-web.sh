#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

PORT=${PORT:-3000}

# Kill any process already holding the port
existing=$(lsof -ti :${PORT} -sTCP:LISTEN 2>/dev/null || true)
if [ -n "$existing" ]; then
  echo "Killing existing process on port ${PORT} (PID $existing)…"
  kill $existing
  sleep 1
fi

echo "Starting i-Ready OASIS web server on http://localhost:${PORT}"

node server/index.js