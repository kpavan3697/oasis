# macOS Signing & Notarization — IT Handoff Checklist

Everything in the codebase is ready (see `DESKTOP.md`). This doc lists the exact
steps to produce the **credentials** and store them as CI secrets so tagged builds
sign + notarize automatically.

You need three things:
1. A **Developer ID Application** certificate (for signing the `.app`) → `MAC_CSC_LINK` + `MAC_CSC_KEY_PASSWORD`
2. A **Developer ID Installer** certificate (for signing the `.pkg`) → `PKG_CSC_LINK` + `PKG_CSC_KEY_PASSWORD`
3. **Notary credentials** (for notarization of both) → *either* an App Store Connect API key *(recommended)* *or* an Apple ID app-specific password.

> If the Application and Installer certs are exported from the same `.p12`, you can set `PKG_CSC_LINK`=`MAC_CSC_LINK` and `PKG_CSC_KEY_PASSWORD`=`MAC_CSC_KEY_PASSWORD`. The `build-pkg.sh` script also falls back to `CSC_LINK`/`CSC_KEY_PASSWORD` automatically.

All of this requires access to the **Curriculum Associates Apple Developer team**
(coordinate via cainc.service-now.com). Do all `security`/key steps on a Mac.

---

## 1. Certificates

### Developer ID Application → signs the `.app`

1. Apple Developer portal → **Certificates** → **+** → **Developer ID Application**.
2. Create a CSR (*Keychain Access → Certificate Assistant → Request a Certificate from a CA* → "Saved to disk").
3. Upload the CSR, download the `.cer`, double-click to install into the **login** keychain.

### Developer ID Installer → signs the `.pkg`

1. Apple Developer portal → **Certificates** → **+** → **Developer ID Installer**.
2. Same CSR/upload/install flow as above.

### Export both to `.p12` files

Keychain Access → **My Certificates** → right-click each cert → **Export** → save with strong passwords.

```bash
security find-identity -v -p codesigning
# look for:
#   "Developer ID Application: Curriculum Associates, Inc. (XXXXXXXXXX)"
#   "Developer ID Installer: Curriculum Associates, Inc. (XXXXXXXXXX)"
```

You can export them into the **same `.p12`** (select both in Keychain Access before exporting) — then reuse the same base64 blob and password for both secrets.

### Base64-encode → CI secrets

```bash
# macOS base64 (single line, no wrapping)
base64 -i oasis-signing.p12 | tr -d '\n' | pbcopy
```

| Secret | Value |
|--------|-------|
| `MAC_CSC_LINK` | base64-encoded `.p12` (Application cert) |
| `MAC_CSC_KEY_PASSWORD` | `.p12` export password |
| `PKG_CSC_LINK` | base64-encoded `.p12` (Installer cert; same value if combined) |
| `PKG_CSC_KEY_PASSWORD` | `.p12` export password |

> Delete `.p12` and `.b64` files after copying. Never commit them.

---

## 2A. Notary credentials — App Store Connect API key (recommended)

API keys don't expire on a 1-year app-password cycle and aren't tied to a person.

1. App Store Connect → **Users and Access** → **Integrations / Keys** →
   **App Store Connect API** → **+** to generate a key with the **Developer** role.
2. Download the **`AuthKey_XXXXXXXXXX.p8`** (you can only download it once).
3. Note the **Key ID** (e.g. `XXXXXXXXXX`) and the **Issuer ID** (a UUID at the top of the page).

In CI you need the `.p8` available as a file. Two common patterns:

- **Path secret:** place the `.p8` on the self-hosted runner and set `APPLE_API_KEY`
  to its absolute path, or
- **Base64 secret + write to disk in the workflow** (avoids storing files on the runner):

```yaml
# add before the "Build (mac)" step if you store the key base64-encoded
- name: Write API key
  run: |
    echo "$APPLE_API_KEY_B64" | base64 --decode > "$RUNNER_TEMP/AuthKey.p8"
    echo "APPLE_API_KEY=$RUNNER_TEMP/AuthKey.p8" >> "$GITHUB_ENV"
  env:
    APPLE_API_KEY_B64: ${{ secrets.APPLE_API_KEY_B64 }}
```

| Secret | Value |
|--------|-------|
| `APPLE_API_KEY` | absolute path to the `.p8` (or use the base64 pattern above) |
| `APPLE_API_KEY_ID` | the Key ID |
| `APPLE_API_ISSUER` | the Issuer ID (UUID) |

---

## 2B. Notary credentials — Apple ID (alternative)

1. The Apple ID must be a member of the CA Developer team.
2. Create an **app-specific password**: appleid.apple.com → Sign-In & Security →
   App-Specific Passwords → generate (label it "OASIS notarize").
3. Find the **Team ID**: Apple Developer → Membership (10-char, e.g. `XXXXXXXXXX`).

| Secret | Value |
|--------|-------|
| `APPLE_ID` | the developer Apple ID email |
| `APPLE_APP_SPECIFIC_PASSWORD` | the app-specific password (format `abcd-efgh-ijkl-mnop`) |
| `APPLE_TEAM_ID` | the 10-char Team ID |

> The notarize hook (`build/notarize.js`) uses the **API key set if present**, otherwise
> the Apple ID set. Supply only one.

---

## 3. Store the secrets

In the GitHub Enterprise repo: **Settings → Secrets and variables → Actions → New
repository secret** (or an org/environment secret). Add the signing secrets from §1
and one notary set from §2A/§2B, plus the existing publish secrets:

- `NEXUS_USER`, `NEXUS_PASS` — upload installers to the Nexus feed
- `NEXUS_NPM_TOKEN` — `npm ci` auth against the Nexus registry

---

## 4. Verify

### Locally (on a Mac with the certs in keychain)

```bash
export CSC_LINK="$(base64 -i oasis-signing.p12 | tr -d '\n')"
export CSC_KEY_PASSWORD='…'
export PKG_CSC_LINK="$CSC_LINK"          # same .p12 if combined export
export PKG_CSC_KEY_PASSWORD="$CSC_KEY_PASSWORD"
# API key route:
export APPLE_API_KEY="$PWD/AuthKey_XXXXXXXXXX.p8" APPLE_API_KEY_ID='XXXXXXXXXX' APPLE_API_ISSUER='…'
npm run dist:pkg
# .app: "Notarizing … via notarytool" → "Notarization complete (ticket stapled)."
# .pkg: "Signing pkg with: Developer ID Installer:…" → "Notarization complete."
```

### Confirm the result

```bash
# .app — signed with hardened runtime?
codesign -dv --verbose=4 "release/mac-arm64/i-Ready OASIS.app" 2>&1 | grep -E 'Authority|flags'
# .app — notarization ticket stapled?
xcrun stapler validate "release/mac-arm64/i-Ready OASIS.app"
# .app — Gatekeeper accepts it?
spctl -a -vvv -t install "release/mac-arm64/i-Ready OASIS.app"

# .pkg — signed?
pkgutil --check-signature "release/i-Ready OASIS-1.1.0-arm64.pkg"
# .pkg — notarization ticket stapled?
xcrun stapler validate "release/i-Ready OASIS-1.1.0-arm64.pkg"
# .pkg — Gatekeeper accepts it?
spctl -a -vvv -t install "release/i-Ready OASIS-1.1.0-arm64.pkg"
```

All checks passing means Gatekeeper will accept the pkg on any Mac.

---

## Notes / gotchas

- **Notarization ≠ signing.** Both are required; the hook only notarizes after
  electron-builder signs. Missing creds → the hook **skips** (build still succeeds,
  but the app won't pass Gatekeeper or auto-update on other machines).
- Keep the signing `.p12` and API `.p8` **out of the repo** — secrets only.
- First notarization of a new bundle ID can take a few minutes; subsequent ones are faster.
- If notarization fails, get the log: `xcrun notarytool log <submission-id> --key … --key-id … --issuer …`.
